﻿Database SQLite (kospace.db) dibuat otomatis saat aplikasi pertama dijalankan.
