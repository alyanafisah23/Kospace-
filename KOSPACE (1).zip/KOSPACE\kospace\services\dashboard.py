"""Layanan ringkasan dashboard dan sinkronisasi status otomatis."""

from __future__ import annotations

from datetime import date, timedelta

from ..database import db
from ..repositories import pembayaran as repo_bayar
from ..repositories import sewa as repo_sewa


def sync_statuses(hari_ini: date | None = None) -> None:
    """Perbarui status sewa dan kamar berdasarkan tanggal hari ini."""
    ref = (hari_ini or date.today()).isoformat()
    with db() as conn:
        # Sewa yang tanggal selesainya sudah lewat otomatis menjadi Selesai.
        conn.execute(
            """
            UPDATE sewa
            SET status_sewa = 'Selesai'
            WHERE status_sewa = 'Aktif' AND tanggal_selesai < ?
            """,
            (ref,),
        )
        # Status kamar diturunkan dari ada/tidaknya sewa aktif pada hari ini.
        conn.execute(
            """
            UPDATE kamar
            SET status = CASE
                WHEN EXISTS (
                    SELECT 1 FROM sewa s
                    WHERE s.id_kamar = kamar.id_kamar
                      AND s.status_sewa = 'Aktif'
                      AND ? BETWEEN s.tanggal_mulai AND s.tanggal_selesai
                ) THEN 'Ditempati'
                ELSE 'Tersedia'
            END
            """,
            (ref,),
        )


def ringkasan(hari_ini: date | None = None) -> dict[str, object]:
    """Kumpulkan seluruh angka yang dibutuhkan dashboard."""
    hari_ini = hari_ini or date.today()
    ref = hari_ini.isoformat()

    with db() as conn:
        total_kamar = int(
            conn.execute("SELECT COUNT(*) FROM kamar").fetchone()[0]
        )
        tersedia = int(
            conn.execute(
                "SELECT COUNT(*) FROM kamar WHERE status = 'Tersedia'"
            ).fetchone()[0]
        )
        ditempati = int(
            conn.execute(
                "SELECT COUNT(*) FROM kamar WHERE status = 'Ditempati'"
            ).fetchone()[0]
        )
        sewa_aktif = repo_sewa.hitung_sewa_aktif(conn)

        bayar = conn.execute(
            """
            SELECT COUNT(*) AS jumlah, COALESCE(SUM(nominal), 0) AS nominal
            FROM pembayaran
            WHERE strftime('%Y-%m', tanggal_bayar) = ?
            """,
            (hari_ini.strftime("%Y-%m"),),
        ).fetchone()

        tunggakan = repo_bayar.ringkasan_tunggakan(conn, hari_ini)

        per_tipe = conn.execute(
            """
            SELECT tipe,
                   COUNT(*) AS total,
                   SUM(CASE WHEN status = 'Tersedia' THEN 1 ELSE 0 END) AS tersedia,
                   SUM(CASE WHEN status = 'Ditempati' THEN 1 ELSE 0 END) AS ditempati
            FROM kamar
            GROUP BY tipe
            ORDER BY tipe
            """
        ).fetchall()

        terbaru = repo_bayar.pembayaran_terbaru(conn, 5)

        batas = (hari_ini + timedelta(days=30)).isoformat()
        segera_berakhir = conn.execute(
            """
            SELECT s.*, p.nama AS nama_penghuni, k.nomor_kamar
            FROM sewa s
            JOIN penghuni p ON p.id_penghuni = s.id_penghuni
            JOIN kamar k ON k.id_kamar = s.id_kamar
            WHERE s.status_sewa = 'Aktif'
              AND s.tanggal_selesai BETWEEN ? AND ?
            ORDER BY s.tanggal_selesai
            LIMIT 5
            """,
            (ref, batas),
        ).fetchall()

    okupansi = (ditempati / total_kamar * 100) if total_kamar else 0.0

    return {
        "total_kamar": total_kamar,
        "tersedia": tersedia,
        "ditempati": ditempati,
        "sewa_aktif": sewa_aktif,
        "okupansi": okupansi,
        "bayar_jumlah": int(bayar["jumlah"]),
        "bayar_nominal": int(bayar["nominal"]),
        "tunggakan_jumlah": int(tunggakan["jumlah"]),
        "tunggakan_nominal": int(tunggakan["nominal"]),
        "tunggakan_rincian": tunggakan["rincian"],
        "per_tipe": per_tipe,
        "terbaru": terbaru,
        "segera_berakhir": segera_berakhir,
    }
