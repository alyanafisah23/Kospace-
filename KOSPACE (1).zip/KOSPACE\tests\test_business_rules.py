"""Unit test aturan bisnis inti KOSPACE."""

from __future__ import annotations

import tempfile
import unittest
from datetime import date
from pathlib import Path

from kospace.database import create_schema, get_connection, seed_rooms
from kospace.repositories import kamar as repo_kamar
from kospace.repositories import pembayaran as repo_bayar
from kospace.repositories import penghuni as repo_penghuni
from kospace.repositories import sewa as repo_sewa
from kospace.utils import duration_months
from kospace.validators import ValidationError


class KospaceTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.conn = get_connection(Path(self.tmp.name) / "test.db")
        create_schema(self.conn)
        seed_rooms(self.conn)
        self.conn.commit()

    def tearDown(self) -> None:
        self.conn.close()
        self.tmp.cleanup()

    # ------------------------------------------------------------------
    # Helper
    # ------------------------------------------------------------------
    def buat_penghuni(self, nama: str = "Penghuni Uji") -> str:
        return repo_penghuni.create_penghuni(
            self.conn,
            nama,
            "0812-3456-7890",
            "0813-1111-2222",
            "Bandung, Jawa Barat",
        )

    def id_kamar(self, nomor: str) -> str:
        row = repo_kamar.get_kamar_by_nomor(self.conn, nomor)
        self.assertIsNotNone(row)
        return str(row["id_kamar"])

    # ------------------------------------------------------------------
    # B01 — nomor kamar unik
    # ------------------------------------------------------------------
    def test_b01_nomor_kamar_tidak_boleh_kembar(self) -> None:
        repo_kamar.create_kamar(
            self.conn, "A06", "A", 1_300_000, "AC, Wi-Fi"
        )
        with self.assertRaises(ValidationError):
            repo_kamar.create_kamar(
                self.conn, "A06", "A", 1_300_000, "AC, Wi-Fi"
            )

    def test_b01_update_ke_nomor_yang_sudah_ada_ditolak(self) -> None:
        with self.assertRaises(ValidationError):
            repo_kamar.update_kamar(
                self.conn,
                self.id_kamar("A02"),
                "A01",
                "A",
                1_300_000,
                "AC",
            )

    # ------------------------------------------------------------------
    # B06 — tanggal selesai harus setelah tanggal mulai
    # ------------------------------------------------------------------
    def test_b06_tanggal_selesai_harus_setelah_mulai(self) -> None:
        penghuni = self.buat_penghuni()
        with self.assertRaises(ValidationError):
            repo_sewa.create_sewa(
                self.conn,
                penghuni,
                self.id_kamar("A01"),
                date(2027, 1, 1),
                date(2027, 1, 1),
            )
        with self.assertRaises(ValidationError):
            repo_sewa.create_sewa(
                self.conn,
                penghuni,
                self.id_kamar("A01"),
                date(2027, 3, 1),
                date(2027, 2, 1),
            )

    # ------------------------------------------------------------------
    # Jadwal bertabrakan
    # ------------------------------------------------------------------
    def test_jadwal_bertabrakan_ditolak(self) -> None:
        penghuni = self.buat_penghuni()
        kamar = self.id_kamar("A01")
        repo_sewa.create_sewa(
            self.conn, penghuni, kamar, date(2027, 1, 1), date(2027, 3, 31)
        )
        with self.assertRaises(ValidationError):
            repo_sewa.create_sewa(
                self.conn, penghuni, kamar, date(2027, 3, 1), date(2027, 4, 30)
            )

    def test_jadwal_bersambung_diterima(self) -> None:
        penghuni = self.buat_penghuni()
        kamar = self.id_kamar("A01")
        repo_sewa.create_sewa(
            self.conn, penghuni, kamar, date(2027, 1, 1), date(2027, 3, 31)
        )
        id_sewa = repo_sewa.create_sewa(
            self.conn, penghuni, kamar, date(2027, 4, 1), date(2027, 6, 30)
        )
        self.assertTrue(id_sewa.startswith("S"))

    # ------------------------------------------------------------------
    # B08 — nominal pembayaran
    # ------------------------------------------------------------------
    def test_b08_nominal_harus_sama_dengan_harga_sewa(self) -> None:
        penghuni = self.buat_penghuni()
        id_sewa = repo_sewa.create_sewa(
            self.conn,
            penghuni,
            self.id_kamar("A01"),
            date(2027, 1, 1),
            date(2027, 3, 31),
        )
        with self.assertRaises(ValidationError):
            repo_bayar.create_pembayaran(
                self.conn, id_sewa, 1, 2027, date(2027, 1, 5), 0
            )
        with self.assertRaises(ValidationError):
            repo_bayar.create_pembayaran(
                self.conn, id_sewa, 1, 2027, date(2027, 1, 5), 1_000_000
            )
        id_bayar = repo_bayar.create_pembayaran(
            self.conn, id_sewa, 1, 2027, date(2027, 1, 5), 1_300_000
        )
        self.assertTrue(id_bayar.startswith("BY"))

    # ------------------------------------------------------------------
    # B14 — satu periode satu pembayaran
    # ------------------------------------------------------------------
    def test_b14_periode_ganda_ditolak(self) -> None:
        penghuni = self.buat_penghuni()
        id_sewa = repo_sewa.create_sewa(
            self.conn,
            penghuni,
            self.id_kamar("A01"),
            date(2027, 1, 1),
            date(2027, 3, 31),
        )
        repo_bayar.create_pembayaran(
            self.conn, id_sewa, 1, 2027, date(2027, 1, 5), 1_300_000
        )
        with self.assertRaises(ValidationError):
            repo_bayar.create_pembayaran(
                self.conn, id_sewa, 1, 2027, date(2027, 1, 8), 1_300_000
            )

    # ------------------------------------------------------------------
    # B10 — data dengan riwayat sewa tidak boleh dihapus
    # ------------------------------------------------------------------
    def test_b10_kamar_dan_penghuni_dengan_riwayat_tidak_bisa_dihapus(self) -> None:
        penghuni = self.buat_penghuni()
        id_kamar = self.id_kamar("A01")
        repo_sewa.create_sewa(
            self.conn, penghuni, id_kamar, date(2027, 1, 1), date(2027, 3, 31)
        )
        with self.assertRaises(ValidationError):
            repo_kamar.delete_kamar(self.conn, id_kamar)
        with self.assertRaises(ValidationError):
            repo_penghuni.delete_penghuni(self.conn, penghuni)

    def test_kamar_tanpa_riwayat_boleh_dihapus(self) -> None:
        repo_kamar.delete_kamar(self.conn, self.id_kamar("A02"))
        self.assertIsNone(repo_kamar.get_kamar_by_nomor(self.conn, "A02"))

    # ------------------------------------------------------------------
    # Status tagihan otomatis
    # ------------------------------------------------------------------
    def test_status_tagihan_lunas_terlambat_dan_belum_dibayar(self) -> None:
        penghuni = self.buat_penghuni()
        id_sewa = repo_sewa.create_sewa(
            self.conn,
            penghuni,
            self.id_kamar("A01"),
            date(2027, 1, 1),
            date(2027, 3, 31),
        )
        repo_bayar.create_pembayaran(
            self.conn, id_sewa, 2, 2027, date(2027, 2, 5), 1_300_000
        )
        sewa = repo_sewa.get_sewa(self.conn, id_sewa)
        jadwal = repo_bayar.billing_schedule(
            self.conn, sewa, hari_ini=date(2027, 3, 15)
        )
        status = {j["label"]: j["status"] for j in jadwal}
        self.assertEqual(status["Januari 2027"], "Terlambat")
        self.assertEqual(status["Februari 2027"], "Lunas")
        self.assertEqual(status["Maret 2027"], "Terlambat")

        tunggakan = repo_bayar.ringkasan_tunggakan(
            self.conn, hari_ini=date(2027, 3, 15)
        )
        self.assertEqual(tunggakan["jumlah"], 2)
        self.assertEqual(tunggakan["nominal"], 2_600_000)

    def test_status_belum_dibayar_sebelum_jatuh_tempo(self) -> None:
        penghuni = self.buat_penghuni()
        id_sewa = repo_sewa.create_sewa(
            self.conn,
            penghuni,
            self.id_kamar("B01"),
            date(2027, 1, 1),
            date(2027, 1, 31),
        )
        sewa = repo_sewa.get_sewa(self.conn, id_sewa)
        jadwal = repo_bayar.billing_schedule(
            self.conn, sewa, hari_ini=date(2027, 1, 5)
        )
        self.assertEqual(jadwal[0]["status"], "Belum Dibayar")

    # ------------------------------------------------------------------
    # ID otomatis & durasi
    # ------------------------------------------------------------------
    def test_id_kamar_berurutan_setelah_seed(self) -> None:
        id_1 = repo_kamar.create_kamar(
            self.conn, "A06", "A", 1_300_000, "AC"
        )
        id_2 = repo_kamar.create_kamar(
            self.conn, "A07", "A", 1_300_000, "AC"
        )
        self.assertEqual(id_1, "K026")
        self.assertEqual(id_2, "K027")

    def test_durasi_bulan(self) -> None:
        self.assertEqual(
            duration_months(date(2027, 1, 1), date(2027, 3, 31)), 3
        )
        self.assertEqual(
            duration_months(date(2027, 1, 15), date(2027, 2, 14)), 1
        )
        self.assertEqual(
            duration_months(date(2026, 8, 31), date(2027, 8, 31)), 12
        )
        self.assertEqual(
            duration_months(date(2027, 1, 15), date(2027, 2, 15)), 1
        )

    # ------------------------------------------------------------------
    # Pembayaran boleh dihapus untuk koreksi
    # ------------------------------------------------------------------
    def test_pembayaran_boleh_dihapus_untuk_koreksi(self) -> None:
        penghuni = self.buat_penghuni()
        id_sewa = repo_sewa.create_sewa(
            self.conn,
            penghuni,
            self.id_kamar("A01"),
            date(2027, 1, 1),
            date(2027, 3, 31),
        )
        id_bayar = repo_bayar.create_pembayaran(
            self.conn, id_sewa, 1, 2027, date(2027, 1, 5), 1_300_000
        )
        repo_bayar.delete_pembayaran(self.conn, id_bayar)
        self.assertIsNone(repo_bayar.get_pembayaran(self.conn, id_bayar))


if __name__ == "__main__":
    unittest.main()
