# KOSPACE — Website Rancangan & Demo Admin

Folder ini berisi **website statis** KOSPACE: satu landing page untuk
menjelaskan rancangan sistem, dan satu demo admin yang bisa langsung dipakai.
Website ini melengkapi aplikasi utama Streamlit di folder induk.

- `index.html` — landing page (presentasi rancangan, pemetaan 16 slide PPT).
- `app.html` — demo admin (dashboard, kamar, penghuni, sewa, pembayaran,
  riwayat) dengan aturan bisnis B01, B06, B08, B10, B14 dan deteksi jadwal
  bertabrakan.
- `assets/` — logo KOSPACE (warna, transparan, putih, ikon, favicon).
- `css/base.css` — design token, reset, tombol, badge, form, utilitas.
- `css/landing.css` — tampilan landing page.
- `css/app.css` — tampilan demo admin.
- `js/data.js` — data contoh, localStorage, status otomatis, validasi, CSV.
- `js/landing.js` — interaksi landing (header, menu, animasi, angka dinamis).
- `js/app.js` — hash router dan seluruh interaksi demo admin.

## Cara menjalankan

### Cara cepat (tanpa server)

Buka `index.html` langsung di browser. Demo admin juga bisa dibuka lewat
`app.html`. Semua data disimpan di `localStorage`, jadi tidak butuh Python
maupun database.

> Catatan: beberapa browser membatasi `localStorage` pada `file://`. Jika data
> tidak tersimpan, gunakan cara server di bawah.

### Cara disarankan (server lokal)

Jalankan dari folder **`kospace`** (folder induk `website`):

```powershell
python -m http.server 8765 --bind 127.0.0.1
```

Lalu buka:

- Landing page: <http://127.0.0.1:8765/website/index.html>
- Demo admin: <http://127.0.0.1:8765/website/app.html>
- Dokumen rancangan: <http://127.0.0.1:8765/docs/RANCANGAN_WEBSITE.md>

Menjalankan server dari folder `kospace` membuat tautan **Lihat Rancangan**
di landing page ikut berfungsi. Tekan `Ctrl + C` di terminal untuk
menghentikan server.

## Data demo

Data contoh dibuat relatif terhadap tanggal hari ini:

- 25 kamar: A01–A05 (Rp1.300.000), B01–B10 (Rp950.000), C01–C10
  (Rp700.000).
- 5 penghuni dan 5 sewa aktif.
- 11 pembayaran contoh; sewa **S004** (Shintia, kamar C05) sengaja belum
  punya pembayaran agar status **Terlambat** bisa didemokan.

Tombol **Reset data demo** di sidebar mengembalikan seluruh data ke kondisi
awal. Tombol **Unduh CSV** mengekspor rekap pembayaran.

## Aturan bisnis yang bisa dicoba

| Kode | Cara mencoba | Pesan yang muncul |
|------|--------------|-------------------|
| B01 | Tambah kamar dengan nomor yang sudah ada (mis. `A01`) | Nomor kamar A01 sudah dipakai (aturan B01). |
| B06 | Buat sewa dengan tanggal selesai sebelum tanggal mulai | Tanggal selesai harus setelah tanggal mulai (aturan B06). |
| — | Buat sewa yang jadwalnya bertabrakan di kamar yang sama | Jadwal bertabrakan dengan sewa … |
| B08 | Isi nominal pembayaran 0 atau berbeda dari harga sewa | Nominal harus sama dengan harga sewa (aturan B08). |
| B10 | Hapus kamar/penghuni yang punya riwayat sewa | … punya riwayat sewa sehingga tidak boleh dihapus (aturan B10). |
| B14 | Catat pembayaran kedua untuk sewa, bulan, dan tahun yang sama | Sewa … sudah punya pembayaran untuk … (aturan B14). |

## Status otomatis

- **Kamar**: `Ditempati` bila ada sewa aktif yang mencakup hari ini;
  `Tersedia` bila tidak ada.
- **Sewa**: `Aktif` bila tanggal selesai belum lewat; `Selesai` bila sudah
  lewat atau diakhiri lebih awal.
- **Pembayaran**: `Lunas` bila sudah dicatat; `Belum Dibayar` bila belum
  melewati jatuh tempo tanggal 10; `Terlambat` bila sudah melewati tanggal 10.

## Catatan teknis

- Tanpa build tool dan tanpa dependensi JavaScript. Cukup buka file.
- Font Plus Jakarta Sans dimuat dari Google Fonts; tanpa internet font
  fallback ke Segoe UI/system.
- Logo memakai file asli dari folder unduhan, diolah menjadi beberapa varian
  (transparan, putih, ikon, favicon).
- Demo ini adalah prototipe tampilan. Aplikasi produksi tetap memakai
  Streamlit + SQLite seperti di `docs/RANCANGAN.md`.
