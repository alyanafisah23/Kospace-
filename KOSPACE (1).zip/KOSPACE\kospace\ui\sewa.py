"""Halaman pengelolaan Sewa."""

from __future__ import annotations

from datetime import timedelta
from html import escape

import streamlit as st

from ..config import ROOM_TYPES
from ..database import db
from ..repositories import kamar as repo_kamar
from ..repositories import penghuni as repo_penghuni
from ..repositories import sewa as repo
from ..services import dashboard as svc
from ..utils import (
    duration_months,
    fmt_date,
    fmt_date_short,
    rupiah,
    today,
)
from ..validators import ValidationError
from .components import (
    badge,
    empty_state,
    flash,
    page_header,
    strong,
    table,
)


def render() -> None:
    page_header(
        "Transaksi",
        "Sewa",
        "Hubungkan penghuni dengan kamar, tetapkan masa sewa, dan pastikan "
        "tidak ada jadwal yang bertabrakan.",
    )
    tab_daftar, tab_buat, tab_ubah = st.tabs(
        ["Daftar Sewa", "Buat Sewa", "Akhiri & Hapus"]
    )
    with tab_daftar:
        _daftar()
    with tab_buat:
        _buat()
    with tab_ubah:
        _akhiri_hapus()


def _daftar() -> None:
    kiri, kanan = st.columns([1.0, 2.0])
    status = kiri.selectbox(
        "Status", ["Semua", "Aktif", "Selesai"], key="sewa_filter_status"
    )
    q = kanan.text_input(
        "Cari sewa",
        placeholder="Nama penghuni, nomor kamar, atau ID sewa…",
        key="sewa_cari",
    )

    with db() as conn:
        rows = repo.list_sewa(conn, status=status, q=q)

    isi = []
    for row in rows:
        isi.append(
            [
                strong(str(row["id_sewa"])),
                escape(str(row["nama_penghuni"])),
                escape(str(row["nomor_kamar"])),
                fmt_date(row["tanggal_mulai"]),
                fmt_date(row["tanggal_selesai"]),
                f"{row['durasi']} bln",
                rupiah(row["harga_bulanan"]),
                rupiah(row["total_dibayar"]),
                badge(str(row["status_sewa"])),
            ]
        )

    table(
        [
            "ID",
            "Penghuni",
            "Kamar",
            "Mulai",
            "Selesai",
            "Durasi",
            "Harga",
            "Dibayar",
            "Status",
        ],
        isi,
        empty_title="Belum ada data sewa",
        empty_message="Buat sewa pertama pada tab Buat Sewa.",
    )
    st.caption(f"{len(rows)} sewa ditampilkan.")


def _buat() -> None:
    with db() as conn:
        penghuni_rows = repo_penghuni.list_penghuni(conn)
        kamar_rows = repo_kamar.list_kamar(conn)

    if not penghuni_rows:
        empty_state(
            "Belum ada penghuni",
            "Tambahkan penghuni terlebih dahulu sebelum membuat sewa.",
        )
        if st.button("Buka menu Penghuni", type="primary"):
            st.session_state.page = "penghuni"
            st.rerun()
        return

    if not kamar_rows:
        empty_state(
            "Belum ada kamar",
            "Tambahkan kamar terlebih dahulu sebelum membuat sewa.",
        )
        return

    peta_penghuni = {str(r["id_penghuni"]): r for r in penghuni_rows}
    peta_kamar = {str(r["id_kamar"]): r for r in kamar_rows}

    kiri, kanan = st.columns([1.25, 1.0])
    with kiri:
        st.markdown("#### Detail sewa baru")
        id_penghuni = st.selectbox(
            "Penghuni",
            list(peta_penghuni),
            format_func=lambda k: (
                f"{peta_penghuni[k]['nama']} — {peta_penghuni[k]['telepon']}"
            ),
            key="sewa_penghuni_baru",
        )
        id_kamar = st.selectbox(
            "Kamar",
            list(peta_kamar),
            format_func=lambda k: (
                f"{peta_kamar[k]['nomor_kamar']} — Tipe {peta_kamar[k]['tipe']} — "
                f"{rupiah(peta_kamar[k]['harga_bulanan'])} "
                f"({peta_kamar[k]['status']})"
            ),
            key="sewa_kamar_baru",
        )

        mulai = st.date_input(
            "Tanggal mulai",
            value=today(),
            format="DD/MM/YYYY",
            key="sewa_mulai_baru",
        )
        selesai = st.date_input(
            "Tanggal selesai",
            value=today() + timedelta(days=89),
            format="DD/MM/YYYY",
            key="sewa_selesai_baru",
        )
        durasi = duration_months(mulai, selesai)
        st.caption(
            f"Perkiraan durasi: **{durasi} bulan** · "
            f"{fmt_date(mulai)} s.d. {fmt_date(selesai)}"
        )

        if st.button("Simpan Sewa", type="primary", use_container_width=True):
            try:
                with db() as conn:
                    id_sewa = repo.create_sewa(
                        conn, id_penghuni, id_kamar, mulai, selesai
                    )
                svc.sync_statuses()
                flash(
                    "success",
                    f"Sewa {id_sewa} berhasil dibuat. Harga sewa disalin dari "
                    f"harga kamar saat ini.",
                )
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))

    with kanan:
        kamar = peta_kamar[id_kamar]
        meta = ROOM_TYPES.get(str(kamar["tipe"]), {})
        st.markdown(
            f"""
            <div class="ks-card">
                <div class="ks-card-head">
                    <div class="ks-card-title">Kamar {escape(str(kamar['nomor_kamar']))}</div>
                    {badge(str(kamar['status']))}
                </div>
                <div style="font-size:1.5rem;font-weight:800;color:#2B1B27">
                    {rupiah(kamar['harga_bulanan'])}
                    <span style="font-size:.8rem;font-weight:600;color:#7A6B74">
                        / bulan</span>
                </div>
                <div style="font-size:.84rem;color:#7A6B74;margin-top:8px">
                    {escape(str(kamar['fasilitas']))}
                </div>
                <div style="margin-top:14px;padding-top:14px;
                            border-top:1px solid #EADFE6;font-size:.8rem;
                            color:#7A6B74">
                    Tipe {escape(str(kamar['tipe']))} ·
                    {escape(str(meta.get('label', '')))}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        with db() as conn:
            riwayat = repo.sewa_per_kamar(conn, id_kamar)
        st.markdown("###### Jadwal kamar ini")
        if not riwayat:
            st.caption("Belum ada sewa pada kamar ini.")
        else:
            baris = []
            for r in riwayat:
                baris.append(
                    [
                        strong(str(r["id_sewa"])),
                        escape(str(r["nama_penghuni"])),
                        f"{fmt_date_short(r['tanggal_mulai'])} – "
                        f"{fmt_date_short(r['tanggal_selesai'])}",
                        badge(str(r["status_sewa"])),
                    ]
                )
            table(
                ["ID", "Penghuni", "Periode", "Status"],
                baris,
                empty_title="Belum ada jadwal",
            )
        st.info(
            "Sistem menolak sewa yang bertabrakan: tanggal mulai baru ≤ "
            "tanggal selesai lama dan tanggal selesai baru ≥ tanggal mulai lama.",
            icon="ℹ️",
        )


def _akhiri_hapus() -> None:
    with db() as conn:
        rows = repo.list_sewa(conn)

    if not rows:
        empty_state(
            "Belum ada data sewa",
            "Buat sewa terlebih dahulu pada tab Buat Sewa.",
        )
        return

    peta = {str(r["id_sewa"]): r for r in rows}
    id_sewa = st.selectbox(
        "Pilih sewa",
        list(peta),
        format_func=lambda k: (
            f"{k} — {peta[k]['nama_penghuni']} — Kamar "
            f"{peta[k]['nomor_kamar']} — {peta[k]['status_sewa']}"
        ),
        key="sewa_pilih_ubah",
    )
    sewa = peta[id_sewa]

    st.markdown(
        f"""
        <div class="ks-card">
            <div class="ks-card-head">
                <div class="ks-card-title">Sewa {escape(id_sewa)}</div>
                {badge(str(sewa['status_sewa']))}
            </div>
            <div style="font-size:.88rem;color:#2B1B27;line-height:1.9">
                <b>{escape(str(sewa['nama_penghuni']))}</b> ·
                Kamar {escape(str(sewa['nomor_kamar']))}<br>
                {fmt_date(sewa['tanggal_mulai'])} s.d.
                {fmt_date(sewa['tanggal_selesai'])}
                ({sewa['durasi']} bulan)<br>
                Harga {rupiah(sewa['harga_bulanan'])} / bulan ·
                Sudah dibayar {rupiah(sewa['total_dibayar'])}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.write("")
    if sewa["status_sewa"] == "Aktif":
        st.markdown("#### Akhiri sewa")
        st.caption(
            "Gunakan bila penghuni berhenti lebih awal. Tanggal dan riwayat "
            "pembayaran tetap tersimpan; status sewa diubah menjadi Selesai."
        )
        yakin_akhir = st.checkbox(
            "Saya yakin ingin menandai sewa ini Selesai",
            key=f"akhir_yakin_{id_sewa}",
        )
        if st.button(
            "Tandai Selesai",
            type="primary",
            disabled=not yakin_akhir,
            key=f"akhir_sewa_{id_sewa}",
        ):
            try:
                with db() as conn:
                    repo.akhiri_sewa(conn, id_sewa)
                svc.sync_statuses()
                flash("success", f"Sewa {id_sewa} ditandai Selesai.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))

    st.divider()
    st.markdown("#### Hapus sewa")
    with db() as conn:
        jumlah_bayar = repo.count_pembayaran(conn, id_sewa)

    if jumlah_bayar:
        st.warning(
            f"Sewa {id_sewa} punya {jumlah_bayar} pembayaran sehingga tidak "
            "bisa dihapus. Hapus pembayaran terlebih dahulu bila memang salah "
            "catat.",
            icon="🔒",
        )
    else:
        yakin_hapus = st.checkbox(
            "Saya yakin ingin menghapus sewa ini",
            key=f"hapus_yakin_sewa_{id_sewa}",
        )
        if st.button(
            "Hapus Sewa",
            type="primary",
            disabled=not yakin_hapus,
            key=f"hapus_sewa_{id_sewa}",
        ):
            try:
                with db() as conn:
                    repo.delete_sewa(conn, id_sewa)
                svc.sync_statuses()
                flash("success", f"Sewa {id_sewa} berhasil dihapus.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))
