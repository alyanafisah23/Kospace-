/* ==========================================================================
   KOSPACE — interaksi landing page (landing.js)
   Header lengket, menu seluler, animasi masuk, penghitung angka, dan
   penyegaran angka ketersediaan dari data demo.
   ========================================================================== */
(function () {
  'use strict';

  const $ = (selector, root) => (root || document).querySelector(selector);
  const $$ = (selector, root) => Array.prototype.slice.call((root || document).querySelectorAll(selector));
  const K = window.KOS;
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* -----------------------------------------------------------------------
     Header lengket
     ----------------------------------------------------------------------- */
  const header = $('.site-header');
  if (header) {
    const syncHeader = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
    syncHeader();
    window.addEventListener('scroll', syncHeader, { passive: true });
  }

  /* -----------------------------------------------------------------------
     Menu seluler
     ----------------------------------------------------------------------- */
  const navToggle = $('.nav__toggle');
  const navLinks = $('#primary-nav');

  function closeNav() {
    if (!navLinks || !navToggle) return;
    navLinks.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
  }

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const open = navLinks.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    navLinks.addEventListener('click', (event) => {
      if (event.target.closest('a')) closeNav();
    });

    document.addEventListener('click', (event) => {
      if (!navLinks.contains(event.target) && !navToggle.contains(event.target)) closeNav();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeNav();
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 960) closeNav();
    });
  }

  /* -----------------------------------------------------------------------
     Animasi masuk saat elemen terlihat
     ----------------------------------------------------------------------- */
  const revealItems = $$('[data-reveal]');
  revealItems.forEach((element) => element.classList.add('reveal'));

  if ('IntersectionObserver' in window && !reduceMotion) {
    const revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );
    revealItems.forEach((element) => revealObserver.observe(element));
  } else {
    revealItems.forEach((element) => element.classList.add('is-visible'));
  }

  /* -----------------------------------------------------------------------
     Penghitung angka
     ----------------------------------------------------------------------- */
  function setCounter(element) {
    const target = Number(element.getAttribute('data-count') || 0);
    const suffix = element.getAttribute('data-suffix') || '';
    if (reduceMotion) {
      element.textContent = target + suffix;
      return;
    }
    const duration = 900;
    const start = performance.now();
    function frame(now) {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      element.textContent = Math.round(target * eased) + suffix;
      if (progress < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  const counters = $$('[data-count]');
  if ('IntersectionObserver' in window && !reduceMotion) {
    const counterObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          setCounter(entry.target);
          counterObserver.unobserve(entry.target);
        });
      },
      { threshold: 0.5 }
    );
    counters.forEach((element) => counterObserver.observe(element));
  } else {
    counters.forEach((element) => {
      element.textContent = element.getAttribute('data-count') + (element.getAttribute('data-suffix') || '');
    });
  }

  /* -----------------------------------------------------------------------
     Angka ketersediaan dari data demo
     ----------------------------------------------------------------------- */
  function paintData() {
    if (!K) return;

    let summary;
    try {
      summary = K.summary();
    } catch (error) {
      return;
    }

    $$('[data-occupancy]').forEach((element) => {
      element.textContent = summary.occupancyPct + '%';
    });

    $$('[data-hero-occupied]').forEach((element) => {
      element.textContent = summary.occupied;
    });
    $$('[data-hero-available]').forEach((element) => {
      element.textContent = summary.available;
    });
    $$('[data-hero-active]').forEach((element) => {
      element.textContent = summary.activeLeases;
    });
    $$('[data-hero-arrears]').forEach((element) => {
      element.textContent = summary.arrearsCount;
    });
    $$('[data-hero-month]').forEach((element) => {
      element.textContent = K.fmtRupiahShort(summary.monthPaid);
    });

    // Donut pada mock dashboard.
    const donut = $('[data-donut]');
    if (donut) {
      const radius = Number(donut.getAttribute('r')) || 46;
      const circumference = 2 * Math.PI * radius;
      donut.setAttribute('stroke-dasharray', circumference.toFixed(2));
      donut.setAttribute('stroke-dashoffset', (circumference * (1 - summary.occupancyPct / 100)).toFixed(2));
    }

    ['A', 'B', 'C'].forEach((type) => {
      const data = summary.byType[type];
      if (!data) return;
      const width = data.pct + '%';
      $$('[data-room-fill="' + type + '"]').forEach((element) => {
        element.style.width = width;
      });
      $$('[data-hero-bar="' + type + '"]').forEach((element) => {
        element.style.width = width;
      });
      $$('[data-room-count="' + type + '"]').forEach((element) => {
        element.textContent = data.occupied + '/' + data.total + ' terisi';
      });
      $$('[data-room-avail="' + type + '"]').forEach((element) => {
        element.textContent = data.available + ' tersedia';
      });
    });

    $$('[data-preview-total]').forEach((element) => {
      element.textContent = summary.totalRooms;
    });
    $$('[data-preview-available]').forEach((element) => {
      element.textContent = summary.available;
    });
    $$('[data-preview-occupied]').forEach((element) => {
      element.textContent = summary.occupied;
    });
    $$('[data-preview-arrears]').forEach((element) => {
      element.textContent = summary.arrearsCount;
    });
    $$('[data-preview-month]').forEach((element) => {
      element.textContent = K.fmtRupiahShort(summary.monthPaid);
    });

    $$('[data-total-rooms]').forEach((element) => {
      element.textContent = summary.totalRooms;
    });
    $$('[data-total-residents]').forEach((element) => {
      element.textContent = K.residents().length;
    });
    $$('[data-total-leases]').forEach((element) => {
      element.textContent = K.leases().length;
    });
    $$('[data-total-payments]').forEach((element) => {
      element.textContent = K.payments().length;
    });
  }

  paintData();

  /* -----------------------------------------------------------------------
     Tahun berjalan di footer
     ----------------------------------------------------------------------- */
  $$('[data-year]').forEach((element) => {
    element.textContent = new Date().getFullYear();
  });
})();
