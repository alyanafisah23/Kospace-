"""Repository data penghuni."""

from __future__ import annotations

import sqlite3

from ..utils import next_id
from ..validators import ValidationError, validate_penghuni

_SELECT_PENGHUNI = """
SELECT p.*,
       (
           SELECT COUNT(*) FROM sewa s WHERE s.id_penghuni = p.id_penghuni
       ) AS jumlah_sewa,
       (
           SELECT k.nomor_kamar
           FROM sewa s
           JOIN kamar k ON k.id_kamar = s.id_kamar
           WHERE s.id_penghuni = p.id_penghuni
             AND s.status_sewa = 'Aktif'
             AND date('now', 'localtime') BETWEEN s.tanggal_mulai AND s.tanggal_selesai
           ORDER BY s.tanggal_mulai DESC
           LIMIT 1
       ) AS kamar_aktif
FROM penghuni p
"""


def list_penghuni(
    conn: sqlite3.Connection, q: str | None = None
) -> list[sqlite3.Row]:
    sql = _SELECT_PENGHUNI
    params: list[object] = []
    if q:
        sql += " WHERE p.nama LIKE ? OR p.telepon LIKE ? OR p.alamat LIKE ?"
        pola = f"%{q.strip()}%"
        params.extend([pola, pola, pola])
    sql += " ORDER BY p.nama COLLATE NOCASE"
    return conn.execute(sql, params).fetchall()


def get_penghuni(conn: sqlite3.Connection, id_penghuni: str) -> sqlite3.Row | None:
    return conn.execute(
        _SELECT_PENGHUNI + " WHERE p.id_penghuni = ?", (id_penghuni,)
    ).fetchone()


def create_penghuni(
    conn: sqlite3.Connection,
    nama: str,
    telepon: str,
    telepon_ortu: str,
    alamat: str,
) -> str:
    nama, telepon, telepon_ortu, alamat = validate_penghuni(
        nama, telepon, telepon_ortu, alamat
    )
    id_penghuni = next_id(conn, "penghuni", "id_penghuni", "P")
    conn.execute(
        """
        INSERT INTO penghuni (id_penghuni, nama, telepon, telepon_ortu, alamat)
        VALUES (?, ?, ?, ?, ?)
        """,
        (id_penghuni, nama, telepon, telepon_ortu, alamat),
    )
    return id_penghuni


def update_penghuni(
    conn: sqlite3.Connection,
    id_penghuni: str,
    nama: str,
    telepon: str,
    telepon_ortu: str,
    alamat: str,
) -> None:
    if not get_penghuni(conn, id_penghuni):
        raise ValidationError("Penghuni tidak ditemukan.")
    nama, telepon, telepon_ortu, alamat = validate_penghuni(
        nama, telepon, telepon_ortu, alamat
    )
    conn.execute(
        """
        UPDATE penghuni
        SET nama = ?, telepon = ?, telepon_ortu = ?, alamat = ?
        WHERE id_penghuni = ?
        """,
        (nama, telepon, telepon_ortu, alamat, id_penghuni),
    )


def has_riwayat_sewa(conn: sqlite3.Connection, id_penghuni: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sewa WHERE id_penghuni = ? LIMIT 1", (id_penghuni,)
    ).fetchone()
    return row is not None


def delete_penghuni(conn: sqlite3.Connection, id_penghuni: str) -> None:
    penghuni = get_penghuni(conn, id_penghuni)
    if not penghuni:
        raise ValidationError("Penghuni tidak ditemukan.")
    # B10 — penghuni dengan riwayat sewa tidak boleh dihapus
    if has_riwayat_sewa(conn, id_penghuni):
        raise ValidationError(
            f"Penghuni {penghuni['nama']} tidak bisa dihapus karena sudah punya "
            "catatan sewa. Riwayatnya tetap bisa ditelusuri lewat menu Riwayat "
            "(aturan B10)."
        )
    conn.execute("DELETE FROM penghuni WHERE id_penghuni = ?", (id_penghuni,))
