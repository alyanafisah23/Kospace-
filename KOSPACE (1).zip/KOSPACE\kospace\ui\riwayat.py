"""Halaman Riwayat dan detail transaksi."""

from __future__ import annotations

import csv
import io
from html import escape

import streamlit as st

from ..config import MONTHS_ID
from ..database import db
from ..repositories import pembayaran as repo_bayar
from ..repositories import penghuni as repo_penghuni
from ..repositories import sewa as repo_sewa
from ..utils import fmt_date, rupiah
from .components import (
    badge,
    empty_state,
    kpi_card,
    page_header,
    strong,
    table,
)


def render() -> None:
    page_header(
        "Penelusuran",
        "Riwayat",
        "Telusuri riwayat sewa dan pembayaran yang tersimpan, lalu unduh "
        "rekapnya untuk arsip pemilik kos.",
    )

    with db() as conn:
        penghuni_rows = repo_penghuni.list_penghuni(conn)
        semua_bayar = repo_bayar.list_pembayaran(conn)

    if not semua_bayar and not penghuni_rows:
        empty_state(
            "Belum ada riwayat",
            "Riwayat akan muncul setelah ada data sewa dan pembayaran.",
        )
        return

    peta_penghuni = {str(r["id_penghuni"]): str(r["nama"]) for r in penghuni_rows}
    tahun_tersedia = sorted(
        {int(r["periode_tahun"]) for r in semua_bayar}, reverse=True
    )

    kiri, tengah, kanan = st.columns([1.2, 1.0, 2.0])
    id_penghuni = kiri.selectbox(
        "Penghuni",
        ["Semua"] + list(peta_penghuni),
        format_func=lambda k: "Semua penghuni" if k == "Semua" else peta_penghuni[k],
        key="riwayat_penghuni",
    )
    tahun = tengah.selectbox(
        "Tahun",
        ["Semua"] + tahun_tersedia,
        key="riwayat_tahun",
    )
    q = kanan.text_input(
        "Cari riwayat",
        placeholder="Nama, nomor kamar, atau ID sewa…",
        key="riwayat_cari",
    )

    with db() as conn:
        leases = repo_sewa.list_sewa(
            conn,
            q=q,
            id_penghuni=None if id_penghuni == "Semua" else id_penghuni,
        )

    tahun_int = None if tahun == "Semua" else int(tahun)
    if tahun_int is not None:
        leases = [
            s
            for s in leases
            if int(str(s["tanggal_mulai"])[:4])
            <= tahun_int
            <= int(str(s["tanggal_selesai"])[:4])
        ]

    if not leases:
        empty_state(
            "Riwayat tidak ditemukan",
            "Coba ubah filter penghuni, tahun, atau kata kunci pencarian.",
        )
        return

    # ------------------------------------------------------------------
    # Ringkasan
    # ------------------------------------------------------------------
    total_sewa = len(leases)
    total_bayar = 0
    total_periode = 0
    semua_untuk_export: list[list[str]] = []

    for sewa in leases:
        with db() as conn:
            bayar_rows = repo_bayar.list_pembayaran(
                conn, id_sewa=str(sewa["id_sewa"]), tahun=tahun_int
            )
        total_bayar += sum(int(b["nominal"]) for b in bayar_rows)
        total_periode += len(bayar_rows)
        for b in bayar_rows:
            semua_untuk_export.append(
                [
                    str(b["id_pembayaran"]),
                    str(b["id_sewa"]),
                    str(b["nama_penghuni"]),
                    str(b["nomor_kamar"]),
                    f"{MONTHS_ID[int(b['periode_bulan']) - 1]} {b['periode_tahun']}",
                    str(int(b["nominal"])),
                    str(b["tanggal_bayar"]),
                    str(b["status_pembayaran"]),
                ]
            )

    kolom = st.columns(3)
    with kolom[0]:
        kpi_card(
            "Sewa Ditampilkan",
            str(total_sewa),
            "Kontrak pada filter ini",
            tone="plum",
            icon="⇄",
        )
    with kolom[1]:
        kpi_card(
            "Total Pembayaran",
            rupiah(total_bayar),
            f"{total_periode} periode tercatat",
            tone="green",
            icon="Rp",
        )
    with kolom[2]:
        kpi_card(
            "Rata-rata / Sewa",
            rupiah(total_bayar / total_sewa if total_sewa else 0),
            "Pembayaran per kontrak",
            tone="rose",
            icon="≈",
        )

    st.write("")

    # ------------------------------------------------------------------
    # Unduh CSV
    # ------------------------------------------------------------------
    if semua_untuk_export:
        buffer = io.StringIO()
        writer = csv.writer(buffer, delimiter=";")
        writer.writerow(
            [
                "ID Pembayaran",
                "ID Sewa",
                "Penghuni",
                "Kamar",
                "Periode",
                "Nominal",
                "Tanggal Bayar",
                "Status",
            ]
        )
        writer.writerows(semua_untuk_export)
        st.download_button(
            "Unduh Rekap Pembayaran (CSV)",
            data="\ufeff" + buffer.getvalue(),
            file_name="kospace_riwayat_pembayaran.csv",
            mime="text/csv",
            use_container_width=False,
        )

    st.write("")

    # ------------------------------------------------------------------
    # Daftar riwayat per sewa
    # ------------------------------------------------------------------
    for sewa in leases:
        id_sewa = str(sewa["id_sewa"])
        with db() as conn:
            bayar_rows = repo_bayar.list_pembayaran(
                conn, id_sewa=id_sewa, tahun=tahun_int
            )
        subtotal = sum(int(b["nominal"]) for b in bayar_rows)

        with st.container(border=True):
            kiri, tengah, kanan = st.columns([1.6, 1.3, 1.0])
            with kiri:
                st.markdown(
                    f"**{escape(id_sewa)}** &nbsp; {badge(str(sewa['status_sewa']))}",
                    unsafe_allow_html=True,
                )
                st.caption(
                    f"{sewa['nama_penghuni']} · Kamar {sewa['nomor_kamar']} "
                    f"(Tipe {sewa['tipe']})"
                )
            with tengah:
                st.markdown(
                    f"{fmt_date(sewa['tanggal_mulai'])} – "
                    f"{fmt_date(sewa['tanggal_selesai'])}"
                )
                st.caption(
                    f"{sewa['durasi']} bulan · "
                    f"{rupiah(sewa['harga_bulanan'])} / bulan"
                )
            with kanan:
                st.markdown(f"**{rupiah(subtotal)}**")
                st.caption(f"{len(bayar_rows)} pembayaran pada filter ini")

            with st.expander(f"Detail pembayaran ({len(bayar_rows)})"):
                if not bayar_rows:
                    st.caption("Belum ada pembayaran pada periode filter ini.")
                else:
                    isi = []
                    for b in bayar_rows:
                        isi.append(
                            [
                                strong(str(b["id_pembayaran"])),
                                escape(
                                    f"{MONTHS_ID[int(b['periode_bulan']) - 1]} "
                                    f"{b['periode_tahun']}"
                                ),
                                rupiah(b["nominal"]),
                                fmt_date(b["tanggal_bayar"]),
                                badge(str(b["status_pembayaran"])),
                            ]
                        )
                    table(
                        ["ID", "Periode", "Nominal", "Tanggal Bayar", "Status"],
                        isi,
                    )

    st.caption(
        "Tanggal ditampilkan DD-MM-YYYY. Data tersimpan di database sebagai "
        "YYYY-MM-DD."
    )
