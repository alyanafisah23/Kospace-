"""Halaman-halaman antarmuka KOSPACE."""
