"""Repository data sewa."""

from __future__ import annotations

import sqlite3
from datetime import date

from ..utils import duration_months, next_id, parse_date
from ..validators import (
    ValidationError,
    validate_jadwal_kamar,
    validate_sewa_dates,
)

_SELECT_SEWA = """
SELECT s.*,
       p.nama AS nama_penghuni,
       p.telepon AS telepon_penghuni,
       k.nomor_kamar,
       k.tipe,
       (
           SELECT COALESCE(SUM(b.nominal), 0)
           FROM pembayaran b WHERE b.id_sewa = s.id_sewa
       ) AS total_dibayar,
       (
           SELECT COUNT(*) FROM pembayaran b WHERE b.id_sewa = s.id_sewa
       ) AS jumlah_pembayaran
FROM sewa s
JOIN penghuni p ON p.id_penghuni = s.id_penghuni
JOIN kamar k ON k.id_kamar = s.id_kamar
"""


def list_sewa(
    conn: sqlite3.Connection,
    status: str | None = None,
    q: str | None = None,
    id_penghuni: str | None = None,
    id_kamar: str | None = None,
) -> list[sqlite3.Row]:
    sql = _SELECT_SEWA + " WHERE 1 = 1"
    params: list[object] = []
    if status and status != "Semua":
        sql += " AND s.status_sewa = ?"
        params.append(status)
    if id_penghuni:
        sql += " AND s.id_penghuni = ?"
        params.append(id_penghuni)
    if id_kamar:
        sql += " AND s.id_kamar = ?"
        params.append(id_kamar)
    if q:
        pola = f"%{q.strip()}%"
        sql += (
            " AND (p.nama LIKE ? OR k.nomor_kamar LIKE ? OR s.id_sewa LIKE ?)"
        )
        params.extend([pola, pola, pola])
    sql += " ORDER BY CASE s.status_sewa WHEN 'Aktif' THEN 0 ELSE 1 END,"
    sql += " s.tanggal_mulai DESC"
    return conn.execute(sql, params).fetchall()


def get_sewa(conn: sqlite3.Connection, id_sewa: str) -> sqlite3.Row | None:
    return conn.execute(
        _SELECT_SEWA + " WHERE s.id_sewa = ?", (id_sewa,)
    ).fetchone()


def create_sewa(
    conn: sqlite3.Connection,
    id_penghuni: str,
    id_kamar: str,
    tanggal_mulai: date,
    tanggal_selesai: date,
    durasi: int | None = None,
) -> str:
    penghuni = conn.execute(
        "SELECT nama FROM penghuni WHERE id_penghuni = ?", (id_penghuni,)
    ).fetchone()
    if not penghuni:
        raise ValidationError("Penghuni tidak ditemukan.")

    kamar = conn.execute(
        "SELECT * FROM kamar WHERE id_kamar = ?", (id_kamar,)
    ).fetchone()
    if not kamar:
        raise ValidationError("Kamar tidak ditemukan.")

    validate_sewa_dates(tanggal_mulai, tanggal_selesai)
    validate_jadwal_kamar(conn, id_kamar, tanggal_mulai, tanggal_selesai)

    durasi = int(durasi or 0) or duration_months(tanggal_mulai, tanggal_selesai)
    if durasi <= 0:
        raise ValidationError("Durasi sewa harus lebih dari 0 bulan.")

    id_sewa = next_id(conn, "sewa", "id_sewa", "S")
    conn.execute(
        """
        INSERT INTO sewa (
            id_sewa, id_penghuni, id_kamar, tanggal_mulai, tanggal_selesai,
            durasi, harga_bulanan, status_sewa
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Aktif')
        """,
        (
            id_sewa,
            id_penghuni,
            id_kamar,
            parse_date(tanggal_mulai).isoformat(),
            parse_date(tanggal_selesai).isoformat(),
            durasi,
            int(kamar["harga_bulanan"]),
        ),
    )
    return id_sewa


def akhiri_sewa(conn: sqlite3.Connection, id_sewa: str) -> None:
    sewa = get_sewa(conn, id_sewa)
    if not sewa:
        raise ValidationError("Sewa tidak ditemukan.")
    if sewa["status_sewa"] == "Selesai":
        raise ValidationError("Sewa ini sudah berstatus Selesai.")
    conn.execute(
        "UPDATE sewa SET status_sewa = 'Selesai' WHERE id_sewa = ?", (id_sewa,)
    )


def count_pembayaran(conn: sqlite3.Connection, id_sewa: str) -> int:
    return int(
        conn.execute(
            "SELECT COUNT(*) FROM pembayaran WHERE id_sewa = ?", (id_sewa,)
        ).fetchone()[0]
    )


def delete_sewa(conn: sqlite3.Connection, id_sewa: str) -> None:
    sewa = get_sewa(conn, id_sewa)
    if not sewa:
        raise ValidationError("Sewa tidak ditemukan.")
    if count_pembayaran(conn, id_sewa) > 0:
        raise ValidationError(
            f"Sewa {id_sewa} tidak bisa dihapus karena sudah punya pembayaran. "
            "Hapus pembayaran terlebih dahulu bila memang salah catat."
        )
    conn.execute("DELETE FROM sewa WHERE id_sewa = ?", (id_sewa,))


def sewa_per_kamar(conn: sqlite3.Connection, id_kamar: str) -> list[sqlite3.Row]:
    return conn.execute(
        _SELECT_SEWA + " WHERE s.id_kamar = ? ORDER BY s.tanggal_mulai DESC",
        (id_kamar,),
    ).fetchall()


def hitung_sewa_aktif(conn: sqlite3.Connection) -> int:
    return int(
        conn.execute(
            "SELECT COUNT(*) FROM sewa WHERE status_sewa = 'Aktif'"
        ).fetchone()[0]
    )
