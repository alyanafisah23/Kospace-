# RANCANGAN SISTEM ADMINISTRASI PENGELOLAAN KOS — KOSPACE

| | |
|---|---|
| **Mata kuliah** | Pemrograman Bisnis & Perancangan Sistem Administrasi |
| **Dosen pengampu** | Dwi Budi Santoso, S.Kom., M.Kom. |
| **Kelompok** | 4 |
| **Anggota** | Alya Nafisah (4.52.24.3.02) · Marensya Aurellya (4.52.24.3.15) · Permata Rayya A. A. (4.52.24.3.21) · Shintia Nova P. A. (4.52.24.3.25) |
| **Produk** | KOSPACE — Sistem Administrasi Pengelolaan Kos |
| **Versi dokumen** | 1.0 |
| **Status** | Rancangan + implementasi siap dijalankan di VS Code |

---

## 1. Ringkasan Eksekutif

KOSPACE adalah aplikasi web lokal untuk membantu **satu pemilik kos putri**
mengelola administrasi 25 kamar: data kamar, identitas penghuni, masa sewa,
dan pembayaran bulanan. Sistem menggantikan pencatatan terpisah di buku dan
WhatsApp dengan satu database terstruktur yang bisa dicari, diperiksa
riwayatnya, dan diunduh rekapnya.

Aplikasi dibangun dengan **Python 3.10+, Streamlit, dan SQLite**, dijalankan
dari terminal VS Code, dan menyimpan data pada `data/kospace.db`. Seluruh
antarmuka berbahasa Indonesia.

**Nilai utama yang diberikan:**

1. Satu sumber data untuk kamar, penghuni, sewa, dan pembayaran.
2. Status kamar dan sewa diperbarui otomatis dari tanggal.
3. Jadwal sewa yang bertabrakan ditolak sebelum disimpan.
4. Pembayaran terhubung ke sewa dan periode, sehingga riwayat mudah ditelusuri.
5. Aturan bisnis B01, B06, B08, B10, dan B14 dijaga di tiga lapisan:
   antarmuka, validasi Python, dan constraint SQLite.

---

## 2. Latar Belakang dan Permasalahan

Pengelolaan kos mencakup pencatatan kamar, penghuni, sewa, dan pembayaran.
Bila data dicatat sendiri di buku dan WhatsApp, informasi terpisah-pisah dan
sulit dicocokkan. Pemilik juga berisiko salah menentukan kamar kosong atau
menerima sewa dengan jadwal yang bertabrakan.

| # | Permasalahan | Akibat | Solusi KOSPACE |
|---|---|---|---|
| 1 | Data kamar, penghuni, dan sewa tercatat di buku dan WhatsApp | Pemilik sulit mencari dan mencocokkan data | Semua data disimpan rapi dalam satu database dan mudah dicari |
| 2 | Ketersediaan kamar dan masa sewa tidak tercatat di satu tempat | Salah menentukan kamar kosong; jadwal sewa bertabrakan | Status kamar otomatis; bentrok jadwal dideteksi sebelum disimpan |
| 3 | Pembayaran tidak terhubung ke data sewa | Pemeriksaan pembayaran dan riwayat memakan waktu | Pembayaran per periode terhubung ke sewa; status otomatis; riwayat bisa ditelusuri |

---

## 3. Tujuan dan Indikator Keberhasilan

| # | Tujuan | Indikator keberhasilan |
|---|---|---|
| 1 | Mempermudah pengelolaan data kamar dan penghuni | Tambah/ubah/hapus data selesai dari satu layar tanpa file terpisah |
| 2 | Memeriksa ketersediaan kamar secara otomatis | Dashboard menampilkan jumlah tersedia/ditempati yang selalu konsisten dengan sewa |
| 3 | Mencatat sewa dan masa sewa secara rapi | Setiap sewa punya tanggal mulai, selesai, durasi, dan harga yang tersimpan |
| 4 | Mencatat pembayaran tiap bulan beserta status | Setiap pembayaran terhubung ke satu sewa dan satu periode |
| 5 | Mencegah jadwal sewa bertabrakan | Sistem menolak sewa yang overlap pada kamar yang sama |
| 6 | Menjaga riwayat sewa dan pembayaran | Data dengan riwayat tidak bisa dihapus; rekap bisa diunduh CSV |

---

## 4. Pengguna, Ruang Lingkup, dan Batasan

### 4.1 Pengguna

| Pengguna | Peran |
|---|---|
| Pemilik kos | Satu-satunya pengguna. Mengelola seluruh data lewat sistem. |
| Penghuni | Tidak menggunakan sistem. Tidak ada akses langsung. |

### 4.2 Ruang lingkup

- Dashboard ringkasan data kos.
- Tambah, lihat, ubah, dan hapus data kamar, penghuni, sewa, dan pembayaran.
- Detail transaksi dan riwayat.
- Pencarian dan filter data.
- Unduh rekap pembayaran (CSV).

### 4.3 Batasan (sesuai dokumen asli)

- Belum ada login dan pemesanan mandiri.
- Belum ada pembayaran online, deposit, dan token listrik.
- Belum ada kuitansi, pengingat WhatsApp, dan deployment ke internet.
- Sistem dijalankan lokal lewat terminal VS Code.

---

## 5. Fitur dan Prioritas

| Fitur | Prioritas | Isi | Status |
|---|---|---|---|
| Dashboard Ringkasan | Pendukung | Jumlah kamar, tersedia/ditempati, sewa aktif, pembayaran bulan ini, tunggakan, okupansi per tipe | ✅ |
| Pengelolaan Kamar | Utama | Nomor, tipe, harga, fasilitas; status otomatis; cari & filter | ✅ |
| Pengelolaan Penghuni | Utama | Nama, telepon, telepon orang tua, alamat; cari | ✅ |
| Pengelolaan Penyewaan | Utama | Hubungkan penghuni–kamar, tanggal, durasi, harga salinan, deteksi bentrok | ✅ |
| Pencatatan Pembayaran | Utama | Pembayaran per periode, status Lunas, validasi nominal & periode ganda | ✅ |
| Riwayat dan Detail Transaksi | Pendukung | Riwayat per sewa, detail pembayaran, ekspor CSV | ✅ |
| Tagihan per Sewa | Pendukung | Jadwal tagihan bulanan, status Belum Dibayar/Terlambat otomatis | ✅ |

---

## 6. Arsitektur Sistem

### 6.1 Teknologi

| Lapisan | Teknologi | Alasan |
|---|---|---|
| Bahasa | Python 3.10+ | Sesuai ketentuan tugas dan mudah dibaca |
| Antarmuka web | Streamlit ≥ 1.37 | Cepat membuat UI data, berjalan lokal di browser |
| Database | SQLite (modul `sqlite3` bawaan) | Tanpa server, satu file, cocok untuk satu pengguna |
| Format tanggal | `datetime` | Tampilan DD-MM-YYYY, penyimpanan YYYY-MM-DD |
| Ekspor | CSV (`csv` + `io`) | Rekap bisa dibuka di Excel |
| Pengujian | `unittest` bawaan Python | Tidak menambah dependensi |

### 6.2 Diagram arsitektur

```mermaid
flowchart LR
    P["Pemilik Kos<br/>(browser)"] -->|HTTP lokal :8501| A["app.py<br/>navigasi + tema"]
    A --> UI["kospace/ui/<br/>dashboard · kamar · penghuni<br/>sewa · pembayaran · riwayat"]
    UI --> C["kospace/ui/components.py<br/>kartu, tabel, badge, CSS"]
    UI --> S["kospace/services/<br/>ringkasan + sync status"]
    UI --> R["kospace/repositories/<br/>kamar · penghuni · sewa · pembayaran"]
    S --> R
    R --> V["kospace/validators.py<br/>B01 · B06 · B08 · B10 · B14"]
    R --> D[("SQLite<br/>data/kospace.db")]
    A --> D
```

### 6.3 Alur satu kali rerun Streamlit

1. `app.py` menyiapkan tema dan memanggil `init_db()` (idempoten).
2. `sync_statuses()` menyelesaikan sewa yang sudah lewat dan menghitung ulang
   status kamar.
3. Sidebar menampilkan navigasi; halaman aktif dipanggil.
4. Halaman membaca data lewat repository, menampilkan komponen, dan menangani
   aksi pengguna.
5. Aksi tulis dibungkus `with db():` — commit bila sukses, rollback bila gagal.
6. Pesan sukses/gagal disimpan di `st.session_state` lalu ditampilkan setelah
   rerun.

### 6.4 Struktur folder

```text
kospace/
├─ app.py                       # Entry point + dispatch halaman
├─ requirements.txt             # streamlit>=1.37,<2.0
├─ README.md                    # Panduan cepat
├─ .gitignore
├─ .streamlit/
│  └─ config.toml               # Tema + file watcher dimatikan
├─ .vscode/
│  ├─ launch.json               # Debug Streamlit / seed / test
│  ├─ settings.json
│  └─ extensions.json
├─ docs/
│  └─ RANCANGAN.md              # Dokumen ini
├─ kospace/
│  ├─ config.py                 # Konstanta, tipe kamar, navigasi
│  ├─ database.py               # Skema, koneksi, seed 25 kamar
│  ├─ utils.py                  # Tanggal, rupiah, periode, ID otomatis
│  ├─ validators.py             # Aturan bisnis + validasi input
│  ├─ seed_demo.py              # Data contoh opsional
│  ├─ repositories/
│  │  ├─ kamar.py
│  │  ├─ penghuni.py
│  │  ├─ sewa.py
│  │  └─ pembayaran.py
│  ├─ services/
│  │  └─ dashboard.py           # sync status + ringkasan
│  └─ ui/
│     ├─ components.py          # Sistem desain + komponen
│     ├─ dashboard.py
│     ├─ kamar.py
│     ├─ penghuni.py
│     ├─ sewa.py
│     ├─ pembayaran.py
│     └─ riwayat.py
├─ tests/
│  └─ test_business_rules.py    # 14 unit test
└─ data/
   └─ kospace.db                # Dibuat otomatis
```

---

## 7. Rancangan Data

### 7.1 ERD

```mermaid
erDiagram
    KAMAR ||--o{ SEWA : "disewa dalam"
    PENGHUNI ||--o{ SEWA : "menyewa"
    SEWA ||--o{ PEMBAYARAN : "memiliki"

    KAMAR {
        TEXT id_kamar PK
        TEXT nomor_kamar UK "A01, B01, C01"
        TEXT tipe "A / B / C"
        INTEGER harga_bulanan "> 0"
        TEXT fasilitas
        TEXT status "Tersedia / Ditempati"
    }

    PENGHUNI {
        TEXT id_penghuni PK
        TEXT nama
        TEXT telepon
        TEXT telepon_ortu
        TEXT alamat
    }

    SEWA {
        TEXT id_sewa PK
        TEXT id_penghuni FK
        TEXT id_kamar FK
        TEXT tanggal_mulai "YYYY-MM-DD"
        TEXT tanggal_selesai "YYYY-MM-DD"
        INTEGER durasi "> 0"
        INTEGER harga_bulanan "salinan saat sewa"
        TEXT status_sewa "Aktif / Selesai"
    }

    PEMBAYARAN {
        TEXT id_pembayaran PK
        TEXT id_sewa FK
        INTEGER periode_bulan "1..12"
        INTEGER periode_tahun
        TEXT tanggal_bayar "YYYY-MM-DD"
        INTEGER nominal "= harga sewa"
        TEXT status_pembayaran "Lunas"
    }
```

### 7.2 Relasi

Tiga relasi **1 : N**:

1. **Kamar → Sewa**: satu kamar boleh punya banyak sewa (bergantian),
   tetapi satu sewa hanya untuk satu kamar.
2. **Penghuni → Sewa**: satu penghuni boleh punya banyak sewa,
   tetapi satu sewa hanya untuk satu penghuni.
3. **Sewa → Pembayaran**: satu sewa punya banyak pembayaran bulanan,
   tetapi satu pembayaran hanya milik satu sewa.

Kardinalitas minimum:

- Kamar boleh belum punya sewa.
- Setiap sewa wajib punya tepat satu kamar dan satu penghuni.
- Setiap pembayaran wajib terkait dengan satu sewa.

### 7.3 Kamus data

#### Tabel `kamar`

| Kolom | Tipe | Ketentuan |
|---|---|---|
| `id_kamar` | TEXT | PK, otomatis `K001` |
| `nomor_kamar` | TEXT | Wajib, unik, format `A01`/`B10`/`C05` |
| `tipe` | TEXT | `A`, `B`, atau `C` |
| `harga_bulanan` | INTEGER | > 0; harga yang berlaku saat ini |
| `fasilitas` | TEXT | Wajib; daftar fasilitas |
| `status` | TEXT | `Tersedia` / `Ditempati`; dihitung otomatis |

#### Tabel `penghuni`

| Kolom | Tipe | Ketentuan |
|---|---|---|
| `id_penghuni` | TEXT | PK, otomatis `P001` |
| `nama` | TEXT | Wajib, minimal 2 karakter |
| `telepon` | TEXT | Wajib, 8–20 karakter angka/spasi/`+`/`-` |
| `telepon_ortu` | TEXT | Wajib, format sama dengan telepon |
| `alamat` | TEXT | Wajib, minimal 5 karakter |

#### Tabel `sewa`

| Kolom | Tipe | Ketentuan |
|---|---|---|
| `id_sewa` | TEXT | PK, otomatis `S001` |
| `id_penghuni` | TEXT | FK → `penghuni`, `ON DELETE RESTRICT` |
| `id_kamar` | TEXT | FK → `kamar`, `ON DELETE RESTRICT` |
| `tanggal_mulai` | TEXT | `YYYY-MM-DD` |
| `tanggal_selesai` | TEXT | `YYYY-MM-DD`, harus > `tanggal_mulai` |
| `durasi` | INTEGER | > 0 bulan; dihitung otomatis, bisa disesuaikan |
| `harga_bulanan` | INTEGER | > 0; **disalin** dari harga kamar saat sewa dibuat |
| `status_sewa` | TEXT | `Aktif` / `Selesai`; otomatis Selesai bila tanggal lewat |

#### Tabel `pembayaran`

| Kolom | Tipe | Ketentuan |
|---|---|---|
| `id_pembayaran` | TEXT | PK, otomatis `BY001` |
| `id_sewa` | TEXT | FK → `sewa`, `ON DELETE RESTRICT` |
| `periode_bulan` | INTEGER | 1–12 |
| `periode_tahun` | INTEGER | 2000–2100 |
| `tanggal_bayar` | TEXT | `YYYY-MM-DD` |
| `nominal` | INTEGER | > 0 dan **sama dengan** `sewa.harga_bulanan` |
| `status_pembayaran` | TEXT | `Lunas` saat dicatat |
| — | UNIQUE | (`id_sewa`, `periode_bulan`, `periode_tahun`) |

### 7.4 Normalisasi

| Bentuk | Pemenuhan |
|---|---|
| **1NF** | Setiap kolom berisi satu nilai atomik; setiap tabel punya primary key. |
| **2NF** | Primary key hanya satu kolom, sehingga tidak ada ketergantungan sebagian. |
| **3NF** | Data penghuni dan kamar tidak ditulis ulang di `sewa` maupun `pembayaran`. Pengecualian yang disengaja: `harga_bulanan` disalin ke `sewa` agar riwayat tidak berubah saat harga kamar naik/turun. |

### 7.5 Penjaga integritas

| Penjaga | Penerapan |
|---|---|
| `NOT NULL` | Semua kolom wajib pada keempat tabel |
| `UNIQUE` | `kamar.nomor_kamar`; (`pembayaran.id_sewa`, periode) |
| `CHECK` | Harga > 0, durasi > 0, periode 1–12, status valid, tanggal selesai > mulai |
| `FOREIGN KEY ... ON DELETE RESTRICT` | Kamar/penghuni/sewa yang masih dipakai tidak bisa dihapus |
| `PRAGMA foreign_keys = ON` | Diaktifkan pada setiap koneksi |

### 7.6 Aturan penghapusan

| Entitas | Aturan |
|---|---|
| Kamar | Tidak bisa dihapus bila punya riwayat sewa (B10). |
| Penghuni | Tidak bisa dihapus bila punya catatan sewa (B10). |
| Sewa | Tidak bisa dihapus bila sudah ada pembayaran. Sewa berhenti lebih awal diubah menjadi `Selesai`. |
| Pembayaran | Boleh dihapus untuk memperbaiki salah catat; tidak memengaruhi tabel lain. |

---

## 8. Aturan Bisnis dan Implementasinya

| Kode | Aturan | Contoh diterima | Contoh ditolak | Implementasi |
|---|---|---|---|---|
| **B01** | Nomor kamar tidak boleh kembar | Kamar baru `A26` | `A01` saat `A01` sudah ada | `validate_kamar()` + `UNIQUE(nomor_kamar)` |
| **B06** | Tanggal selesai harus setelah tanggal mulai | `01-01-2027` s.d. `31-03-2027` | `15-12-2026` s.d. `10-12-2026` | `validate_sewa_dates()` + `CHECK` |
| **B08** | Nominal pembayaran > 0 dan sama dengan harga sewa | Nominal = harga sewa | Nominal 0 atau kurang | `validate_pembayaran()` + `CHECK(nominal > 0)` |
| **B10** | Kamar/penghuni dengan riwayat sewa tidak bisa dihapus | Hapus kamar yang belum pernah disewa | Hapus `A01` yang punya riwayat sewa | `delete_kamar()` / `delete_penghuni()` + FK RESTRICT |
| **B14** | Satu sewa hanya boleh punya satu pembayaran per bulan & tahun | Sewa `S001` periode Januari 2027 (belum ada) | Pembayaran kedua `S001` Januari 2027 | `validate_pembayaran()` + `UNIQUE` |
| — | Jadwal sewa tidak boleh bertabrakan | Kamar `A01` selesai 31-12-2026, sewa baru mulai 01-01-2027 | Sewa baru mulai 15-12-2026 | `validate_jadwal_kamar()` |
| — | Status kamar & sewa otomatis | Sewa lewat tanggal → `Selesai`; kamar tanpa sewa aktif → `Tersedia` | — | `sync_statuses()` |
| — | Format tanggal | Tampil `DD-MM-YYYY`, simpan `YYYY-MM-DD` | — | `fmt_date()` / `parse_date()` |
| — | ID otomatis | `K001`, `P001`, `S001`, `BY001` | — | `next_id()` |

### 8.1 Rumus bentrok jadwal

Dua sewa pada kamar yang sama dianggap **bertabrakan** jika:

```text
tanggal_mulai_baru  ≤ tanggal_selesai_lama
DAN
tanggal_selesai_baru ≥ tanggal_mulai_lama
```

Sewa yang bersambung (`selesai_lama + 1 hari = mulai_baru`) **diterima**.

### 8.2 Status kamar

| Status | Kondisi |
|---|---|
| `Ditempati` | Ada sewa `Aktif` dengan `tanggal_mulai ≤ hari ini ≤ tanggal_selesai`. |
| `Tersedia` | Tidak ada sewa aktif yang mencakup hari ini. |

Status kamar **tidak diisi manual**; selalu diturunkan dari tabel `sewa`.

### 8.3 Status sewa

| Status | Kondisi |
|---|---|
| `Aktif` | Belum melewati tanggal selesai dan belum diakhiri manual. |
| `Selesai` | Tanggal selesai sudah lewat, atau pemilik menandai selesai lebih awal. |

### 8.4 Status pembayaran

| Status | Kondisi |
|---|---|
| `Lunas` | Pembayaran untuk periode itu sudah dicatat. |
| `Belum Dibayar` | Belum ada pembayaran dan hari ini belum melewati jatuh tempo. |
| `Terlambat` | Belum ada pembayaran dan hari ini sudah melewati jatuh tempo. |

Jatuh tempo normal adalah **tanggal 10** setiap bulan. Khusus periode pertama
yang dimulai setelah tanggal 10, jatuh tempo mengikuti tanggal mulai agar
penghuni baru tidak langsung dianggap terlambat.

### 8.5 Harga bulanan dan normalisasi

`harga_bulanan` sengaja ada di dua tabel:

- **Kamar** — harga yang berlaku saat ini dan boleh berubah.
- **Sewa** — harga yang disepakati saat sewa dibuat dan **tidak berubah**.

Harga disalin saat sewa dibuat sehingga riwayat sewa dan pembayaran tidak ikut
berubah ketika pemilik menaikkan atau menurunkan harga kamar.

---

## 9. Rancangan Antarmuka

### 9.1 Prinsip desain

1. **Satu layar, satu tugas** — setiap halaman punya tujuan jelas.
2. **Data dulu** — angka penting (okupansi, tunggakan) terlihat sebelum detail.
3. **Aman secara default** — aksi hapus butuh konfirmasi; data bersejarah dikunci.
4. **Bahasa Indonesia sederhana** — pesan kesalahan menjelaskan aturan dan solusi.
5. **Konsisten** — kartu, tabel, badge, dan tombol memakai sistem desain yang sama.

### 9.2 Design token

| Token | Nilai | Penggunaan |
|---|---|---|
| `--ks-bg` | `#F6F1EE` | Latar aplikasi |
| `--ks-surface` | `#FFFFFF` | Kartu, tabel, form |
| `--ks-ink` | `#2B1B27` | Teks utama |
| `--ks-muted` | `#7A6B74` | Teks sekunder |
| `--ks-plum` | `#7B3F61` | Warna utama, tombol, grafik |
| `--ks-plum-dark` | `#5E2E49` | Hover/tombol aktif |
| `--ks-rose` | `#B65C82` | Aksen tipe A, KPI |
| `--ks-line` | `#EADFE6` | Garis kartu/tabel |
| `--ks-green` | `#2F7D5C` | Lunas, tersedia, sukses |
| `--ks-amber` | `#A96A12` | Belum dibayar, peringatan |
| `--ks-red` | `#B23A48` | Terlambat, bahaya |

Tipografi: **Plus Jakarta Sans** (fallback Segoe UI), skala 0.68rem–1.95rem,
judul halaman 800 weight, teks isi 400–600.

Radius: 9px (input/tombol), 15px (kartu/tabel), 999px (badge/pill).
Spacing: kelipatan 4px, padding kartu 18–20px.

### 9.3 Sitemap

```text
KOSPACE
├─ Dashboard
├─ Kamar
│  ├─ Daftar Kamar
│  ├─ Tambah Kamar
│  └─ Ubah & Hapus
├─ Penghuni
│  ├─ Daftar Penghuni
│  ├─ Tambah Penghuni
│  └─ Ubah & Hapus
├─ Sewa
│  ├─ Daftar Sewa
│  ├─ Buat Sewa
│  └─ Akhiri & Hapus
├─ Pembayaran
│  ├─ Catat Pembayaran
│  ├─ Riwayat Pembayaran
│  └─ Tagihan per Sewa
└─ Riwayat
```

### 9.4 Wireframe Dashboard

```text
┌──────────────┬──────────────────────────────────────────────────────────┐
│ K  KOSPACE   │ RINGKASAN OPERASIONAL                                    │
│              │ Dashboard                                                │
│ ▦ Dashboard  │ Pantau okupansi kamar, sewa, dan pembayaran…             │
│ ▤ Kamar      │                                                          │
│ ☺ Penghuni   │ [+ Catat Pembayaran] [+ Buat Sewa] [+ Tambah Penghuni]   │
│ ⇄ Sewa       │                                                          │
│ Rp Pembayaran│ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐             │
│ ◷ Riwayat    │ │Total 25│ │Sedia 22│ │Isi   3 │ │Sewa  3 │             │
│              │ └────────┘ └────────┘ └────────┘ └────────┘             │
│              │ ┌──────────────┐ ┌──────────────┐                       │
│              │ │Bayar bulan ini│ │Tunggakan     │                       │
│              │ └──────────────┘ └──────────────┘                       │
│              │ ┌──────────┐ ┌──────────────────────────────┐            │
│              │ │  DONUT   │ │ Ketersediaan per tipe (bar)  │            │
│              │ │  okupansi│ │ Tipe A  ████████ 4/5         │            │
│              │ └──────────┘ └──────────────────────────────┘            │
│              │ ┌──────────────────────────┐ ┌───────────────────┐       │
│              │ │ Pembayaran terbaru       │ │ Sewa segera       │       │
│              │ │ tabel 5 baris            │ │ berakhir          │       │
│              │ └──────────────────────────┘ └───────────────────┘       │
│              │ ┌──────────────────────────────────────────────────┐     │
│              │ │ Perlu ditindaklanjuti (periode terlambat)        │     │
│              │ └──────────────────────────────────────────────────┘     │
└──────────────┴──────────────────────────────────────────────────────────┘
```

### 9.5 Wireframe halaman data (Kamar/Penghuni/Sewa)

```text
┌──────────────┬──────────────────────────────────────────────────────────┐
│ Sidebar      │ DATA MASTER                                              │
│              │ Kamar                                                    │
│              │ Kelola nomor, tipe, harga, dan fasilitas…                │
│              │                                                          │
│              │ [ Daftar Kamar ] [ Tambah Kamar ] [ Ubah & Hapus ]        │
│              │                                                          │
│              │ [Cari…............] [Tipe ▾] [Status ▾]                  │
│              │ ┌──────────────────────────────────────────────────────┐ │
│              │ │ NOMOR  TIPE  HARGA     FASILITAS   STATUS  PENGHUNI  │ │
│              │ │ A01    A     Rp1.300k  AC, Wi-Fi   ● Isi   Alya      │ │
│              │ │ A02    A     Rp1.300k  AC, Wi-Fi   ● Sedia —         │ │
│              │ └──────────────────────────────────────────────────────┘ │
│              │ 25 kamar ditampilkan.                                    │
└──────────────┴──────────────────────────────────────────────────────────┘
```

### 9.6 Wireframe form tambah sewa

```text
┌──────────────────────────────────────┬──────────────────────────────┐
│ DETAIL SEWA BARU                     │ ┌──────────────────────────┐ │
│ Penghuni  [Alya Nafisah ▾]           │ │ Kamar A01      ● Tersedia│ │
│ Kamar     [A01 — Tipe A ▾]           │ │ Rp1.300.000 / bulan      │ │
│ Tanggal mulai [01/01/2027]           │ │ AC, Wi-Fi, KM dalam      │ │
│ Tanggal selesai [31/03/2027]         │ └──────────────────────────┘ │
│ Perkiraan durasi: 3 bulan            │ Jadwal kamar ini             │
│                                      │ S001  Alya  01-01–31-03      │
│ [ Simpan Sewa ]                      │ Sistem menolak bentrok…      │
└──────────────────────────────────────┴──────────────────────────────┘
```

### 9.7 Wireframe pembayaran & tagihan

```text
┌──────────────────────────────┬──────────────────────────────────────┐
│ CATAT PEMBAYARAN             │ ┌──────────────────────────────────┐ │
│ Pilih sewa [S001 — Alya ▾]   │ │ Sewa S001            ● Aktif     │ │
│ Periode [Januari 2027 ▾]     │ │ Alya · Kamar A01                 │ │
│ Tanggal bayar [05/01/2027]   │ │ 01-01–31-03-2027                 │ │
│ Nominal [1300000]            │ │ Rp1.300.000 / bulan              │ │
│ Jatuh tempo 10-01-2027       │ └──────────────────────────────────┘ │
│ [ Simpan Pembayaran ]        │ Status tersimpan Lunas…              │
└──────────────────────────────┴──────────────────────────────────────┘

TAGIHAN PER SEWA
┌──────────────┬──────────────┬──────────────┐
│ TOTAL TAGIHAN│ SUDAH DIBAYAR│ SISA TAGIHAN │
└──────────────┴──────────────┴──────────────┘
PERIODE        JATUH TEMPO  NOMINAL      STATUS
Januari 2027   10-01-2027   Rp1.300.000  ● Lunas
Februari 2027  10-02-2027   Rp1.300.000  ● Terlambat
```

### 9.8 Komponen antarmuka

| Komponen | Fungsi |
|---|---|
| Sidebar gelap | Brand, navigasi 6 halaman, info kos |
| Page header | Eyebrow, judul, deskripsi halaman |
| KPI card | Angka utama + konteks + aksen warna |
| Tabel kustom | Data padat, badge status, scroll horizontal di layar kecil |
| Badge | Status kamar, sewa, pembayaran, tipe kamar |
| Donut | Persentase okupansi |
| Bar | Ketersediaan per tipe kamar |
| Flash message | Umpan balik sukses/gagal setelah aksi |
| Empty state | Panduan saat data masih kosong |
| Tabs | Memisahkan daftar, tambah, dan ubah/hapus |
| Expander | Detail pembayaran pada riwayat |

### 9.9 Perilaku responsif

- Lebar konten maksimum 1180px, terpusat.
- Tabel memiliki `min-width` dan wrapper `overflow-x:auto`, sehingga tetap
  terbaca di layar sempit.
- Kolom KPI 4 → 2 → 1 mengikuti lebar Streamlit.
- Sidebar dapat diciutkan dari tombol bawaan Streamlit.

---

## 10. Alur Pengguna

### 10.1 Alur membuat sewa

```mermaid
flowchart TD
    A[Buka menu Sewa] --> B[Tab Buat Sewa]
    B --> C{Penghuni sudah ada?}
    C -- Belum --> D[Tambah penghuni dulu]
    D --> B
    C -- Sudah --> E[Pilih penghuni & kamar]
    E --> F[Isi tanggal mulai & selesai]
    F --> G[Simpan]
    G --> H{Validasi}
    H -- Gagal B06 --> I[Pesan: tanggal selesai harus setelah mulai]
    H -- Gagal bentrok --> J[Pesan: jadwal bertabrakan + detail sewa lama]
    H -- Lolos --> K[Simpan sewa, salin harga kamar]
    K --> L[Sync status kamar]
    L --> M[Sukses + kembali ke daftar]
```

### 10.2 Alur mencatat pembayaran

```mermaid
flowchart TD
    A[Menu Pembayaran] --> B[Pilih sewa]
    B --> C[Sistem menampilkan periode & harga]
    C --> D[Pilih periode, tanggal, nominal]
    D --> E[Simpan]
    E --> F{Validasi}
    F -- Nominal salah --> G[Tolak B08]
    F -- Periode ganda --> H[Tolak B14]
    F -- Periode di luar sewa --> I[Tolak]
    F -- Lolos --> J[Simpan status Lunas]
    J --> K[Riwayat & tagihan diperbarui]
```

### 10.3 State transition

```text
KAMAR:    Tersedia ──(sewa aktif mencakup hari ini)──► Ditempati
          Ditempati ──(sewa selesai/lewat)──────────► Tersedia

SEWA:     (baru) ──► Aktif ──(tanggal lewat / diakhiri)──► Selesai

TAGIHAN:  Belum Dibayar ──(hari > jatuh tempo)──► Terlambat
          Belum/Terlambat ──(pembayaran dicatat)──► Lunas
          Lunas ──(pembayaran dihapus untuk koreksi)──► Belum/Terlambat
```

---

## 11. Rancangan Teknis

### 11.1 Tanggung jawab modul

| Modul | Tanggung jawab |
|---|---|
| `app.py` | Konfigurasi halaman, init DB, sync, navigasi, dispatch, penanganan error |
| `config.py` | Konstanta aplikasi, tipe kamar, harga, label bulan, navigasi |
| `database.py` | Skema SQL, koneksi, `PRAGMA foreign_keys`, seed 25 kamar |
| `utils.py` | Parse/format tanggal, rupiah, periode bulan, durasi, ID otomatis |
| `validators.py` | Validasi kamar, penghuni, tanggal sewa, bentrok jadwal, pembayaran |
| `repositories/*` | Query dan operasi CRUD per entitas; tidak menyentuh UI |
| `services/dashboard.py` | Sinkronisasi status dan agregasi angka dashboard |
| `ui/components.py` | CSS, sidebar, kartu, badge, tabel, flash, empty state |
| `ui/*.py` | Halaman; memanggil repository/service dan menampilkan hasil |

### 11.2 ID otomatis

| Entitas | Prefix | Contoh |
|---|---|---|
| Kamar | `K` | `K001` |
| Penghuni | `P` | `P001` |
| Sewa | `S` | `S001` |
| Pembayaran | `BY` | `BY001` |

`next_id()` mengambil ID terbesar dengan prefix yang sama lalu menambah 1.
Nomor kamar (A01, B01, C01) adalah **kode bisnis** yang dikenal pemilik dan
wajib unik; `id_kamar` hanya dipakai di dalam sistem.

### 11.3 Penyimpanan tanggal

- Database: `YYYY-MM-DD` (ISO) agar perbandingan string = perbandingan tanggal.
- Tampilan: `DD-MM-YYYY` melalui `fmt_date()`.
- Input Streamlit: `format="DD/MM/YYYY"`.
- Perbandingan overlap memakai string ISO sehingga aman dan cepat.

### 11.4 Penanganan kesalahan

- `ValidationError` membawa pesan berbahasa Indonesia yang menjelaskan aturan.
- Form menampilkan `st.error` di dekat tombol simpan; data lain tidak hilang.
- Transaksi database memakai context manager: rollback otomatis bila gagal.
- Halaman dibungkus `try/except` di `app.py`; detail teknis hanya di expander.

### 11.5 Privasi dan keamanan

- Aplikasi berjalan lokal; tidak ada data yang dikirim ke internet.
- Belum ada login (sesuai batasan tugas); cocok untuk satu pengguna.
- Data pribadi penghuni (telepon orang tua, alamat) hanya tersimpan di SQLite
  lokal. Folder `data/` diabaikan Git melalui `.gitignore`.
- Input pengguna di-escape sebelum dimasukkan ke HTML kustom untuk mencegah
  HTML injection.

---

## 12. Rencana Pengujian

### 12.1 Unit test otomatis

Perintah:

```powershell
python -m unittest discover -s tests -v
```

| # | Skenario | Ekspektasi | Status |
|---|---|---|---|
| 1 | Tambah kamar `A06` dua kali | Percobaan kedua ditolak (B01) | ✅ |
| 2 | Ubah kamar menjadi nomor yang sudah ada | Ditolak (B01) | ✅ |
| 3 | Tanggal selesai = tanggal mulai | Ditolak (B06) | ✅ |
| 4 | Tanggal selesai sebelum tanggal mulai | Ditolak (B06) | ✅ |
| 5 | Sewa baru overlap dengan sewa lama | Ditolak | ✅ |
| 6 | Sewa baru bersambung tepat setelah sewa lama | Diterima | ✅ |
| 7 | Nominal 0 | Ditolak (B08) | ✅ |
| 8 | Nominal ≠ harga sewa | Ditolak (B08) | ✅ |
| 9 | Pembayaran kedua periode sama | Ditolak (B14) | ✅ |
| 10 | Hapus kamar/penghuni yang punya sewa | Ditolak (B10) | ✅ |
| 11 | Hapus kamar tanpa riwayat | Diterima | ✅ |
| 12 | Status tagihan Lunas/Terlambat | Sesuai tanggal | ✅ |
| 13 | Status Belum Dibayar sebelum jatuh tempo | Sesuai | ✅ |
| 14 | ID kamar berurutan setelah seed | `K026`, `K027` | ✅ |
| 15 | Durasi 01-01 s.d. 31-03 | 3 bulan | ✅ |
| 16 | Durasi 31-08-2026 s.d. 31-08-2027 | 12 bulan | ✅ |
| 17 | Hapus pembayaran untuk koreksi | Diterima | ✅ |

### 12.2 Uji manual di browser

| # | Langkah | Hasil yang diharapkan |
|---|---|---|
| 1 | Buka dashboard | 6 KPI, donut, bar per tipe, tabel pembayaran terbaru |
| 2 | Tambah kamar baru | Muncul di daftar, status Tersedia |
| 3 | Cari kamar `A01` | Hanya kamar terkait yang tampil |
| 4 | Tambah penghuni | Muncul di daftar; telepon tervalidasi |
| 5 | Buat sewa A01 | Sewa aktif, kamar A01 menjadi Ditempati |
| 6 | Buat sewa kedua di A01 dengan tanggal overlap | Ditolak dengan pesan bentrok |
| 7 | Catat pembayaran | Status Lunas, total dibayar bertambah |
| 8 | Catat pembayaran periode yang sama | Ditolak (B14) |
| 9 | Buka Tagihan per Sewa | Periode lewat jatuh tempo berstatus Terlambat |
| 10 | Hapus kamar yang punya sewa | Ditolak (B10) |
| 11 | Akhiri sewa | Status Selesai, kamar kembali Tersedia |
| 12 | Unduh CSV riwayat | File terbuka di Excel dengan data benar |
| 13 | Kosongkan filter riwayat | Empty state tampil, bukan error |
| 14 | Perbesar/perkecil jendela | Tabel bisa di-scroll horizontal, layout tetap rapi |

---

## 13. Cara Menjalankan di VS Code

1. Buka folder `kospace` di VS Code.
2. Buka terminal: `Ctrl + ~`.
3. Buat virtual environment dan aktifkan:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```

4. Jalankan aplikasi:

   ```powershell
   streamlit run app.py
   ```

5. Browser terbuka di `http://localhost:8501`.
6. Opsional, isi data contoh:

   ```powershell
   python -m kospace.seed_demo
   ```

7. Opsional, jalankan unit test:

   ```powershell
   python -m unittest discover -s tests -v
   ```

Alternatif: tekan `F5` dan pilih konfigurasi
**“Streamlit: Jalankan KOSPACE”** (tersedia di `.vscode/launch.json`).

> Catatan: `server.fileWatcherType = "none"` dipakai karena database SQLite
> berada di dalam folder proyek. Tanpa pengaturan ini, Streamlit dapat memuat
> ulang aplikasi setiap kali database ditulis.

---

## 14. Roadmap Pengembangan

| Prioritas | Fitur | Manfaat |
|---|---|---|
| Tinggi | Login pemilik (hash password) | Melindungi data pribadi penghuni |
| Tinggi | Kuitansi PDF otomatis | Bukti pembayaran untuk penghuni |
| Tinggi | Pengingat WhatsApp jatuh tempo | Mengurangi tunggakan |
| Sedang | Perpanjangan sewa 1 klik | Mempercepat perpanjangan kontrak |
| Sedang | Grafik pendapatan 12 bulan | Analisis bisnis kos |
| Sedang | Deposit & token listrik | Sesuai operasional kos nyata |
| Rendah | Pembayaran online (midtrans/Xendit) | Pembayaran mandiri |
| Rendah | Deployment (Streamlit Cloud/VPS) | Akses dari luar rumah |
| Rendah | Multi-kos / multi-cabang | Skala usaha lebih besar |

---

## 15. Pemetaan ke Dokumen Asli

| Halaman dokumen | Isi | Implementasi di proyek |
|---|---|---|
| 2 | Gambaran umum, 25 kamar, 4 tabel | `config.py`, `database.py`, dashboard |
| 3 | Latar belakang, masalah, solusi | Dokumen ini §2; fitur |
| 4 | Tujuan perancangan | Dokumen ini §3 |
| 5 | Pengguna, ruang lingkup, batasan | Dokumen ini §4 |
| 6 | Fitur & prioritas | Dokumen ini §5 |
| 7 | Kebutuhan nonfungsional & aturan bisnis | `validators.py`, `tests/` |
| 8 | Alur proses bisnis | Alur di §10 |
| 9 | Status kamar, pembayaran, jadwal | `sync_statuses()`, `billing_schedule()` |
| 10 | Empat entitas | Skema SQL + repository |
| 11 | ERD 3 relasi 1:N | ERD §7.1 |
| 12 | PK, FK, kode bisnis, format ID | `utils.next_id()`, skema |
| 13 | Kamus data | §7.3 |
| 14 | Harga & normalisasi | §7.4, §8.5 |
| 15 | Aturan penghapusan & integritas | §7.6, `delete_*`, FK RESTRICT |
| 16 | Penutup | — |

---

## 16. Kesimpulan

KOSPACE memenuhi kebutuhan administrasi kos dalam satu sistem lokal:
data kamar, penghuni, sewa, dan pembayaran tersimpan terstruktur; status
diperbarui otomatis; bentrok jadwal dan pelanggaran aturan bisnis ditolak
dengan pesan yang jelas; serta riwayat dapat ditelusuri dan diekspor.

Rancangan ini sudah diimplementasikan penuh di folder proyek, diuji dengan
17 skenario otomatis, dan siap dijalankan dari VS Code sesuai panduan §13.
