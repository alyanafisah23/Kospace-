"""Repository data kamar."""

from __future__ import annotations

import sqlite3

from ..utils import next_id
from ..validators import ValidationError, validate_kamar

_SELECT_KAMAR = """
SELECT k.*,
       (
           SELECT p.nama
           FROM sewa s
           JOIN penghuni p ON p.id_penghuni = s.id_penghuni
           WHERE s.id_kamar = k.id_kamar
             AND s.status_sewa = 'Aktif'
             AND date('now', 'localtime') BETWEEN s.tanggal_mulai AND s.tanggal_selesai
           ORDER BY s.tanggal_mulai DESC
           LIMIT 1
       ) AS penghuni_aktif
FROM kamar k
"""


def list_kamar(
    conn: sqlite3.Connection,
    status: str | None = None,
    tipe: str | None = None,
    q: str | None = None,
) -> list[sqlite3.Row]:
    sql = _SELECT_KAMAR + " WHERE 1 = 1"
    params: list[object] = []
    if status and status != "Semua":
        sql += " AND k.status = ?"
        params.append(status)
    if tipe and tipe != "Semua":
        sql += " AND k.tipe = ?"
        params.append(tipe)
    if q:
        sql += " AND (k.nomor_kamar LIKE ? OR k.fasilitas LIKE ?)"
        params.extend([f"%{q.strip()}%", f"%{q.strip()}%"])
    sql += " ORDER BY k.nomor_kamar"
    return conn.execute(sql, params).fetchall()


def get_kamar(conn: sqlite3.Connection, id_kamar: str) -> sqlite3.Row | None:
    return conn.execute(
        _SELECT_KAMAR + " WHERE k.id_kamar = ?", (id_kamar,)
    ).fetchone()


def get_kamar_by_nomor(conn: sqlite3.Connection, nomor: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM kamar WHERE nomor_kamar = ?", (str(nomor).strip().upper(),)
    ).fetchone()


def create_kamar(
    conn: sqlite3.Connection,
    nomor: str,
    tipe: str,
    harga: int | float,
    fasilitas: str,
) -> str:
    nomor, harga = validate_kamar(conn, nomor, tipe, harga)
    fasilitas = str(fasilitas or "").strip() or "—"
    id_kamar = next_id(conn, "kamar", "id_kamar", "K")
    conn.execute(
        """
        INSERT INTO kamar
            (id_kamar, nomor_kamar, tipe, harga_bulanan, fasilitas, status)
        VALUES (?, ?, ?, ?, ?, 'Tersedia')
        """,
        (id_kamar, nomor, str(tipe).strip().upper(), harga, fasilitas),
    )
    return id_kamar


def update_kamar(
    conn: sqlite3.Connection,
    id_kamar: str,
    nomor: str,
    tipe: str,
    harga: int | float,
    fasilitas: str,
) -> None:
    if not get_kamar(conn, id_kamar):
        raise ValidationError("Kamar tidak ditemukan.")
    nomor, harga = validate_kamar(conn, nomor, tipe, harga, exclude_id=id_kamar)
    fasilitas = str(fasilitas or "").strip() or "—"
    conn.execute(
        """
        UPDATE kamar
        SET nomor_kamar = ?, tipe = ?, harga_bulanan = ?, fasilitas = ?
        WHERE id_kamar = ?
        """,
        (nomor, str(tipe).strip().upper(), harga, fasilitas, id_kamar),
    )


def has_riwayat_sewa(conn: sqlite3.Connection, id_kamar: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sewa WHERE id_kamar = ? LIMIT 1", (id_kamar,)
    ).fetchone()
    return row is not None


def delete_kamar(conn: sqlite3.Connection, id_kamar: str) -> None:
    kamar = get_kamar(conn, id_kamar)
    if not kamar:
        raise ValidationError("Kamar tidak ditemukan.")
    # B10 — kamar dengan riwayat sewa tidak boleh dihapus
    if has_riwayat_sewa(conn, id_kamar):
        raise ValidationError(
            f"Kamar {kamar['nomor_kamar']} tidak bisa dihapus karena sudah punya "
            "riwayat sewa. Data harus tetap tersimpan untuk penelusuran "
            "(aturan B10)."
        )
    conn.execute("DELETE FROM kamar WHERE id_kamar = ?", (id_kamar,))


def stats_tipe(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute(
        """
        SELECT tipe,
               COUNT(*) AS total,
               SUM(CASE WHEN status = 'Tersedia' THEN 1 ELSE 0 END) AS tersedia,
               SUM(CASE WHEN status = 'Ditempati' THEN 1 ELSE 0 END) AS ditempati
        FROM kamar
        GROUP BY tipe
        ORDER BY tipe
        """
    ).fetchall()
