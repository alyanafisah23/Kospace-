/* ==========================================================================
   KOSPACE — data demo, penyimpanan, dan aturan bisnis
   --------------------------------------------------------------------------
   Lapisan ini meniru aturan bisnis pada aplikasi Streamlit KOSPACE:
   B01 nomor kamar unik, B06 tanggal selesai > mulai, B08 nominal = harga sewa,
   B10 data dengan riwayat tidak boleh dihapus, B14 satu pembayaran per periode,
   serta deteksi jadwal sewa yang bertabrakan.
   Data disimpan di localStorage agar demo bisa dibuka tanpa server.
   ========================================================================== */
(function (global) {
  'use strict';

  const KEY = 'kospace_website_demo_v1';
  const VERSION = 1;

  const MONTHS = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

  const ROOM_TYPES = {
    A: {
      key: 'A',
      label: 'Tipe A',
      harga: 1300000,
      fasilitas: 'AC, Wi-Fi, kamar mandi dalam',
      color: '#1d3b66',
      tint: '#eef3f8',
      jumlah: 5
    },
    B: {
      key: 'B',
      label: 'Tipe B',
      harga: 950000,
      fasilitas: 'AC, Wi-Fi, kamar mandi luar',
      color: '#d9861b',
      tint: '#fff4e3',
      jumlah: 10
    },
    C: {
      key: 'C',
      label: 'Tipe C',
      harga: 700000,
      fasilitas: 'Kipas angin, Wi-Fi, kamar mandi luar',
      color: '#2e8b7a',
      tint: '#e6f4f1',
      jumlah: 10
    }
  };

  /* -----------------------------------------------------------------------
     Utilitas tanggal & angka
     ----------------------------------------------------------------------- */
  const pad2 = (n) => String(n).padStart(2, '0');
  const pad3 = (n) => String(n).padStart(3, '0');

  function today() {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  }

  function parseISO(value) {
    if (value instanceof Date) return new Date(value.getFullYear(), value.getMonth(), value.getDate());
    const parts = String(value).split('-').map(Number);
    return new Date(parts[0], parts[1] - 1, parts[2]);
  }

  function iso(date) {
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
  }

  function addDays(date, days) {
    const d = new Date(date);
    d.setDate(d.getDate() + days);
    return d;
  }

  function addMonths(date, months) {
    const d = new Date(date.getFullYear(), date.getMonth() + months, 1);
    const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    d.setDate(Math.min(date.getDate(), last));
    return d;
  }

  function daysBetween(start, end) {
    return Math.round((parseISO(end) - parseISO(start)) / 86400000);
  }

  function monthsBetween(start, end) {
    const a = parseISO(start);
    const b = parseISO(end);
    let months = (b.getFullYear() - a.getFullYear()) * 12 + (b.getMonth() - a.getMonth());
    if (b.getDate() < a.getDate()) months -= 1;
    const anchor = addMonths(a, months);
    if (b > anchor) months += 1;
    return Math.max(1, months);
  }

  function isValidISO(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value))) return false;
    const d = parseISO(value);
    return iso(d) === String(value);
  }

  function fmtDate(value) {
    if (!value) return '—';
    const d = parseISO(value);
    return `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}-${d.getFullYear()}`;
  }

  function fmtDateLong(value) {
    if (!value) return '—';
    const d = parseISO(value);
    return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
  }

  function fmtRupiah(value) {
    return 'Rp' + Number(value || 0).toLocaleString('id-ID');
  }

  function fmtRupiahShort(value) {
    const n = Number(value || 0);
    if (n >= 1000000000) return 'Rp' + (n / 1000000000).toFixed(1).replace('.', ',') + ' M';
    if (n >= 1000000) return 'Rp' + (n / 1000000).toFixed(1).replace('.', ',') + ' jt';
    if (n >= 1000) return 'Rp' + Math.round(n / 1000) + ' rb';
    return fmtRupiah(n);
  }

  function monthLabel(month, year) {
    return `${MONTHS[Number(month) - 1]} ${year}`;
  }

  function monthKey(year, month) {
    return `${year}-${pad2(month)}`;
  }

  function nextId(prefix, items, key) {
    key = key || 'id';
    let max = 0;
    items.forEach((item) => {
      const value = String(item[key] || '');
      if (value.indexOf(prefix) === 0) {
        const n = parseInt(value.slice(prefix.length), 10);
        if (!Number.isNaN(n) && n > max) max = n;
      }
    });
    return prefix + pad3(max + 1);
  }

  /* -----------------------------------------------------------------------
     Seed data contoh
     ----------------------------------------------------------------------- */
  function periodsForLease(lease) {
    const start = parseISO(lease.mulai);
    const end = parseISO(lease.selesai);
    const periods = [];
    let year = start.getFullYear();
    let month = start.getMonth() + 1;
    let guard = 0;
    while ((year < end.getFullYear() || (year === end.getFullYear() && month <= end.getMonth() + 1)) && guard < 240) {
      periods.push({ year: year, month: month });
      month += 1;
      if (month > 12) {
        month = 1;
        year += 1;
      }
      guard += 1;
    }
    return periods;
  }

  function dueDateFor(lease, year, month) {
    const start = parseISO(lease.mulai);
    if (start.getFullYear() === Number(year) && start.getMonth() + 1 === Number(month) && start.getDate() > 10) {
      return start;
    }
    return new Date(Number(year), Number(month) - 1, 10);
  }

  function buildSeed() {
    const t = today();
    const kamar = [];
    let roomNo = 1;

    ['A', 'B', 'C'].forEach((type) => {
      const spec = ROOM_TYPES[type];
      for (let i = 1; i <= spec.jumlah; i += 1) {
        kamar.push({
          id: 'K' + pad3(roomNo),
          nomor: type + pad2(i),
          tipe: type,
          harga: spec.harga,
          fasilitas: spec.fasilitas
        });
        roomNo += 1;
      }
    });

    const penghuni = [
      {
        id: 'P001',
        nama: 'Alya Nafisah',
        telepon: '0812-3456-7890',
        telepon_ortu: '0813-1111-2222',
        alamat: 'Bandung, Jawa Barat'
      },
      {
        id: 'P002',
        nama: 'Marensya Aurellya',
        telepon: '0857-8899-1122',
        telepon_ortu: '0812-3333-4444',
        alamat: 'Surabaya, Jawa Timur'
      },
      {
        id: 'P003',
        nama: 'Shintia Nova P. A.',
        telepon: '0878-2233-4455',
        telepon_ortu: '0856-7777-8888',
        alamat: 'Yogyakarta, DI Yogyakarta'
      },
      {
        id: 'P004',
        nama: 'Permata Rayya A. A.',
        telepon: '0813-5566-7788',
        telepon_ortu: '0812-9999-0000',
        alamat: 'Semarang, Jawa Tengah'
      },
      {
        id: 'P005',
        nama: 'Nadia Khairunnisa',
        telepon: '0821-1122-3344',
        telepon_ortu: '0813-5555-6666',
        alamat: 'Salatiga, Jawa Tengah'
      }
    ];

    const sewa = [
      {
        id: 'S001',
        id_penghuni: 'P001',
        id_kamar: 'K001',
        mulai: iso(addMonths(t, -2)),
        selesai: iso(addMonths(t, 10)),
        durasi: 12,
        harga: 1300000,
        status: 'Aktif'
      },
      {
        id: 'S002',
        id_penghuni: 'P004',
        id_kamar: 'K003',
        mulai: iso(addMonths(t, -4)),
        selesai: iso(addMonths(t, 8)),
        durasi: 12,
        harga: 1300000,
        status: 'Aktif'
      },
      {
        id: 'S003',
        id_penghuni: 'P002',
        id_kamar: 'K008',
        mulai: iso(addMonths(t, -1)),
        selesai: iso(addMonths(t, 11)),
        durasi: 12,
        harga: 950000,
        status: 'Aktif'
      },
      {
        id: 'S004',
        id_penghuni: 'P003',
        id_kamar: 'K018',
        mulai: iso(addMonths(t, -1)),
        selesai: iso(addMonths(t, 5)),
        durasi: 6,
        harga: 700000,
        status: 'Aktif'
      },
      {
        id: 'S005',
        id_penghuni: 'P005',
        id_kamar: 'K021',
        mulai: iso(addDays(t, -10)),
        selesai: iso(addMonths(t, 11)),
        durasi: 12,
        harga: 700000,
        status: 'Aktif'
      }
    ];

    sewa.forEach((lease) => {
      lease.durasi = monthsBetween(lease.mulai, lease.selesai);
    });

    const pembayaran = [];
    let payNo = 1;

    function addPaymentFor(lease, periodIndex) {
      const periods = periodsForLease(lease);
      const period = periods[periodIndex];
      if (!period) return;
      const due = dueDateFor(lease, period.year, period.month);
      const payDate = new Date(Math.min(addDays(due, -3).getTime(), t.getTime()));
      pembayaran.push({
        id: 'BY' + pad3(payNo),
        id_sewa: lease.id,
        bulan: period.month,
        tahun: period.year,
        tanggal: iso(payDate),
        nominal: lease.harga,
        status: 'Lunas'
      });
      payNo += 1;
    }

    function payThroughCurrentMonth(lease, extra) {
      const periods = periodsForLease(lease);
      const currentIndex = periods.findIndex(
        (p) => p.year === t.getFullYear() && p.month === t.getMonth() + 1
      );
      const last = currentIndex >= 0 ? currentIndex : 0;
      for (let i = 0; i <= last + (extra || 0); i += 1) {
        addPaymentFor(lease, i);
      }
    }

    const byId = (id) => sewa.find((s) => s.id === id);

    // S001: tiga periode terakhir sudah dibayar (termasuk bulan berjalan).
    addPaymentFor(byId('S001'), 0);
    addPaymentFor(byId('S001'), 1);
    addPaymentFor(byId('S001'), 2);

    // S002: lunas sejak mulai sampai bulan berjalan.
    payThroughCurrentMonth(byId('S002'), 0);

    // S003: periode pertama dan bulan berjalan sudah dibayar.
    addPaymentFor(byId('S003'), 0);
    addPaymentFor(byId('S003'), 1);

    // S004 sengaja belum dibayar agar muncul sebagai tunggakan.

    // S005: periode pertama sudah dibayar.
    addPaymentFor(byId('S005'), 0);

    return {
      version: VERSION,
      kamar: kamar,
      penghuni: penghuni,
      sewa: sewa,
      pembayaran: pembayaran
    };
  }

  /* -----------------------------------------------------------------------
     Penyimpanan
     ----------------------------------------------------------------------- */
  let state = null;
  let storageOK = true;

  function ensureState() {
    if (state) return state;
    try {
      const raw = global.localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.version === VERSION && Array.isArray(parsed.kamar)) {
          state = parsed;
          return state;
        }
      }
    } catch (error) {
      storageOK = false;
    }
    state = buildSeed();
    persist();
    return state;
  }

  function persist() {
    if (!storageOK) return;
    try {
      global.localStorage.setItem(KEY, JSON.stringify(state));
    } catch (error) {
      storageOK = false;
    }
  }

  function resetDemo() {
    state = buildSeed();
    persist();
    return state;
  }

  /* -----------------------------------------------------------------------
     Akses data
     ----------------------------------------------------------------------- */
  function rooms() {
    return ensureState().kamar;
  }

  function residents() {
    return ensureState().penghuni;
  }

  function leases() {
    return ensureState().sewa;
  }

  function payments() {
    return ensureState().pembayaran;
  }

  function getRoom(id) {
    return rooms().find((room) => room.id === id) || null;
  }

  function getResident(id) {
    return residents().find((person) => person.id === id) || null;
  }

  function getLease(id) {
    return leases().find((lease) => lease.id === id) || null;
  }

  function getPayment(id) {
    return payments().find((payment) => payment.id === id) || null;
  }

  /* -----------------------------------------------------------------------
     Status turunan
     ----------------------------------------------------------------------- */
  function leaseStatus(lease) {
    if (!lease) return 'Selesai';
    if (lease.status === 'Selesai') return 'Selesai';
    return parseISO(lease.selesai) < today() ? 'Selesai' : 'Aktif';
  }

  function roomStatus(roomOrId) {
    const id = typeof roomOrId === 'string' ? roomOrId : roomOrId.id;
    const t = today();
    const occupied = leases().some(
      (lease) =>
        lease.id_kamar === id &&
        leaseStatus(lease) === 'Aktif' &&
        parseISO(lease.mulai) <= t &&
        parseISO(lease.selesai) >= t
    );
    return occupied ? 'Ditempati' : 'Tersedia';
  }

  function occupantOf(roomId) {
    const t = today();
    const lease = leases().find(
      (item) =>
        item.id_kamar === roomId &&
        leaseStatus(item) === 'Aktif' &&
        parseISO(item.mulai) <= t &&
        parseISO(item.selesai) >= t
    );
    if (!lease) return null;
    return getResident(lease.id_penghuni);
  }

  function activeLeases() {
    return leases().filter((lease) => leaseStatus(lease) === 'Aktif');
  }

  function periodsFor(lease) {
    return periodsForLease(lease);
  }

  function paymentFor(leaseId, year, month) {
    return payments().find(
      (payment) =>
        payment.id_sewa === leaseId &&
        Number(payment.tahun) === Number(year) &&
        Number(payment.bulan) === Number(month)
    ) || null;
  }

  function paymentStatus(lease, year, month) {
    if (paymentFor(lease.id, year, month)) return 'Lunas';
    const due = dueDateFor(lease, year, month);
    return today() > due ? 'Terlambat' : 'Belum Dibayar';
  }

  function dueDate(lease, year, month) {
    return dueDateFor(lease, year, month);
  }

  function overdueItems() {
    const t = today();
    const items = [];
    leases().forEach((lease) => {
      periodsForLease(lease).forEach((period) => {
        if (paymentFor(lease.id, period.year, period.month)) return;
        const due = dueDateFor(lease, period.year, period.month);
        if (due < t) {
          items.push({
            lease: lease,
            year: period.year,
            month: period.month,
            due: iso(due),
            amount: lease.harga,
            resident: getResident(lease.id_penghuni),
            room: getRoom(lease.id_kamar)
          });
        }
      });
    });
    items.sort((a, b) => (a.due < b.due ? -1 : a.due > b.due ? 1 : 0));
    return items;
  }

  function summary() {
    const t = today();
    const allRooms = rooms();
    const total = allRooms.length;
    const occupied = allRooms.filter((room) => roomStatus(room) === 'Ditempati').length;
    const available = total - occupied;
    const active = activeLeases();
    const monthPaid = payments()
      .filter((p) => Number(p.bulan) === t.getMonth() + 1 && Number(p.tahun) === t.getFullYear())
      .reduce((sum, p) => sum + Number(p.nominal), 0);
    const overdue = overdueItems();
    const arrearsAmount = overdue.reduce((sum, item) => sum + Number(item.amount), 0);

    const byType = {};
    Object.keys(ROOM_TYPES).forEach((type) => {
      const typeRooms = allRooms.filter((room) => room.tipe === type);
      const typeOccupied = typeRooms.filter((room) => roomStatus(room) === 'Ditempati').length;
      byType[type] = {
        total: typeRooms.length,
        occupied: typeOccupied,
        available: typeRooms.length - typeOccupied,
        pct: typeRooms.length ? Math.round((typeOccupied / typeRooms.length) * 100) : 0
      };
    });

    return {
      totalRooms: total,
      available: available,
      occupied: occupied,
      activeLeases: active.length,
      monthPaid: monthPaid,
      arrearsCount: overdue.length,
      arrearsAmount: arrearsAmount,
      occupancyPct: total ? Math.round((occupied / total) * 100) : 0,
      byType: byType,
      overdue: overdue
    };
  }

  function recentPayments(limit) {
    return payments()
      .slice()
      .sort((a, b) => {
        if (a.tanggal !== b.tanggal) return a.tanggal < b.tanggal ? 1 : -1;
        return a.id < b.id ? 1 : -1;
      })
      .slice(0, limit || 5);
  }

  function leasesEndingSoon(days) {
    const t = today();
    const limit = addDays(t, days || 45);
    return leases()
      .filter(
        (lease) =>
          leaseStatus(lease) === 'Aktif' &&
          parseISO(lease.selesai) >= t &&
          parseISO(lease.selesai) <= limit
      )
      .sort((a, b) => (a.selesai < b.selesai ? -1 : 1));
  }

  /* -----------------------------------------------------------------------
     Validasi
     ----------------------------------------------------------------------- */
  const PHONE_RE = /^[0-9+\-\s]{8,20}$/;

  function validateRoom(data, excludeId) {
    const nomor = String(data.nomor || '').trim().toUpperCase();
    if (!nomor) return 'Nomor kamar wajib diisi.';
    if (!/^[A-Z]\d{2}$/.test(nomor)) return 'Nomor kamar harus berbentuk huruf + 2 angka, contoh A01.';
    const duplicate = rooms().some(
      (room) => room.nomor.toUpperCase() === nomor && room.id !== excludeId
    );
    if (duplicate) return `Nomor kamar ${nomor} sudah dipakai (aturan B01).`;
    if (!ROOM_TYPES[data.tipe]) return 'Tipe kamar harus A, B, atau C.';
    const harga = Number(data.harga);
    if (!Number.isInteger(harga) || harga <= 0) return 'Harga bulanan harus bilangan bulat lebih dari 0.';
    if (!String(data.fasilitas || '').trim()) return 'Fasilitas wajib diisi.';
    return null;
  }

  function validateResident(data) {
    const nama = String(data.nama || '').trim();
    if (nama.length < 2) return 'Nama penghuni minimal 2 karakter.';
    if (!PHONE_RE.test(String(data.telepon || '').trim())) {
      return 'Nomor telepon harus 8–20 karakter angka, spasi, +, atau -.';
    }
    if (!PHONE_RE.test(String(data.telepon_ortu || '').trim())) {
      return 'Nomor telepon orang tua harus 8–20 karakter angka, spasi, +, atau -.';
    }
    if (String(data.alamat || '').trim().length < 5) return 'Alamat minimal 5 karakter.';
    return null;
  }

  function validateLease(data, excludeId) {
    if (!getResident(data.id_penghuni)) return 'Penghuni wajib dipilih.';
    if (!getRoom(data.id_kamar)) return 'Kamar wajib dipilih.';
    if (!isValidISO(data.mulai)) return 'Tanggal mulai tidak valid.';
    if (!isValidISO(data.selesai)) return 'Tanggal selesai tidak valid.';
    if (String(data.selesai) <= String(data.mulai)) {
      return 'Tanggal selesai harus setelah tanggal mulai (aturan B06).';
    }
    const conflict = leases().find(
      (lease) =>
        lease.id !== excludeId &&
        lease.id_kamar === data.id_kamar &&
        String(data.mulai) <= String(lease.selesai) &&
        String(data.selesai) >= String(lease.mulai)
    );
    if (conflict) {
      const person = getResident(conflict.id_penghuni);
      return `Jadwal bertabrakan dengan sewa ${conflict.id} (${person ? person.nama : 'penghuni'}) pada ${fmtDate(conflict.mulai)}–${fmtDate(conflict.selesai)}.`;
    }
    return null;
  }

  function validatePayment(data) {
    const lease = getLease(data.id_sewa);
    if (!lease) return 'Sewa wajib dipilih.';
    const month = Number(data.bulan);
    const year = Number(data.tahun);
    if (!Number.isInteger(month) || month < 1 || month > 12) return 'Periode bulan harus 1–12.';
    if (!Number.isInteger(year) || year < 2000 || year > 2100) return 'Periode tahun tidak valid.';
    if (!isValidISO(data.tanggal)) return 'Tanggal bayar tidak valid.';
    const nominal = Number(data.nominal);
    if (!Number.isInteger(nominal) || nominal <= 0) return 'Nominal harus lebih dari 0 (aturan B08).';
    if (nominal !== Number(lease.harga)) {
      return `Nominal harus sama dengan harga sewa ${fmtRupiah(lease.harga)} (aturan B08).`;
    }
    const inPeriod = periodsForLease(lease).some(
      (period) => period.year === year && period.month === month
    );
    if (!inPeriod) return 'Periode berada di luar masa sewa.';
    if (paymentFor(lease.id, year, month)) {
      return `Sewa ${lease.id} sudah punya pembayaran untuk ${monthLabel(month, year)} (aturan B14).`;
    }
    return null;
  }

  /* -----------------------------------------------------------------------
     Operasi tulis
     ----------------------------------------------------------------------- */
  function addRoom(data) {
    const error = validateRoom(data);
    if (error) return { ok: false, message: error };
    const item = {
      id: nextId('K', rooms()),
      nomor: String(data.nomor).trim().toUpperCase(),
      tipe: data.tipe,
      harga: Number(data.harga),
      fasilitas: String(data.fasilitas).trim()
    };
    rooms().push(item);
    persist();
    return { ok: true, item: item };
  }

  function updateRoom(id, data) {
    const room = getRoom(id);
    if (!room) return { ok: false, message: 'Kamar tidak ditemukan.' };
    const error = validateRoom(data, id);
    if (error) return { ok: false, message: error };
    room.nomor = String(data.nomor).trim().toUpperCase();
    room.tipe = data.tipe;
    room.harga = Number(data.harga);
    room.fasilitas = String(data.fasilitas).trim();
    persist();
    return { ok: true, item: room };
  }

  function deleteRoom(id) {
    const room = getRoom(id);
    if (!room) return { ok: false, message: 'Kamar tidak ditemukan.' };
    if (leases().some((lease) => lease.id_kamar === id)) {
      return {
        ok: false,
        message: `Kamar ${room.nomor} punya riwayat sewa sehingga tidak boleh dihapus (aturan B10).`
      };
    }
    state.kamar = rooms().filter((item) => item.id !== id);
    persist();
    return { ok: true };
  }

  function addResident(data) {
    const error = validateResident(data);
    if (error) return { ok: false, message: error };
    const item = {
      id: nextId('P', residents()),
      nama: String(data.nama).trim(),
      telepon: String(data.telepon).trim(),
      telepon_ortu: String(data.telepon_ortu).trim(),
      alamat: String(data.alamat).trim()
    };
    residents().push(item);
    persist();
    return { ok: true, item: item };
  }

  function updateResident(id, data) {
    const person = getResident(id);
    if (!person) return { ok: false, message: 'Penghuni tidak ditemukan.' };
    const error = validateResident(data);
    if (error) return { ok: false, message: error };
    person.nama = String(data.nama).trim();
    person.telepon = String(data.telepon).trim();
    person.telepon_ortu = String(data.telepon_ortu).trim();
    person.alamat = String(data.alamat).trim();
    persist();
    return { ok: true, item: person };
  }

  function deleteResident(id) {
    const person = getResident(id);
    if (!person) return { ok: false, message: 'Penghuni tidak ditemukan.' };
    if (leases().some((lease) => lease.id_penghuni === id)) {
      return {
        ok: false,
        message: `${person.nama} punya catatan sewa sehingga tidak boleh dihapus (aturan B10).`
      };
    }
    state.penghuni = residents().filter((item) => item.id !== id);
    persist();
    return { ok: true };
  }

  function addLease(data) {
    const error = validateLease(data);
    if (error) return { ok: false, message: error };
    const room = getRoom(data.id_kamar);
    const item = {
      id: nextId('S', leases()),
      id_penghuni: data.id_penghuni,
      id_kamar: data.id_kamar,
      mulai: String(data.mulai),
      selesai: String(data.selesai),
      durasi: monthsBetween(data.mulai, data.selesai),
      harga: Number(room.harga),
      status: 'Aktif'
    };
    leases().push(item);
    persist();
    return { ok: true, item: item };
  }

  function endLease(id) {
    const lease = getLease(id);
    if (!lease) return { ok: false, message: 'Sewa tidak ditemukan.' };
    if (leaseStatus(lease) === 'Selesai') return { ok: false, message: 'Sewa ini sudah selesai.' };
    const t = today();
    if (parseISO(lease.mulai) >= t) {
      return { ok: false, message: 'Sewa belum dimulai, jadi belum bisa diakhiri.' };
    }
    lease.status = 'Selesai';
    lease.selesai = iso(t);
    lease.durasi = monthsBetween(lease.mulai, lease.selesai);
    persist();
    return { ok: true, item: lease };
  }

  function deleteLease(id) {
    const lease = getLease(id);
    if (!lease) return { ok: false, message: 'Sewa tidak ditemukan.' };
    if (payments().some((payment) => payment.id_sewa === id)) {
      return {
        ok: false,
        message: `Sewa ${lease.id} sudah punya pembayaran sehingga tidak boleh dihapus (aturan B10).`
      };
    }
    state.sewa = leases().filter((item) => item.id !== id);
    persist();
    return { ok: true };
  }

  function addPayment(data) {
    const error = validatePayment(data);
    if (error) return { ok: false, message: error };
    const item = {
      id: nextId('BY', payments()),
      id_sewa: data.id_sewa,
      bulan: Number(data.bulan),
      tahun: Number(data.tahun),
      tanggal: String(data.tanggal),
      nominal: Number(data.nominal),
      status: 'Lunas'
    };
    payments().push(item);
    persist();
    return { ok: true, item: item };
  }

  function deletePayment(id) {
    const payment = getPayment(id);
    if (!payment) return { ok: false, message: 'Pembayaran tidak ditemukan.' };
    state.pembayaran = payments().filter((item) => item.id !== id);
    persist();
    return { ok: true };
  }

  /* -----------------------------------------------------------------------
     Ekspor CSV
     ----------------------------------------------------------------------- */
  function csvPayments() {
    const header = [
      'ID Pembayaran', 'ID Sewa', 'Penghuni', 'Kamar', 'Periode',
      'Tanggal Bayar', 'Nominal', 'Status'
    ];
    const rows = payments()
      .slice()
      .sort((a, b) => (a.tanggal < b.tanggal ? -1 : 1))
      .map((payment) => {
        const lease = getLease(payment.id_sewa);
        const person = lease ? getResident(lease.id_penghuni) : null;
        const room = lease ? getRoom(lease.id_kamar) : null;
        return [
          payment.id,
          payment.id_sewa,
          person ? person.nama : '—',
          room ? room.nomor : '—',
          monthLabel(payment.bulan, payment.tahun),
          fmtDate(payment.tanggal),
          payment.nominal,
          payment.status
        ];
      });
    const escape = (value) => {
      const text = String(value == null ? '' : value);
      return /[",;\n]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text;
    };
    return [header].concat(rows).map((row) => row.map(escape).join(';')).join('\r\n');
  }

  /* -----------------------------------------------------------------------
     Ekspor API
     ----------------------------------------------------------------------- */
  global.KOS = {
    KEY: KEY,
    VERSION: VERSION,
    MONTHS: MONTHS,
    MONTHS_SHORT: MONTHS_SHORT,
    ROOM_TYPES: ROOM_TYPES,
    // tanggal & format
    today: today,
    parseISO: parseISO,
    iso: iso,
    addDays: addDays,
    addMonths: addMonths,
    daysBetween: daysBetween,
    monthsBetween: monthsBetween,
    isValidISO: isValidISO,
    fmtDate: fmtDate,
    fmtDateLong: fmtDateLong,
    fmtRupiah: fmtRupiah,
    fmtRupiahShort: fmtRupiahShort,
    monthLabel: monthLabel,
    monthKey: monthKey,
    // data
    rooms: rooms,
    residents: residents,
    leases: leases,
    payments: payments,
    getRoom: getRoom,
    getResident: getResident,
    getLease: getLease,
    getPayment: getPayment,
    // status
    leaseStatus: leaseStatus,
    roomStatus: roomStatus,
    occupantOf: occupantOf,
    activeLeases: activeLeases,
    periodsFor: periodsFor,
    paymentFor: paymentFor,
    paymentStatus: paymentStatus,
    dueDate: dueDate,
    overdueItems: overdueItems,
    summary: summary,
    recentPayments: recentPayments,
    leasesEndingSoon: leasesEndingSoon,
    // validasi
    validateRoom: validateRoom,
    validateResident: validateResident,
    validateLease: validateLease,
    validatePayment: validatePayment,
    // tulis
    addRoom: addRoom,
    updateRoom: updateRoom,
    deleteRoom: deleteRoom,
    addResident: addResident,
    updateResident: updateResident,
    deleteResident: deleteResident,
    addLease: addLease,
    endLease: endLease,
    deleteLease: deleteLease,
    addPayment: addPayment,
    deletePayment: deletePayment,
    // lain-lain
    resetDemo: resetDemo,
    csvPayments: csvPayments
  };
})(window);
