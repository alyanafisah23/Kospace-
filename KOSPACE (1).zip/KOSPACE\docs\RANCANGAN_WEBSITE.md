# RANCANGAN WEBSITE KOSPACE

| | |
|---|---|
| **Produk** | KOSPACE — Sistem Administrasi Pengelolaan Kos |
| **Jenis dokumen** | Rancangan antarmuka website (landing page + demo admin) |
| **Kelompok** | 4 |
| **Anggota** | Alya Nafisah (4.52.24.3.02) · Marensya Aurellya (4.52.24.3.15) · Permata Rayya A. A. (4.52.24.3.21) · Shintia Nova P. A. (4.52.24.3.25) |
| **Mata kuliah** | Pemrograman Bisnis & Perancangan Sistem Administrasi |
| **Dosen pengampu** | Dwi Budi Santoso, S.Kom., M.Kom. |
| **Sumber acuan** | `KOSPACE_revisi.pdf` (16 slide) dan `KOSPACE_ERD.pptx` (8 slide) |
| **Status** | Prototipe website statis, siap dibuka di browser |
| **Lokasi kode** | `kospace/website/` |

---

## 1. Ringkasan

Website KOSPACE terdiri dari dua halaman yang saling terhubung:

1. **Landing page** (`index.html`) — mempresentasikan rancangan sistem kepada
   dosen dan penguji: latar belakang, masalah, fitur, data kamar, model data,
   alur kerja, aturan bisnis, status otomatis, pratinjau, dan FAQ.
2. **Demo admin** (`app.html`) — prototipe antarmuka yang benar-benar bisa
   diklik. Pengguna dapat menambah kamar, menyimpan penghuni, membuat sewa,
   mencatat pembayaran, dan menelusuri riwayat. Aturan bisnis B01, B06, B08,
   B10, B14 serta deteksi jadwal bertabrakan dijalankan di sisi klien.

Tujuan website bukan menggantikan aplikasi Streamlit + SQLite, melainkan
menjadi **media presentasi rancangan** yang sekaligus memperlihatkan
pengalaman pengguna akhir secara nyata.

### Prinsip desain

1. **Satu sumber kebenaran** — semua angka di landing page diambil dari data
   demo yang sama dengan yang dipakai admin, sehingga tidak ada angka yang
   saling bertentangan.
2. **Status dihitung, bukan diisi** — status kamar, sewa, dan pembayaran
   diturunkan dari tanggal dan transaksi.
3. **Validasi terlihat** — kesalahan aturan bisnis muncul sebagai pesan
   berbahasa Indonesia yang menyebut kode aturannya.
4. **Bahasa Indonesia, istilah konsisten** — istilah mengikuti PPT: kamar,
   penghuni, sewa, pembayaran, Lunas, Belum Dibayar, Terlambat.
5. **Ramah presentasi** — tampilan bersih, kontras tinggi, dan tetap rapi saat
   diproyeksikan maupun dibuka di ponsel.

---

## 2. Pemetaan 16 Slide PPT ke Website

| Slide | Isi PPT | Ditempatkan di website |
|---|---|---|
| 1 | Judul, mata kuliah, dosen, anggota kelompok | Hero landing + footer tim |
| 2 | Gambaran umum: 25 kamar, 3 tipe, 4 tabel, 1 pengguna | Hero, strip statistik, kartu kamar, kartu entitas |
| 3 | Latar belakang, 3 masalah, 3 solusi | Section **Masalah** (`#masalah`) |
| 4 | 6 tujuan perancangan | Section **Fitur** (enam kartu fitur) + hero |
| 5 | Pengguna, ruang lingkup, batasan | Hero meta, section **FAQ** (batasan), footer |
| 6 | 6 fitur utama + prioritas Utama/Pendukung | Section **Fitur** (`#fitur`) dengan badge prioritas |
| 7 | Kebutuhan nonfungsional + aturan B01–B14 | Section **Aturan** (`#aturan`) + catatan teknis |
| 8 | Alur proses manual vs KOSPACE | Section **Alur** (`#alur`) dua panel 9 langkah |
| 9 | Status kamar, status pembayaran, jadwal bertabrakan | Section **Status** (`#status`) + aturan bentrok di demo |
| 10 | Empat entitas database | Section **Data** (`#data`) empat kartu entitas |
| 11 | ERD tiga relasi 1:N | Section **Data** (catatan ERD) |
| 12 | PK, FK, kode bisnis, format ID | Kartu entitas (chip PK/FK) + catatan ERD |
| 13 | Kamus data dan ketentuan atribut | Kartu entitas + validasi form di demo |
| 14 | Harga bulanan ganda & normalisasi 1NF–3NF | Catatan ERD + FAQ “Mengapa harga disalin” |
| 15 | Aturan penghapusan & integritas data | Aturan **B10** + tombol hapus di demo |
| 16 | Terima kasih | Section **CTA** + footer |

Dengan pemetaan ini, seluruh isi PPT dapat dijelaskan hanya dengan membuka
landing page, lalu dibuktikan pada demo admin.

---

## 3. Arsitektur Informasi

```
kospace/website/
├─ index.html            Landing page (presentasi rancangan)
│  ├─ #top               Hero + mock dashboard
│  ├─ stats              Strip 25 kamar / 3 tipe / 4 entitas / 5 aturan
│  ├─ #masalah           Latar belakang & 3 masalah
│  ├─ #fitur             6 fitur + prioritas
│  ├─ #kamar             3 tipe kamar + okupansi dinamis
│  ├─ #data              4 entitas + relasi 1:N
│  ├─ #alur              Proses manual vs KOSPACE
│  ├─ #aturan            B01, B06, B08, B10, B14
│  ├─ #status            Status kamar/sewa/pembayaran
│  ├─ #preview           Pratinjau aplikasi + CTA demo
│  ├─ #faq               Pertanyaan umum
│  └─ footer             Navigasi, demo, tim, tahun
└─ app.html              Demo admin (hash router)
   ├─ #dashboard         KPI, grafik okupansi, tunggakan, sewa aktif
   ├─ #kamar             Tabel + cari + filter tipe/status + CRUD
   ├─ #penghuni          Tabel + cari + CRUD
   ├─ #sewa              Tabel + cari/filter + buat/akhiri/hapus
   ├─ #pembayaran        Form pembayaran + tagihan per periode + tabel
   └─ #riwayat           Filter sewa + pencarian + ekspor CSV
```

Navigasi landing memakai anchor; navigasi admin memakai hash (`#kamar`,
`#pembayaran`, dst.) sehingga tombol back/forward browser tetap bekerja.

---

## 4. Design System

### 4.1 Palet warna

Warna diambil dari tema PPT KOSPACE, dengan logo navy `#1D3B66` sebagai
acuan utama.

| Peran | Token | Nilai | Pemakaian |
|---|---|---|---|
| Navy utama | `--navy-700` | `#1D3B66` | Logo, tombol utama, donut |
| Navy gelap | `--navy-900` | `#0E2038` | Sidebar, teks judul, footer |
| Navy PPT | `--navy-800` | `#1B3A5E` | Gradien sidebar, aksen |
| Oranye | `--orange-500` | `#F2A33A` | Aksen CTA, KPI tersedia, tipe B |
| Teal | `--teal-500` | `#2E8B7A` | Status sukses, tipe C |
| Latar | `--bg` | `#F4F7FB` | Latar halaman |
| Permukaan | `--surface` | `#FFFFFF` | Kartu, panel, tabel |
| Garis | `--line` | `#DFE7F0` | Border halus |
| Teks | `--ink` | `#1F2937` | Teks utama |
| Teks sekunder | `--muted` | `#5B6B7F` | Deskripsi |
| Bahaya | `--danger` | `#C0392B` | Terlambat, hapus, error |
| Peringatan | `--amber` | `#B9760F` | Belum Dibayar |

Setiap warna aksen memiliki tint (`--orange-50`, `--teal-50`, `--navy-50`)
untuk latar kartu dan badge agar kontras teks tetap aman.

### 4.2 Tipografi

- **Keluarga font:** Plus Jakarta Sans (Google Fonts), fallback
  `Segoe UI, system-ui, -apple-system, sans-serif`.
- **Skala:** H1 hero `clamp(2.1rem, 4.2vw, 3.35rem)`, H2 section
  `clamp(1.55rem, 2.6vw, 2.2rem)`, H3 kartu `1.05–1.2rem`, body `0.95–1rem`,
  label `0.72–0.8rem` dengan letter-spacing.
- **Bobot:** 400 body, 500–600 label, 700–800 judul dan angka KPI.
- **Angka:** memakai `font-variant-numeric: tabular-nums` pada KPI/tabel agar
  kolom rupiah sejajar.

### 4.3 Layout, spasi, radius

- Container maksimum **1180px**, padding samping 20px (desktop) dan 16px
  (mobile).
- Grid 12 kolom implisit melalui utilitas `.grid-2`, `.grid-3`, `.grid-4`.
- Skala spasi kelipatan 4px: 4, 8, 12, 16, 20, 24, 32, 40, 56, 72, 96.
- Radius: `8px` (xs), `11px` (sm), `16px` (md), `24px` (lg), `32px` (xl),
  `999px` (pill).
- Bayangan berlapis lembut: `xs` untuk kartu, `md` untuk hover, `lg` untuk
  mock dashboard dan modal.

### 4.4 Gerak

- Easing utama `cubic-bezier(0.22, 0.61, 0.36, 1)`.
- Durasi 160–260ms untuk hover/transisi, 600ms untuk reveal dan progress bar.
- `prefers-reduced-motion: reduce` mematikan reveal, penghitung angka, dan
  transisi panjang.

### 4.5 Komponen bersama

| Komponen | Kelas | Catatan |
|---|---|---|
| Tombol | `.btn` + `--primary`, `--ghost`, `--accent`, `--soft`, `--danger`, `--sm`, `--lg`, `--block` | Fokus ring 3px, ikon SVG 18px |
| Badge status | `.badge--green`, `--amber`, `--red`, `--navy`, `--muted` | Teks + titik warna |
| Kartu | `.icon-card`, `.feature-card`, `.room-card`, `.entity-card`, `.rule-card`, `.status-card` | Border 1px, hover lift |
| Panel admin | `.panel`, `.panel__head`, `.panel__title`, `.panel__sub` | Wadah tabel dan form |
| Form | `.field`, `.input`, `.select`, `.textarea`, `.hint`, `.form-error` | Label eksplisit, error `role` |
| Tabel | `.table-wrap`, `table.data` | Header sticky, zebra halus, scroll horizontal |
| Modal | `.modal-root`, `.modal`, `.modal__head/body/foot` | Fokus ke dialog, Esc menutup |
| Toast | `.toast-root`, `.toast--success/error/info` | Muncul kanan atas, auto-dismiss |
| Empty state | `.empty-state` | Ikon + judul + saran tindakan |

---

## 5. Landing Page

### 5.1 Struktur & wireframe

```
┌──────────────────────────────────────────────────────────────┐
│ HEADER  [logo] KOSPACE        Masalah Fitur Kamar Data ...   │
│                                  [Lihat Demo] [Buka Admin]   │
├──────────────────────────────────────────────────────────────┤
│ HERO                                                          │
│ ┌───────────────────────┐   ┌─────────────────────────────┐  │
│ │ badge sistem          │   │  mock browser KOSPACE        │  │
│ │ H1 25 kamar           │   │  Total | Tersedia | Sewa     │  │
│ │ lead paragraf         │   │  donut okupansi | bar tipe   │  │
│ │ [Coba Demo] [Fitur]   │   │  catatan status otomatis     │  │
│ │ ✓ 4 entitas ✓ status  │   └─────────────────────────────┘  │
│ └───────────────────────┘   float: 5 terisi / Rp3,5 jt       │
├──────────────────────────────────────────────────────────────┤
│ STATS   25 kamar | 3 tipe | 4 entitas | 5 aturan             │
├──────────────────────────────────────────────────────────────┤
│ MASALAH  judul + 3 kartu (data tersebar, kamar tidak akurat,  │
│          riwayat sulit)                                       │
├──────────────────────────────────────────────────────────────┤
│ FITUR    6 kartu + badge prioritas Utama/Pendukung            │
├──────────────────────────────────────────────────────────────┤
│ KAMAR    3 kartu tipe A/B/C + harga + fasilitas + okupansi    │
├──────────────────────────────────────────────────────────────┤
│ DATA     4 kartu entitas (PK/FK) + catatan relasi 1:N         │
├──────────────────────────────────────────────────────────────┤
│ ALUR     panel manual (9 langkah) | panel KOSPACE (9 langkah) │
├──────────────────────────────────────────────────────────────┤
│ ATURAN   5 kartu B01 B06 B08 B10 B14 + contoh diterima/ditolak│
├──────────────────────────────────────────────────────────────┤
│ STATUS   3 kartu: kamar, sewa, pembayaran                     │
├──────────────────────────────────────────────────────────────┤
│ PRATINJAU  salinan copy + jendela aplikasi mini               │
├──────────────────────────────────────────────────────────────┤
│ FAQ      6 pertanyaan (details/summary)                       │
├──────────────────────────────────────────────────────────────┤
│ CTA      ajakan + [Buka Demo Admin] [Lihat Rancangan]         │
├──────────────────────────────────────────────────────────────┤
│ FOOTER   logo putih | navigasi | demo | tim + NIM | copyright │
└──────────────────────────────────────────────────────────────┘
```

### 5.2 Detail section

1. **Header** — sticky dengan blur; berubah warna saat halaman digulir.
   Di layar ≤960px navigasi menjadi menu dropdown yang dikontrol tombol
   hamburger (`aria-expanded`).
2. **Hero** — pesan utama “Kelola 25 kamar tanpa buku catatan yang tercecer”.
   Mock dashboard memakai angka nyata dari `K.summary()`; donut dan bar
   dihitung dari okupansi. Dua kartu mengambang menampilkan kamar terisi dan
   pendapatan bulan ini.
3. **Strip statistik** — empat angka dengan animasi hitung saat terlihat.
4. **Masalah** — tiga kartu mengikuti slide 3, masing-masing diakhiri tag
   solusi agar transisi ke fitur terasa logis.
5. **Fitur** — enam kartu sesuai slide 6, badge **Utama** (oranye) dan
   **Pendukung** (navy) mengikuti prioritas PPT.
6. **Kamar** — tiga kartu tipe dengan harga, fasilitas, dan progress okupansi
   yang dihitung dari data demo. Tautan “Lihat di demo” menuju `app.html#kamar`.
7. **Data** — empat kartu entitas dengan chip PK/FK/unik, diikuti catatan
   relasi 1:N dan alasan harga bulanan disalin ke sewa (slide 11–14).
8. **Alur** — dua panel berdampingan: 9 langkah manual (merah/oranye) dan
   9 langkah dengan KOSPACE (teal), mengikuti slide 8.
9. **Aturan** — lima kartu B01–B14 dengan contoh diterima (✓) dan ditolak (✕).
10. **Status** — tiga kartu yang menjelaskan status kamar, sewa, dan
    pembayaran, termasuk definisi jatuh tempo tanggal 10 (slide 9).
11. **Pratinjau** — salinan penjelasan demo + jendela aplikasi mini berisi KPI,
    donut, bar tipe, dan cuplikan tabel pembayaran.
12. **FAQ** — enam pertanyaan: kebutuhan server, perbedaan dengan Streamlit,
    reset data, batasan (tanpa login/online), alasan harga disalin, dan ekspor.
13. **CTA** — ajakan membuka demo; tombol kedua menuju dokumen rancangan.
14. **Footer** — logo putih, tiga kolom tautan, daftar tim + NIM, tahun berjalan.

### 5.3 Data dinamis di landing

`landing.js` memanggil `KOS.summary()` lalu mengisi:

- `[data-hero-occupied]`, `[data-hero-available]`, `[data-hero-active]`,
  `[data-hero-arrears]`, `[data-hero-month]`
- `[data-occupancy]` dan `[data-donut]` (stroke-dashoffset)
- `[data-room-fill]`, `[data-room-count]`, `[data-room-avail]` per tipe
- `[data-preview-*]` dan `[data-total-*]`

Dengan begitu, jika pengguna mengubah data di demo lalu kembali ke landing,
angka yang tampil ikut berubah.

---

## 6. Demo Admin

### 6.1 Kerangka aplikasi

```
┌───────────────┬──────────────────────────────────────────────┐
│ SIDEBAR       │ TOPBAR                                       │
│ [logo] KOSPACE│ [menu] KOSPACE · Admin   Dashboard  [tanggal]│
│ Admin demo    │                                       [Landing]│
│               ├──────────────────────────────────────────────┤
│ MENU UTAMA    │ KONTEN HALAMAN                               │
│ ▸ Dashboard   │                                              │
│ ▸ Data Kamar  │  judul + deskripsi + aksi utama              │
│ ▸ Penghuni    │  ┌────────┐ ┌────────┐ ┌────────┐            │
│ ▸ Data Sewa   │  │ panel  │ │ panel  │ │ panel  │            │
│ ▸ Pembayaran  │  └────────┘ └────────┘ └────────┘            │
│ ▸ Riwayat     │                                              │
│               │                                              │
│ Mode demo     │                                              │
│ [Reset data]  │                                              │
│ ← Landing     │                                              │
└───────────────┴──────────────────────────────────────────────┘
```

- Sidebar navy bergradien, lebar 264px, sticky di desktop.
- Di ≤900px sidebar menjadi off-canvas; tombol hamburger di topbar membuka
  overlay, klik overlay atau `Esc` menutup.
- Topbar menampilkan tanggal hari ini dalam format Indonesia dan tautan
  kembali ke landing.

### 6.2 Dashboard (`#dashboard`)

```
┌──────────────────────────────────────────────────────────────┐
│ Ringkasan operasional                                         │
│ Pantau okupansi dan pembayaran bulan ini                      │
│ ┌────────┐┌────────┐┌────────┐┌────────┐┌────────┐            │
│ │Total 25││Tersedia││Ditempati││Sewa    ││Bulan ini│           │
│ │        ││  20    ││   5    ││aktif 5 ││Rp3,5 jt │           │
│ └────────┘└────────┘└────────┘└────────┘└────────┘            │
│ ┌─────────────────────────┐ ┌──────────────────────────────┐ │
│ │ Okupansi per tipe       │ │ Tunggakan                    │ │
│ │ donut 20% + bar A/B/C   │ │ daftar sewa terlambat + [Catat]│ │
│ └─────────────────────────┘ └──────────────────────────────┘ │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ Sewa aktif: penghuni, kamar, periode, status, aksi      │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

KPI: total kamar, tersedia, ditempati, sewa aktif, pembayaran bulan ini,
tunggakan. Tombol **Catat** pada tunggakan membuka halaman pembayaran dengan
sewa, bulan, dan tahun yang sudah terisi.

### 6.3 Data Kamar (`#kamar`)

- Toolbar: pencarian (nomor/tipe/fasilitas), filter tipe A/B/C, filter status,
  tombol **Tambah kamar**, dan jumlah hasil (“25 dari 25 kamar”).
- Tabel: nomor, tipe, harga, fasilitas, status (badge), aksi ubah/hapus.
- Form tambah/ubah: nomor, tipe, harga (otomatis mengikuti tipe tetapi bisa
  diubah), fasilitas. Validasi B01 untuk nomor unik.
- Hapus: dialog konfirmasi; ditolak dengan pesan B10 bila kamar punya riwayat
  sewa.

### 6.4 Data Penghuni (`#penghuni`)

- Pencarian nama/telepon/alamat.
- Tabel: ID, nama, telepon, telepon orang tua, alamat, aksi.
- Form: nama, telepon, telepon orang tua, alamat.
- Hapus ditolak (B10) bila penghuni punya catatan sewa.

### 6.5 Data Sewa (`#sewa`)

- Toolbar: pencarian, filter status Aktif/Selesai, tombol **Buat sewa**.
- Tabel: ID, penghuni, kamar, tanggal mulai–selesai, durasi, harga, status,
  aksi **Akhiri**/hapus.
- Form sewa: penghuni, kamar, tanggal mulai, tanggal selesai, lalu **pratinjau**
  durasi dan harga yang dihitung otomatis.
- Validasi: B06 (selesai > mulai), deteksi jadwal bertabrakan pada kamar yang
  sama, dan harga disalin dari kamar saat sewa dibuat.
- **Akhiri** mengubah status menjadi Selesai lebih awal; hapus ditolak bila
  sudah ada pembayaran.

### 6.6 Pembayaran (`#pembayaran`)

```
┌───────────────────────────────┐ ┌──────────────────────────────┐
│ Catat pembayaran              │ │ Tagihan per sewa             │
│ Sewa [S004 — Shintia — C05]   │ │ S004 · Shintia · Kamar C05   │
│ Bulan [Oktober] Tahun [2026]  │ │ Total Rp4.900.000            │
│ Tanggal bayar [09-11-2026]    │ │ Dibayar Rp700.000            │
│ Nominal [700000]              │ │ Sisa Rp4.200.000             │
│ Jatuh tempo 10-10-2026 ·      │ │ Oktober 2026 JT 10-10 Lunas  │
│ Status: Terlambat             │ │ November 2026 ... Terlambat  │
│ [Simpan Pembayaran]           │ └──────────────────────────────┘
└───────────────────────────────┘
┌──────────────────────────────────────────────────────────────┐
│ Pembayaran tercatat: ID, tanggal, penghuni, kamar, periode,   │
│ nominal, status, detail/hapus                                 │
└──────────────────────────────────────────────────────────────┘
```

- Nominal otomatis terisi harga sewa saat sewa diganti.
- Hint jatuh tempo dan status periode berubah saat bulan/tahun diganti.
- Validasi B08 (nominal > 0 dan sama dengan harga sewa) dan B14 (satu
  pembayaran per sewa/bulan/tahun).
- Panel kanan menampilkan seluruh periode sewa beserta status per periode.
- Pesan error dibersihkan otomatis ketika pilihan sewa/periode diubah.

### 6.7 Riwayat (`#riwayat`)

- Filter sewa (semua atau satu sewa) dan pencarian bebas (penghuni, kamar,
  ID pembayaran).
- Tabel kronologis terbaru lebih dulu, dengan aksi detail dan hapus.
- Tombol **Unduh CSV** mengekspor rekap pembayaran (ID, tanggal, penghuni,
  kamar, periode, nominal, status).

---

## 7. Data, Status, dan Aturan Bisnis di UI

### 7.1 Data contoh

| Entitas | Isi |
|---|---|
| Kamar | 25 baris: A01–A05 (Rp1.300.000), B01–B10 (Rp950.000), C01–C10 (Rp700.000) |
| Penghuni | 5 orang: Alya, Marensya, Shintia, Permata, Nadia |
| Sewa | 5 sewa aktif pada A01, A03, B03, C05, C08 |
| Pembayaran | 11 pembayaran; S004 (C05) sengaja kosong agar ada tunggakan |

Tanggal seed dihitung relatif terhadap hari ini, sehingga demo selalu relevan
kapan pun dibuka.

### 7.2 Status

| Objek | Aturan | Nilai |
|---|---|---|
| Kamar | Ada sewa aktif yang mencakup hari ini? | Ditempati / Tersedia |
| Sewa | Tanggal selesai ≥ hari ini dan belum diakhiri? | Aktif / Selesai |
| Pembayaran | Sudah ada catatan? Jika belum, lewat tanggal 10? | Lunas / Belum Dibayar / Terlambat |

Jatuh tempo adalah tanggal 10. Untuk periode pertama, jika tanggal mulai sewa
jatuh setelah tanggal 10, jatuh tempo mengikuti tanggal mulai.

### 7.3 Validasi dan pesan

| Kode | Kondisi | Pesan |
|---|---|---|
| B01 | Nomor kamar sudah dipakai | `Nomor kamar A01 sudah dipakai (aturan B01).` |
| B06 | Tanggal selesai ≤ tanggal mulai | `Tanggal selesai harus setelah tanggal mulai (aturan B06).` |
| — | Jadwal bertabrakan | `Jadwal bertabrakan dengan sewa S001 (Alya Nafisah) pada 09-09-2026–09-09-2027.` |
| B08 | Nominal ≤ 0 atau ≠ harga sewa | `Nominal harus sama dengan harga sewa (aturan B08).` |
| B10 | Hapus data yang punya riwayat | `Kamar A01 punya riwayat sewa sehingga tidak boleh dihapus (aturan B10).` |
| B14 | Pembayaran ganda periode sama | `Sewa S001 sudah punya pembayaran untuk November 2026 (aturan B14).` |

Rumus bentrok: `baru.mulai <= lama.selesai DAN baru.selesai >= lama.mulai`.

---

## 8. Interaksi & State

- **Penyimpanan:** `localStorage` dengan kunci `kospace_website_demo_v1`.
  Struktur: `{ version, kamar, penghuni, sewa, pembayaran }`.
- **Seed:** dibuat saat pertama kali dibuka atau setelah reset.
- **Routing:** hash router (`#dashboard`, `#kamar`, …) yang memanggil renderer
  per halaman dan menyorot menu aktif.
- **State UI:** disimpan di objek `ui` (pencarian, filter, pilihan pembayaran)
  dan tidak ikut tersimpan permanen.
- **Modal:** satu root modal; fokus dipindahkan ke dialog, `Esc` menutup,
  klik latar menutup.
- **Toast:** notifikasi sukses/error/info, hilang otomatis.
- **Reset:** dialog konfirmasi, lalu data contoh dimuat ulang dan halaman
  dirender kembali.
- **Ekspor CSV:** `Blob` + `URL.createObjectURL`, dipicu tombol unduh.

---

## 9. Responsif

| Breakpoint | Landing | Admin |
|---|---|---|
| ≥1081px | Grid 3–4 kolom, nav lengkap | Sidebar 264px, grid 2–3 kolom |
| 961–1080px | Grid mulai rapat | Sidebar tetap, beberapa panel menumpuk |
| 761–960px | Nav menjadi menu hamburger | Sidebar off-canvas, topbar menu muncul |
| ≤760px | Grid 1–2 kolom, hero menumpuk | Konten 1 kolom, toolbar membungkus |
| ≤560px | Padding 16px, tipografi mengecil, kartu penuh | Tombol melebar, tabel scroll horizontal |

Prinsip: tidak ada scroll horizontal pada halaman; hanya tabel yang boleh
menggulir di dalam `.table-wrap`.

---

## 10. Aksesibilitas

- Struktur semantik: `header`, `nav`, `main`, `section`, `footer`, heading
  berurutan.
- `skip-link` “Lewati ke konten utama” di kedua halaman.
- Semua gambar logo memiliki `alt`; ikon dekoratif memakai `aria-hidden`.
- Tombol navigasi seluler memakai `aria-expanded` dan `aria-controls`.
- Form memakai `<label for>` eksplisit; pesan error ditempatkan dekat field.
- Kontras teks utama di atas latar memenuhi WCAG AA untuk teks normal.
- Fokus keyboard terlihat (ring 3px) pada tombol, tautan, input, dan select.
- Mendukung `prefers-reduced-motion`.
- Modal dapat ditutup dengan `Esc`; overlay tidak menjebak fokus di luar
  dialog saat terbuka.

---

## 11. Aset & Performa

- Logo asli `logo_kospace.png` diolah menjadi:
  - `logo_kospace_transparent.png` — header terang,
  - `logo_kospace_white.png` — footer/sidebar gelap,
  - `logo_icon.png` / `logo_icon_white.png` — ikon kecil,
  - `favicon.png` — ikon tab browser.
- Tanpa framework CSS/JS, tanpa build step. Total aset ringan.
- Font eksternal dimuat dengan `display=swap`; jika offline, fallback sistem
  tetap nyaman dibaca.
- Animasi memakai `transform`/`opacity` agar tidak memicu layout ulang.
- Angka dan tabel memakai `tabular-nums` untuk mencegah teks “meloncat”.

---

## 12. Struktur File

```
kospace/website/
├─ index.html                 Landing page
├─ app.html                   Demo admin
├─ README.md                  Cara menjalankan + panduan demo
├─ assets/
│  ├─ favicon.png
│  ├─ logo_icon.png
│  ├─ logo_icon_white.png
│  ├─ logo_kospace.png
│  ├─ logo_kospace_transparent.png
│  └─ logo_kospace_white.png
├─ css/
│  ├─ base.css                Token, reset, komponen dasar
│  ├─ landing.css             Gaya landing
│  └─ app.css                 Gaya admin
└─ js/
   ├─ data.js                 Data, localStorage, status, validasi, CSV
   ├─ landing.js              Interaksi landing
   └─ app.js                  Router + interaksi admin
```

---

## 13. Cara Menjalankan & Uji Coba

### Menjalankan

```powershell
cd "kospace"
python -m http.server 8765 --bind 127.0.0.1
```

Buka `http://127.0.0.1:8765/website/index.html` untuk landing dan
`http://127.0.0.1:8765/website/app.html` untuk demo admin. Alternatif: buka
`website/index.html` langsung di browser. Server dijalankan dari folder
`kospace` agar tautan **Lihat Rancangan** menuju dokumen ini tetap berfungsi.

### Skenario uji manual

1. **Landing** — buka di desktop dan ponsel; pastikan tidak ada scroll
   horizontal, logo tampil, menu seluler bisa dibuka/tutup, dan angka
   ketersediaan sesuai data demo.
2. **B01** — Data Kamar → Tambah → nomor `A01` → muncul pesan B01; ganti ke
   `A26` → kamar bertambah.
3. **B10** — Hapus kamar `A01` → ditolak dengan pesan riwayat sewa.
4. **B06 + bentrok** — Data Sewa → Buat → kamar `A01`, mulai `2027-01-01` →
   ditolak karena bertabrakan dengan S001; ganti kamar ke `A02` → sewa
   berhasil.
5. **B08** — Pembayaran → isi nominal `0` atau bukan harga sewa → ditolak.
6. **B14** — Pembayaran → pilih S001 periode yang sudah dibayar → ditolak;
   pilih S004 Oktober 2026 → berhasil, status periode berubah menjadi Lunas.
7. **Riwayat** — filter sewa, cari nama, lalu **Unduh CSV**.
8. **Reset** — sidebar → Reset data demo → data kembali ke contoh awal.

### Hasil pengujian yang sudah dilakukan

- Landing dan admin dimuat tanpa error konsol.
- Semua gambar logo berhasil dimuat (`naturalWidth > 0`).
- Tidak ada overflow horizontal pada 390px, 768px, 1024px, dan 1440px.
- Menu seluler landing dan sidebar admin berfungsi.
- B01, B06, bentrok, B08, B10, dan B14 menghasilkan pesan yang benar.
- Pembayaran S004 Oktober 2026 berhasil dan panel periode menampilkan
  **Lunas**.
- Hint jatuh tempo menampilkan `10-10-2026` untuk S004 Oktober 2026 dan
  `10-11-2026` untuk November 2026.

---

## 14. Batasan & Rekomendasi Lanjutan

Sesuai ruang lingkup PPT, website demo ini **belum** mencakup:

- login dan hak akses,
- pemesanan mandiri oleh penghuni,
- pembayaran online dan deposit,
- kuitansi, pengingat WhatsApp, dan token listrik,
- deployment ke internet.

Rekomendasi pengembangan berikutnya:

1. Hubungkan demo ke API aplikasi Streamlit/SQLite agar data nyata dipakai
   bersama.
2. Tambahkan autentikasi sederhana untuk pemilik kos.
3. Tambahkan kuitansi PDF dan pengingat jatuh tempo.
4. Tambahkan grafik tren pembayaran per bulan dan ekspor laporan tahunan.
5. Pertahankan validasi aturan bisnis di server, bukan hanya di klien, saat
   aplikasi dipakai bersama.
