"""Halaman pencatatan dan riwayat Pembayaran."""

from __future__ import annotations

from html import escape

import streamlit as st

from ..config import MONTHS_ID
from ..database import db
from ..repositories import pembayaran as repo
from ..repositories import sewa as repo_sewa
from ..utils import fmt_date, fmt_date_short, month_label, month_span, rupiah, today
from ..validators import ValidationError
from .components import (
    badge,
    empty_state,
    flash,
    kpi_card,
    muted,
    page_header,
    strong,
    table,
)


def render() -> None:
    page_header(
        "Transaksi",
        "Pembayaran",
        "Catat pembayaran per periode, pantau status tagihan, dan perbaiki "
        "salah catat tanpa mengubah data lain.",
    )
    tab_catat, tab_riwayat, tab_tagihan = st.tabs(
        ["Catat Pembayaran", "Riwayat Pembayaran", "Tagihan per Sewa"]
    )
    with tab_catat:
        _catat()
    with tab_riwayat:
        _riwayat()
    with tab_tagihan:
        _tagihan()


def _catat() -> None:
    with db() as conn:
        rows = repo_sewa.list_sewa(conn)

    if not rows:
        empty_state(
            "Belum ada sewa",
            "Buat sewa terlebih dahulu sebelum mencatat pembayaran.",
        )
        return

    peta = {str(r["id_sewa"]): r for r in rows}
    id_sewa = st.selectbox(
        "Pilih sewa",
        list(peta),
        format_func=lambda k: (
            f"{k} — {peta[k]['nama_penghuni']} — Kamar "
            f"{peta[k]['nomor_kamar']} — {peta[k]['status_sewa']}"
        ),
        key="bayar_pilih_sewa",
    )
    sewa = peta[id_sewa]
    harga = int(sewa["harga_bulanan"])

    kiri, kanan = st.columns([1.25, 1.0])
    with kiri:
        st.markdown("#### Detail pembayaran")
        opsi = month_span(sewa["tanggal_mulai"], sewa["tanggal_selesai"])
        with db() as conn:
            dibayar = repo.paid_map(conn, id_sewa)
            jadwal = repo.billing_schedule(conn, sewa)
        jatuh_tempo = {
            (int(j["periode_tahun"]), int(j["periode_bulan"])): j["jatuh_tempo"]
            for j in jadwal
        }
        belum = [p for p in opsi if p not in dibayar]
        indeks = opsi.index(belum[0]) if belum else len(opsi) - 1

        periode = st.selectbox(
            "Periode pembayaran",
            opsi,
            index=indeks,
            format_func=lambda p: month_label(p[1], p[0]),
            key=f"bayar_periode_{id_sewa}",
        )
        tanggal_bayar = st.date_input(
            "Tanggal bayar",
            value=today(),
            format="DD/MM/YYYY",
            key=f"bayar_tanggal_{id_sewa}",
        )
        nominal = st.number_input(
            "Nominal (Rp)",
            min_value=0,
            step=50_000,
            format="%d",
            value=harga,
            key=f"bayar_nominal_{id_sewa}",
            help="Nominal harus sama dengan harga sewa (aturan B08).",
        )
        tempo = jatuh_tempo.get((periode[0], periode[1]))
        st.caption(
            f"Periode dipilih: **{month_label(periode[1], periode[0])}** · "
            f"Jatuh tempo {fmt_date_short(tempo)}."
        )

        if (periode[0], periode[1]) in dibayar:
            st.warning(
                f"Periode {month_label(periode[1], periode[0])} sudah dibayar "
                f"({dibayar[(periode[0], periode[1])]['id_pembayaran']}). "
                "Satu periode hanya boleh dibayar sekali (B14).",
                icon="⚠️",
            )

        if st.button(
            "Simpan Pembayaran", type="primary", use_container_width=True
        ):
            try:
                with db() as conn:
                    id_bayar = repo.create_pembayaran(
                        conn,
                        id_sewa,
                        periode[1],
                        periode[0],
                        tanggal_bayar,
                        nominal,
                    )
                flash(
                    "success",
                    f"Pembayaran {id_bayar} untuk periode "
                    f"{month_label(periode[1], periode[0])} berhasil dicatat.",
                )
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))

    with kanan:
        st.markdown(
            f"""
            <div class="ks-card">
                <div class="ks-card-head">
                    <div class="ks-card-title">Sewa {escape(id_sewa)}</div>
                    {badge(str(sewa['status_sewa']))}
                </div>
                <div style="font-size:.88rem;line-height:1.9;color:#2B1B27">
                    <b>{escape(str(sewa['nama_penghuni']))}</b> ·
                    Kamar {escape(str(sewa['nomor_kamar']))}<br>
                    {fmt_date(sewa['tanggal_mulai'])} s.d.
                    {fmt_date(sewa['tanggal_selesai'])}<br>
                    Harga sewa: <b>{rupiah(harga)}</b> / bulan
                </div>
                <div style="margin-top:14px;padding-top:14px;
                            border-top:1px solid #EADFE6;font-size:.8rem;
                            color:#7A6B74">
                    {len(dibayar)} dari {len(opsi)} periode sudah dibayar ·
                    Total {rupiah(sewa['total_dibayar'])}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.info(
            "Status pembayaran tersimpan sebagai Lunas. Status Belum Dibayar "
            "dan Terlambat dihitung otomatis pada tab Tagihan per Sewa.",
            icon="ℹ️",
        )


def _riwayat() -> None:
    with db() as conn:
        semua = repo.list_pembayaran(conn)
        tahun_rows = conn.execute(
            "SELECT DISTINCT periode_tahun FROM pembayaran ORDER BY periode_tahun DESC"
        ).fetchall()

    if not semua:
        empty_state(
            "Belum ada pembayaran",
            "Catat pembayaran pertama pada tab Catat Pembayaran.",
        )
        return

    tahun_opsi = ["Semua"] + [int(r[0]) for r in tahun_rows]
    bulan_opsi = ["Semua"] + list(range(1, 13))

    kiri, tengah, kanan = st.columns([1.0, 1.0, 2.0])
    tahun = kiri.selectbox("Tahun", tahun_opsi, key="bayar_filter_tahun")
    bulan = tengah.selectbox(
        "Bulan",
        bulan_opsi,
        format_func=lambda b: "Semua" if b == "Semua" else MONTHS_ID[int(b) - 1],
        key="bayar_filter_bulan",
    )
    q = kanan.text_input(
        "Cari pembayaran",
        placeholder="Nama penghuni, nomor kamar, atau ID pembayaran…",
        key="bayar_cari",
    )

    with db() as conn:
        rows = repo.list_pembayaran(
            conn,
            tahun=None if tahun == "Semua" else int(tahun),
            bulan=None if bulan == "Semua" else int(bulan),
            q=q,
        )

    isi = []
    total = 0
    for row in rows:
        total += int(row["nominal"])
        isi.append(
            [
                strong(str(row["id_pembayaran"])),
                escape(str(row["nama_penghuni"])),
                escape(str(row["nomor_kamar"])),
                escape(
                    f"{MONTHS_ID[int(row['periode_bulan']) - 1]} "
                    f"{row['periode_tahun']}"
                ),
                rupiah(row["nominal"]),
                fmt_date(row["tanggal_bayar"]),
                badge(str(row["status_pembayaran"])),
            ]
        )

    table(
        ["ID", "Penghuni", "Kamar", "Periode", "Nominal", "Dibayar", "Status"],
        isi,
        empty_title="Tidak ada pembayaran",
        empty_message="Coba ubah filter tahun atau bulan.",
    )
    st.caption(f"{len(rows)} pembayaran · Total {rupiah(total)}")

    st.divider()
    st.markdown("#### Koreksi pembayaran")
    st.caption(
        "Pembayaran boleh dihapus hanya untuk memperbaiki salah catat. "
        "Penghapusan tidak memengaruhi data sewa atau kamar."
    )
    peta = {str(r["id_pembayaran"]): r for r in rows}
    if not peta:
        st.caption("Tidak ada pembayaran yang bisa dihapus pada filter ini.")
        return

    id_bayar = st.selectbox(
        "Pilih pembayaran",
        list(peta),
        format_func=lambda k: (
            f"{k} — {peta[k]['nama_penghuni']} — "
            f"{month_label(peta[k]['periode_bulan'], peta[k]['periode_tahun'])} — "
            f"{rupiah(peta[k]['nominal'])}"
        ),
        key="bayar_pilih_hapus",
    )
    yakin = st.checkbox(
        "Saya yakin ingin menghapus pembayaran ini",
        key=f"hapus_yakin_bayar_{id_bayar}",
    )
    if st.button(
        "Hapus Pembayaran",
        type="primary",
        disabled=not yakin,
        key=f"hapus_bayar_{id_bayar}",
    ):
        try:
            with db() as conn:
                repo.delete_pembayaran(conn, id_bayar)
            flash("success", f"Pembayaran {id_bayar} berhasil dihapus.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))


def _tagihan() -> None:
    with db() as conn:
        rows = repo_sewa.list_sewa(conn)

    if not rows:
        empty_state(
            "Belum ada sewa",
            "Tagihan akan muncul setelah sewa dibuat.",
        )
        return

    peta = {str(r["id_sewa"]): r for r in rows}
    id_sewa = st.selectbox(
        "Pilih sewa",
        list(peta),
        format_func=lambda k: (
            f"{k} — {peta[k]['nama_penghuni']} — Kamar "
            f"{peta[k]['nomor_kamar']} — {peta[k]['status_sewa']}"
        ),
        key="tagihan_pilih_sewa",
    )
    sewa = peta[id_sewa]

    with db() as conn:
        jadwal = repo.billing_schedule(conn, sewa)

    lunas = [j for j in jadwal if j["status"] == "Lunas"]
    terlambat = [j for j in jadwal if j["status"] == "Terlambat"]
    belum = [j for j in jadwal if j["status"] == "Belum Dibayar"]
    total_tagihan = len(jadwal) * int(sewa["harga_bulanan"])
    total_dibayar = len(lunas) * int(sewa["harga_bulanan"])

    kolom = st.columns(3)
    with kolom[0]:
        kpi_card(
            "Total Tagihan",
            rupiah(total_tagihan),
            f"{len(jadwal)} periode",
            tone="plum",
            icon="▤",
        )
    with kolom[1]:
        kpi_card(
            "Sudah Dibayar",
            rupiah(total_dibayar),
            f"{len(lunas)} periode lunas",
            tone="green",
            icon="✓",
        )
    with kolom[2]:
        kpi_card(
            "Sisa Tagihan",
            rupiah(total_tagihan - total_dibayar),
            f"{len(terlambat)} terlambat · {len(belum)} belum jatuh tempo",
            tone="red" if terlambat else "amber",
            icon="!",
        )

    st.write("")
    isi = []
    for item in jadwal:
        bayar = item["pembayaran"]
        isi.append(
            [
                strong(str(item["label"])),
                fmt_date_short(item["jatuh_tempo"]),
                rupiah(item["nominal"]),
                badge(str(item["status"])),
                escape(str(bayar["id_pembayaran"])) if bayar else muted("—"),
                fmt_date_short(bayar["tanggal_bayar"]) if bayar else muted("—"),
            ]
        )
    table(
        ["Periode", "Jatuh Tempo", "Nominal", "Status", "ID Bayar", "Tanggal Bayar"],
        isi,
        empty_title="Belum ada tagihan",
    )
    st.caption(
        "Status Belum Dibayar berarti periode belum lewat tanggal 10. "
        "Status Terlambat muncul setelah tanggal 10 terlewati."
    )
