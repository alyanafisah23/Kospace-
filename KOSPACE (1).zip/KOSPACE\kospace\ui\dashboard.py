"""Halaman Dashboard."""

from __future__ import annotations

from html import escape

import streamlit as st

from ..config import MONTHS_ID, ROOM_TYPES
from ..services import dashboard as svc
from ..utils import days_between, fmt_date_short, rupiah, today
from .components import (
    bar_row,
    card_header,
    donut,
    goto,
    kpi_card,
    page_header,
    strong,
    table,
)


def render() -> None:
    page_header(
        "Ringkasan Operasional",
        "Dashboard",
        "Pantau okupansi kamar, sewa berjalan, dan pembayaran kos "
        "dalam satu layar.",
    )

    data = svc.ringkasan()

    # ------------------------------------------------------------------
    # Aksi cepat
    # ------------------------------------------------------------------
    aksi = st.columns([1.1, 1.1, 1.1, 2.7])
    with aksi[0]:
        if st.button("+ Catat Pembayaran", use_container_width=True):
            goto("pembayaran")
    with aksi[1]:
        if st.button("+ Buat Sewa", use_container_width=True):
            goto("sewa")
    with aksi[2]:
        if st.button("+ Tambah Penghuni", use_container_width=True):
            goto("penghuni")

    st.write("")

    # ------------------------------------------------------------------
    # KPI utama
    # ------------------------------------------------------------------
    kolom = st.columns(4)
    with kolom[0]:
        kpi_card(
            "Total Kamar",
            str(data["total_kamar"]),
            f"{len(data['per_tipe'])} tipe kamar",
            tone="plum",
            icon="▤",
        )
    with kolom[1]:
        kpi_card(
            "Kamar Tersedia",
            str(data["tersedia"]),
            "Siap dihuni hari ini",
            tone="green",
            icon="✓",
        )
    with kolom[2]:
        kpi_card(
            "Kamar Ditempati",
            str(data["ditempati"]),
            f"{data['okupansi']:.0f}% tingkat okupansi",
            tone="rose",
            icon="◉",
        )
    with kolom[3]:
        kpi_card(
            "Sewa Aktif",
            str(data["sewa_aktif"]),
            "Kontrak berjalan",
            tone="amber",
            icon="⇄",
        )

    st.write("")

    # ------------------------------------------------------------------
    # Pembayaran bulan ini & tunggakan
    # ------------------------------------------------------------------
    bulan_ini = MONTHS_ID[today().month - 1]
    kiri, kanan = st.columns(2)
    with kiri:
        kpi_card(
            "Pembayaran Bulan Ini",
            rupiah(data["bayar_nominal"]),
            f"{data['bayar_jumlah']} transaksi tercatat · {bulan_ini} {today().year}",
            tone="green",
            icon="Rp",
        )
    with kanan:
        kpi_card(
            "Tunggakan",
            rupiah(data["tunggakan_nominal"]),
            f"{data['tunggakan_jumlah']} periode melewati jatuh tempo",
            tone="red" if data["tunggakan_jumlah"] else "green",
            icon="!",
        )

    st.write("")

    # ------------------------------------------------------------------
    # Okupansi & ketersediaan per tipe
    # ------------------------------------------------------------------
    kiri, kanan = st.columns([1.0, 1.65])

    with kiri:
        legend = (
            f'<div class="ks-legend">'
            f'<span><span class="ks-dot" style="background:#7B3F61"></span>'
            f"Ditempati <b>{data['ditempati']}</b></span>"
            f'<span><span class="ks-dot" style="background:#E4D3DD"></span>'
            f"Tersedia <b>{data['tersedia']}</b></span></div>"
        )
        st.markdown(
            f'<div class="ks-card">'
            f'<div class="ks-card-head"><div class="ks-card-title">'
            f"Okupansi Kamar</div><div class=\"ks-card-sub\">Hari ini</div></div>"
            f"{donut(float(data['okupansi']))}{legend}</div>",
            unsafe_allow_html=True,
        )

    with kanan:
        bars = ""
        for row in data["per_tipe"]:
            tipe = str(row["tipe"])
            meta = ROOM_TYPES.get(tipe, {})
            bars += bar_row(
                f"Tipe {tipe}",
                int(row["tersedia"]),
                int(row["total"]),
                str(meta.get("warna", "#7B3F61")),
            )
        st.markdown(
            f'<div class="ks-card">'
            f'<div class="ks-card-head"><div class="ks-card-title">'
            f"Ketersediaan per Tipe</div>"
            f'<div class="ks-card-sub">{data["tersedia"]} dari '
            f'{data["total_kamar"]} kamar siap huni</div></div>'
            f"{bars}"
            f'<div style="font-size:.76rem;color:#7A6B74;margin-top:2px">'
            f"Tipe A: AC + KM dalam · Tipe B: AC + KM luar · "
            f"Tipe C: kipas + KM luar</div></div>",
            unsafe_allow_html=True,
        )

    st.write("")

    # ------------------------------------------------------------------
    # Pembayaran terbaru & sewa segera berakhir
    # ------------------------------------------------------------------
    kiri, kanan = st.columns([1.5, 1.0])

    with kiri:
        card_header("Pembayaran Terbaru", "5 transaksi terakhir")
        rows = []
        for row in data["terbaru"]:
            rows.append(
                [
                    strong(str(row["id_pembayaran"])),
                    escape(str(row["nama_penghuni"])),
                    escape(str(row["nomor_kamar"])),
                    escape(
                        f"{MONTHS_ID[int(row['periode_bulan']) - 1]} "
                        f"{row['periode_tahun']}"
                    ),
                    rupiah(row["nominal"]),
                    fmt_date_short(row["tanggal_bayar"]),
                ]
            )
        table(
            ["ID", "Penghuni", "Kamar", "Periode", "Nominal", "Dibayar"],
            rows,
            empty_title="Belum ada pembayaran",
            empty_message="Catat pembayaran pertama lewat menu Pembayaran.",
        )

    with kanan:
        items = data["segera_berakhir"]
        if not items:
            isi = (
                '<div style="font-size:.84rem;color:#7A6B74;padding:8px 0">'
                "Tidak ada sewa yang berakhir dalam 30 hari ke depan.</div>"
            )
        else:
            isi = ""
            for row in items:
                sisa = days_between(today(), row["tanggal_selesai"])
                isi += (
                    f'<div style="display:flex;justify-content:space-between;'
                    f'gap:10px;padding:9px 0;border-bottom:1px solid #F3EAEF">'
                    f"<div><div style=\"font-weight:700;font-size:.85rem\">"
                    f"{escape(str(row['nama_penghuni']))}</div>"
                    f'<div style="font-size:.76rem;color:#7A6B74">'
                    f"Kamar {escape(str(row['nomor_kamar']))} · "
                    f"{fmt_date_short(row['tanggal_selesai'])}</div></div>"
                    f'<div style="font-size:.76rem;font-weight:700;'
                    f'color:#A96A12;white-space:nowrap">{sisa} hari</div></div>'
                )
        st.markdown(
            f'<div class="ks-card">'
            f'<div class="ks-card-head"><div class="ks-card-title">'
            f"Sewa Segera Berakhir</div>"
            f'<div class="ks-card-sub">30 hari ke depan</div></div>'
            f"{isi}</div>",
            unsafe_allow_html=True,
        )

    st.write("")

    # ------------------------------------------------------------------
    # Rincian tunggakan
    # ------------------------------------------------------------------
    if data["tunggakan_jumlah"]:
        card_header(
            "Perlu Ditindaklanjuti",
            f"{data['tunggakan_jumlah']} periode terlambat",
        )
        rows = []
        for item in data["tunggakan_rincian"]:
            rows.append(
                [
                    strong(str(item["id_sewa"])),
                    escape(str(item["nama_penghuni"])),
                    escape(str(item["nomor_kamar"])),
                    escape(str(item["label"])),
                    fmt_date_short(item["jatuh_tempo"]),
                    rupiah(item["nominal"]),
                ]
            )
        table(
            ["Sewa", "Penghuni", "Kamar", "Periode", "Jatuh Tempo", "Nominal"],
            rows,
        )
