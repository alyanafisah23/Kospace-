"""Repository data pembayaran dan status tagihan."""

from __future__ import annotations

import sqlite3
from datetime import date

from ..config import PAYMENT_DUE_DAY
from ..utils import month_label, month_span, next_id, parse_date
from ..validators import ValidationError, validate_pembayaran

_SELECT_BAYAR = """
SELECT b.*,
       s.id_penghuni,
       s.id_kamar,
       s.harga_bulanan AS harga_sewa,
       p.nama AS nama_penghuni,
       k.nomor_kamar
FROM pembayaran b
JOIN sewa s ON s.id_sewa = b.id_sewa
JOIN penghuni p ON p.id_penghuni = s.id_penghuni
JOIN kamar k ON k.id_kamar = s.id_kamar
"""


def list_pembayaran(
    conn: sqlite3.Connection,
    id_sewa: str | None = None,
    tahun: int | None = None,
    bulan: int | None = None,
    q: str | None = None,
) -> list[sqlite3.Row]:
    sql = _SELECT_BAYAR + " WHERE 1 = 1"
    params: list[object] = []
    if id_sewa:
        sql += " AND b.id_sewa = ?"
        params.append(id_sewa)
    if tahun:
        sql += " AND b.periode_tahun = ?"
        params.append(int(tahun))
    if bulan:
        sql += " AND b.periode_bulan = ?"
        params.append(int(bulan))
    if q:
        pola = f"%{q.strip()}%"
        sql += (
            " AND (p.nama LIKE ? OR k.nomor_kamar LIKE ? OR b.id_pembayaran LIKE ?)"
        )
        params.extend([pola, pola, pola])
    sql += " ORDER BY b.periode_tahun DESC, b.periode_bulan DESC, b.tanggal_bayar DESC"
    return conn.execute(sql, params).fetchall()


def get_pembayaran(
    conn: sqlite3.Connection, id_pembayaran: str
) -> sqlite3.Row | None:
    return conn.execute(
        _SELECT_BAYAR + " WHERE b.id_pembayaran = ?", (id_pembayaran,)
    ).fetchone()


def create_pembayaran(
    conn: sqlite3.Connection,
    id_sewa: str,
    periode_bulan: int,
    periode_tahun: int,
    tanggal_bayar: date,
    nominal: int | float,
) -> str:
    validate_pembayaran(
        conn, id_sewa, periode_bulan, periode_tahun, nominal
    )
    id_pembayaran = next_id(conn, "pembayaran", "id_pembayaran", "BY")
    conn.execute(
        """
        INSERT INTO pembayaran (
            id_pembayaran, id_sewa, periode_bulan, periode_tahun,
            tanggal_bayar, nominal, status_pembayaran
        )
        VALUES (?, ?, ?, ?, ?, ?, 'Lunas')
        """,
        (
            id_pembayaran,
            id_sewa,
            int(periode_bulan),
            int(periode_tahun),
            parse_date(tanggal_bayar).isoformat(),
            int(nominal),
        ),
    )
    return id_pembayaran


def delete_pembayaran(conn: sqlite3.Connection, id_pembayaran: str) -> None:
    if not get_pembayaran(conn, id_pembayaran):
        raise ValidationError("Pembayaran tidak ditemukan.")
    # Pembayaran boleh dihapus untuk memperbaiki salah catat.
    conn.execute(
        "DELETE FROM pembayaran WHERE id_pembayaran = ?", (id_pembayaran,)
    )


def paid_map(
    conn: sqlite3.Connection, id_sewa: str
) -> dict[tuple[int, int], sqlite3.Row]:
    rows = conn.execute(
        "SELECT * FROM pembayaran WHERE id_sewa = ?", (id_sewa,)
    ).fetchall()
    return {(int(r["periode_tahun"]), int(r["periode_bulan"])): r for r in rows}


def billing_schedule(
    conn: sqlite3.Connection,
    sewa: sqlite3.Row,
    hari_ini: date | None = None,
) -> list[dict[str, object]]:
    """Jadwal tagihan per periode + status Lunas/Belum Dibayar/Terlambat."""
    hari_ini = hari_ini or date.today()
    mulai = parse_date(sewa["tanggal_mulai"])
    selesai = parse_date(sewa["tanggal_selesai"])
    dibayar = paid_map(conn, sewa["id_sewa"])

    jadwal: list[dict[str, object]] = []
    for tahun, bulan in month_span(mulai, selesai):
        jatuh_tempo = date(tahun, bulan, PAYMENT_DUE_DAY)
        if (tahun, bulan) == (mulai.year, mulai.month) and jatuh_tempo < mulai:
            jatuh_tempo = mulai

        bayar = dibayar.get((tahun, bulan))
        if bayar:
            status = "Lunas"
        elif hari_ini > jatuh_tempo:
            status = "Terlambat"
        else:
            status = "Belum Dibayar"

        jadwal.append(
            {
                "periode_bulan": bulan,
                "periode_tahun": tahun,
                "label": month_label(bulan, tahun),
                "jatuh_tempo": jatuh_tempo,
                "status": status,
                "pembayaran": bayar,
                "nominal": int(sewa["harga_bulanan"]),
            }
        )
    return jadwal


def total_dibayar(conn: sqlite3.Connection, id_sewa: str) -> int:
    row = conn.execute(
        "SELECT COALESCE(SUM(nominal), 0) FROM pembayaran WHERE id_sewa = ?",
        (id_sewa,),
    ).fetchone()
    return int(row[0])


def ringkasan_tunggakan(
    conn: sqlite3.Connection, hari_ini: date | None = None
) -> dict[str, object]:
    """Hitung periode terlambat pada seluruh sewa aktif."""
    hari_ini = hari_ini or date.today()
    rows = conn.execute(
        """
        SELECT s.*, p.nama AS nama_penghuni, k.nomor_kamar
        FROM sewa s
        JOIN penghuni p ON p.id_penghuni = s.id_penghuni
        JOIN kamar k ON k.id_kamar = s.id_kamar
        WHERE s.status_sewa = 'Aktif'
        """
    ).fetchall()

    jumlah = 0
    nominal = 0
    rincian: list[dict[str, object]] = []
    for sewa in rows:
        for item in billing_schedule(conn, sewa, hari_ini):
            if item["status"] == "Terlambat":
                jumlah += 1
                nominal += int(item["nominal"])
                rincian.append(
                    {
                        "id_sewa": sewa["id_sewa"],
                        "nama_penghuni": sewa["nama_penghuni"],
                        "nomor_kamar": sewa["nomor_kamar"],
                        "label": item["label"],
                        "jatuh_tempo": item["jatuh_tempo"],
                        "nominal": int(item["nominal"]),
                    }
                )
    return {"jumlah": jumlah, "nominal": nominal, "rincian": rincian}


def pembayaran_terbaru(
    conn: sqlite3.Connection, limit: int = 5
) -> list[sqlite3.Row]:
    return conn.execute(
        _SELECT_BAYAR
        + " ORDER BY b.tanggal_bayar DESC, b.id_pembayaran DESC LIMIT ?",
        (int(limit),),
    ).fetchall()
