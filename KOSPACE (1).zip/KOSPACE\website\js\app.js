/* ==========================================================================
   KOSPACE — antarmuka demo admin (app.js)
   ========================================================================== */
(function () {
  'use strict';

  const K = window.KOS;
  const $ = (selector, root) => (root || document).querySelector(selector);
  const $$ = (selector, root) => Array.prototype.slice.call((root || document).querySelectorAll(selector));

  const esc = (value) =>
    String(value == null ? '' : value).replace(/[&<>"']/g, (char) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[char]));

  /* -----------------------------------------------------------------------
     Ikon inline
     ----------------------------------------------------------------------- */
  const SVG_OPEN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
  const ICON = {
    dashboard: SVG_OPEN + '<rect x="3" y="3" width="7" height="7" rx="1.6"/><rect x="14" y="3" width="7" height="7" rx="1.6"/><rect x="3" y="14" width="7" height="7" rx="1.6"/><rect x="14" y="14" width="7" height="7" rx="1.6"/></svg>',
    bed: SVG_OPEN + '<path d="M3 18v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6"/><path d="M3 18v2"/><path d="M21 18v2"/><path d="M7 10V8a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v2"/><path d="M3 14h18"/></svg>',
    users: SVG_OPEN + '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    swap: SVG_OPEN + '<path d="M7 4 3 8l4 4"/><path d="M3 8h13a4 4 0 0 1 4 4"/><path d="m17 20 4-4-4-4"/><path d="M21 16H8a4 4 0 0 1-4-4"/></svg>',
    wallet: SVG_OPEN + '<path d="M20 12V7a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h15a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/></svg>',
    clock: SVG_OPEN + '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    plus: SVG_OPEN + '<path d="M12 5v14"/><path d="M5 12h14"/></svg>',
    search: SVG_OPEN + '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.2-3.2"/></svg>',
    edit: SVG_OPEN + '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>',
    trash: SVG_OPEN + '<path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>',
    check: SVG_OPEN + '<path d="m4 12 5 5L20 6"/></svg>',
    x: SVG_OPEN + '<path d="M6 6l12 12"/><path d="M18 6 6 18"/></svg>',
    alert: SVG_OPEN + '<path d="M10.3 3.9 2.4 18a2 2 0 0 0 1.7 3h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>',
    info: SVG_OPEN + '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><path d="M12 8h.01"/></svg>',
    calendar: SVG_OPEN + '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4"/><path d="M8 3v4"/><path d="M3 11h18"/></svg>',
    download: SVG_OPEN + '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>',
    menu: SVG_OPEN + '<path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/></svg>',
    home: SVG_OPEN + '<path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9"/><path d="M9 20v-6h6v6"/></svg>',
    refresh: SVG_OPEN + '<path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg>',
    eye: SVG_OPEN + '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>',
    chart: SVG_OPEN + '<path d="M3 3v18h18"/><path d="M7 15l4-5 4 3 5-7"/></svg>',
    door: SVG_OPEN + '<path d="M4 21h16"/><path d="M6 21V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v17"/><path d="M14 12h.01"/></svg>',
    key: SVG_OPEN + '<circle cx="7.5" cy="15.5" r="4.5"/><path d="m11 12 9-9"/><path d="m17 4 3 3"/><path d="m14 7 3 3"/></svg>',
    arrowRight: SVG_OPEN + '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg>',
    arrowLeft: SVG_OPEN + '<path d="M19 12H5"/><path d="m11 18-6-6 6-6"/></svg>'
  };

  /* -----------------------------------------------------------------------
     Metadata halaman
     ----------------------------------------------------------------------- */
  const VIEW_META = {
    dashboard: {
      title: 'Dashboard',
      desc: 'Ringkasan kamar, sewa aktif, dan pembayaran bulan ini.'
    },
    kamar: {
      title: 'Data Kamar',
      desc: 'Kelola nomor, tipe, harga, fasilitas, dan status kamar.'
    },
    penghuni: {
      title: 'Data Penghuni',
      desc: 'Simpan identitas dan kontak penghuni kos.'
    },
    sewa: {
      title: 'Data Sewa',
      desc: 'Hubungkan penghuni dengan kamar dan atur masa sewa.'
    },
    pembayaran: {
      title: 'Pembayaran',
      desc: 'Catat pembayaran per periode dan pantau tagihan.'
    },
    riwayat: {
      title: 'Riwayat Transaksi',
      desc: 'Telusuri pembayaran yang terhubung ke sewa, penghuni, dan kamar.'
    }
  };

  const STATUS_TONE = {
    Tersedia: 'green',
    Ditempati: 'navy',
    Aktif: 'green',
    Selesai: 'muted',
    Lunas: 'green',
    'Belum Dibayar': 'amber',
    Terlambat: 'red'
  };

  /* -----------------------------------------------------------------------
     State antarmuka
     ----------------------------------------------------------------------- */
  const ui = {
    view: 'dashboard',
    kamarSearch: '',
    kamarTipe: '',
    kamarStatus: '',
    penghuniSearch: '',
    sewaSearch: '',
    sewaStatus: '',
    bayarLease: '',
    bayarBulan: '',
    bayarTahun: '',
    riwayatLease: '',
    riwayatSearch: ''
  };

  let modalOpen = false;
  let lastFocus = null;
  let pendingConfirm = null;

  /* -----------------------------------------------------------------------
     Helper HTML
     ----------------------------------------------------------------------- */
  function badge(text, tone) {
    const color = tone || STATUS_TONE[text] || 'muted';
    return `<span class="badge badge--${color}">${esc(text)}</span>`;
  }

  function iconButton(action, id, label, icon, danger) {
    return `<button type="button" class="icon-btn" data-action="${action}" data-id="${esc(id)}" aria-label="${esc(label)}" title="${esc(label)}"${danger ? ' style="color:var(--danger);border-color:#f5c6c1"' : ''}>${icon}</button>`;
  }

  function option(value, label, selected) {
    return `<option value="${esc(value)}"${String(selected) === String(value) ? ' selected' : ''}>${esc(label)}</option>`;
  }

  function emptyState(title, text) {
    return `<div class="empty-state">${ICON.door}<strong>${esc(title)}</strong><p>${esc(text)}</p></div>`;
  }

  function monthOptions(selected) {
    return K.MONTHS.map((name, index) => option(index + 1, name, selected)).join('');
  }

  function yearOptions(selected) {
    const current = K.today().getFullYear();
    let html = '';
    for (let year = current - 2; year <= current + 2; year += 1) {
      html += option(year, year, selected);
    }
    return html;
  }

  function residentOptions(selected) {
    return K.residents()
      .map((person) => option(person.id, `${person.nama} · ${person.id}`, selected))
      .join('');
  }

  function roomOptions(selected) {
    return K.rooms()
      .map((room) => {
        const status = K.roomStatus(room);
        return option(room.id, `${room.nomor} — ${K.ROOM_TYPES[room.tipe].label} · ${K.fmtRupiah(room.harga)} · ${status}`, selected);
      })
      .join('');
  }

  function leaseOptions(selected) {
    return K.leases()
      .map((lease) => {
        const person = K.getResident(lease.id_penghuni);
        const room = K.getRoom(lease.id_kamar);
        const status = K.leaseStatus(lease);
        return option(
          lease.id,
          `${lease.id} — ${person ? person.nama : '?'} · ${room ? room.nomor : '?'} · ${status}`,
          selected
        );
      })
      .join('');
  }

  /* -----------------------------------------------------------------------
     Dashboard
     ----------------------------------------------------------------------- */
  function kpiCard(label, value, hint, iconName, tone) {
    return `<div class="kpi${tone ? ' kpi--' + tone : ''}">
      <div class="kpi__top">
        <span class="kpi__label">${esc(label)}</span>
        <span class="kpi__icon">${ICON[iconName]}</span>
      </div>
      <div class="kpi__value">${value}</div>
      <div class="kpi__hint">${esc(hint)}</div>
    </div>`;
  }

  function donutSvg(percent, color) {
    const radius = 54;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference * (1 - Math.max(0, Math.min(100, percent)) / 100);
    return `<svg viewBox="0 0 128 128" role="img" aria-label="Okupansi ${percent} persen">
      <circle cx="64" cy="64" r="${radius}" fill="none" stroke="#eef3f8" stroke-width="14"/>
      <circle cx="64" cy="64" r="${radius}" fill="none" stroke="${color}" stroke-width="14" stroke-linecap="round" stroke-dasharray="${circumference.toFixed(2)}" stroke-dashoffset="${offset.toFixed(2)}"/>
    </svg>`;
  }

  function renderDashboard() {
    const s = K.summary();
    const now = K.today();
    const monthName = K.monthLabel(now.getMonth() + 1, now.getFullYear());
    const recent = K.recentPayments(5);
    const ending = K.leasesEndingSoon(45);

    const kpis = [
      kpiCard('Total kamar', s.totalRooms, '3 tipe kamar', 'bed', 'navy'),
      kpiCard('Tersedia', s.available, `${s.occupancyPct}% okupansi`, 'door', 'green'),
      kpiCard('Ditempati', s.occupied, 'dari total kamar', 'users', 'orange'),
      kpiCard('Sewa aktif', s.activeLeases, 'berjalan saat ini', 'swap', 'navy'),
      kpiCard('Pembayaran bulan ini', K.fmtRupiahShort(s.monthPaid), monthName, 'wallet', 'green'),
      kpiCard('Tunggakan', s.arrearsCount, K.fmtRupiah(s.arrearsAmount), 'alert', 'red')
    ].join('');

    const recentRows = recent.length
      ? recent.map((payment) => {
          const lease = K.getLease(payment.id_sewa);
          const person = lease ? K.getResident(lease.id_penghuni) : null;
          const room = lease ? K.getRoom(lease.id_kamar) : null;
          return `<tr>
            <td class="cell-strong cell-nowrap">${esc(payment.id)}</td>
            <td>${person ? esc(person.nama) : '—'}<div class="cell-muted">Kamar ${room ? esc(room.nomor) : '—'}</div></td>
            <td class="cell-nowrap">${esc(K.monthLabel(payment.bulan, payment.tahun))}</td>
            <td class="cell-nowrap">${esc(K.fmtRupiah(payment.nominal))}</td>
            <td>${badge(payment.status)}</td>
          </tr>`;
        }).join('')
      : `<tr><td colspan="5"><div class="table-empty"><strong>Belum ada pembayaran</strong>Catat pembayaran pertama dari menu Pembayaran.</div></td></tr>`;

    const endingRows = ending.length
      ? ending.map((lease) => {
          const person = K.getResident(lease.id_penghuni);
          const room = K.getRoom(lease.id_kamar);
          const days = K.daysBetween(K.iso(now), lease.selesai);
          return `<div class="period-row">
            <div>
              <div class="period-row__month">${room ? esc(room.nomor) : '—'} · ${person ? esc(person.nama) : '—'}</div>
              <div class="period-row__due">Berakhir ${esc(K.fmtDate(lease.selesai))}</div>
            </div>
            <span class="badge badge--${days <= 14 ? 'red' : 'amber'}">${days} hari</span>
          </div>`;
        }).join('')
      : emptyState('Tidak ada sewa yang segera berakhir', 'Sewa dalam 45 hari ke depan akan muncul di sini.');

    const overdueRows = s.overdue.length
      ? s.overdue.map((item) => `<tr>
          <td class="cell-strong">${esc(item.lease.id)}</td>
          <td>${item.resident ? esc(item.resident.nama) : '—'}<div class="cell-muted">Kamar ${item.room ? esc(item.room.nomor) : '—'}</div></td>
          <td class="cell-nowrap">${esc(K.monthLabel(item.month, item.year))}</td>
          <td class="cell-nowrap">${esc(K.fmtDate(item.due))}</td>
          <td class="cell-nowrap">${esc(K.fmtRupiah(item.amount))}</td>
          <td><button type="button" class="btn btn--soft btn--sm" data-action="pay-lease" data-id="${esc(item.lease.id)}" data-year="${item.year}" data-month="${item.month}">Catat</button></td>
        </tr>`).join('')
      : `<tr><td colspan="6"><div class="table-empty"><strong>Tidak ada tunggakan</strong>Semua pembayaran periode berjalan sudah tercatat.</div></td></tr>`;

    const typeBars = Object.keys(K.ROOM_TYPES).map((type) => {
      const spec = K.ROOM_TYPES[type];
      const data = s.byType[type];
      return `<div class="type-bar">
        <div class="type-bar__top">
          <span>${esc(spec.label)} · ${esc(K.fmtRupiah(spec.harga))}</span>
          <span>${data.occupied}/${data.total} terisi</span>
        </div>
        <div class="bar"><span style="width:${data.pct}%;background:${spec.color}"></span></div>
      </div>`;
    }).join('');

    return `
      <div class="page-head">
        <div class="page-head__text">
          <h2>Ringkasan operasional</h2>
          <p>Pantau okupansi, sewa aktif, dan pembayaran ${esc(monthName)} dalam satu layar.</p>
        </div>
        <div class="page-head__actions">
          <a class="btn btn--ghost btn--sm" href="#pembayaran">${ICON.wallet} Catat Pembayaran</a>
          <a class="btn btn--primary btn--sm" href="#sewa">${ICON.plus} Buat Sewa</a>
        </div>
      </div>
      <div class="kpi-grid">${kpis}</div>
      <div class="dash-grid">
        <section class="panel">
          <div class="panel__head">
            <div><div class="panel__title">Okupansi kamar</div><div class="panel__sub">Perbandingan kamar terisi dan tersedia</div></div>
          </div>
          <div class="occupancy">
            <div class="donut">
              ${donutSvg(s.occupancyPct, '#1d3b66')}
              <div class="donut__label"><strong>${s.occupancyPct}%</strong><span>terisi</span></div>
            </div>
            <div class="legend">
              <div class="legend__item"><span class="legend__dot" style="background:#1d3b66"></span>Ditempati<strong>${s.occupied}</strong></div>
              <div class="legend__item"><span class="legend__dot" style="background:#2e8b7a"></span>Tersedia<strong>${s.available}</strong></div>
              <div class="legend__item"><span class="legend__dot" style="background:#c9d5e4"></span>Total kamar<strong>${s.totalRooms}</strong></div>
            </div>
          </div>
        </section>
        <section class="panel">
          <div class="panel__head">
            <div><div class="panel__title">Ketersediaan per tipe</div><div class="panel__sub">Tipe A, B, dan C</div></div>
            <a class="panel__link" href="#kamar">Lihat kamar ${ICON.arrowRight}</a>
          </div>
          <div class="type-bars">${typeBars}</div>
        </section>
      </div>
      <div class="dash-grid dash-grid--wide">
        <section class="panel">
          <div class="panel__head">
            <div><div class="panel__title">Pembayaran terbaru</div><div class="panel__sub">5 transaksi terakhir</div></div>
            <a class="panel__link" href="#riwayat">Riwayat ${ICON.arrowRight}</a>
          </div>
          <div class="table-wrap">
            <table class="data">
              <thead><tr><th>ID</th><th>Penghuni</th><th>Periode</th><th>Nominal</th><th>Status</th></tr></thead>
              <tbody>${recentRows}</tbody>
            </table>
          </div>
        </section>
        <section class="panel">
          <div class="panel__head">
            <div><div class="panel__title">Sewa segera berakhir</div><div class="panel__sub">Dalam 45 hari ke depan</div></div>
            <a class="panel__link" href="#sewa">Sewa ${ICON.arrowRight}</a>
          </div>
          <div class="period-list">${endingRows}</div>
        </section>
      </div>
      <section class="panel">
        <div class="panel__head">
          <div><div class="panel__title">Perlu ditindaklanjuti</div><div class="panel__sub">Periode yang sudah melewati jatuh tempo</div></div>
          ${badge(s.arrearsCount + ' tunggakan', s.arrearsCount ? 'red' : 'green')}
        </div>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Sewa</th><th>Penghuni</th><th>Periode</th><th>Jatuh tempo</th><th>Nominal</th><th><span class="sr-only">Aksi</span></th></tr></thead>
            <tbody>${overdueRows}</tbody>
          </table>
        </div>
      </section>
    `;
  }

  /* -----------------------------------------------------------------------
     Data kamar
     ----------------------------------------------------------------------- */
  function renderKamar() {
    return `
      <div class="page-head">
        <div class="page-head__text">
          <h2>Data kamar</h2>
          <p>Nomor kamar unik (B01), status dihitung otomatis dari sewa aktif.</p>
        </div>
        <div class="page-head__actions">
          <button type="button" class="btn btn--primary btn--sm" data-action="add-room">${ICON.plus} Tambah Kamar</button>
        </div>
      </div>
      <section class="panel">
        <div class="toolbar">
          <div class="toolbar__search">${ICON.search}<input class="input" type="search" data-filter="kamar-search" placeholder="Cari nomor, tipe, atau fasilitas..." value="${esc(ui.kamarSearch)}" aria-label="Cari kamar"></div>
          <select class="select" data-filter="kamar-tipe" aria-label="Filter tipe">
            ${option('', 'Semua tipe', ui.kamarTipe)}
            ${Object.keys(K.ROOM_TYPES).map((type) => option(type, K.ROOM_TYPES[type].label, ui.kamarTipe)).join('')}
          </select>
          <select class="select" data-filter="kamar-status" aria-label="Filter status">
            ${option('', 'Semua status', ui.kamarStatus)}
            ${option('Tersedia', 'Tersedia', ui.kamarStatus)}
            ${option('Ditempati', 'Ditempati', ui.kamarStatus)}
          </select>
          <span class="toolbar__count" id="kamar-count"></span>
        </div>
        <div id="kamar-table"></div>
      </section>
    `;
  }

  function paintKamarTable() {
    const target = $('#kamar-table');
    if (!target) return;
    const query = ui.kamarSearch.toLowerCase();
    let rows = K.rooms().slice().sort((a, b) => (a.nomor < b.nomor ? -1 : 1));
    if (query) {
      rows = rows.filter((room) =>
        `${room.nomor} ${room.tipe} ${room.fasilitas}`.toLowerCase().indexOf(query) >= 0
      );
    }
    if (ui.kamarTipe) rows = rows.filter((room) => room.tipe === ui.kamarTipe);
    if (ui.kamarStatus) rows = rows.filter((room) => K.roomStatus(room) === ui.kamarStatus);

    const count = $('#kamar-count');
    if (count) count.textContent = `${rows.length} dari ${K.rooms().length} kamar`;

    if (!rows.length) {
      target.innerHTML = emptyState('Kamar tidak ditemukan', 'Ubah kata kunci atau filter untuk melihat kamar lain.');
      return;
    }

    target.innerHTML = `<div class="table-wrap"><table class="data">
      <thead><tr><th>Nomor</th><th>Tipe</th><th>Harga</th><th>Fasilitas</th><th>Penghuni</th><th>Status</th><th><span class="sr-only">Aksi</span></th></tr></thead>
      <tbody>${rows.map((room) => {
        const person = K.occupantOf(room.id);
        return `<tr>
          <td class="cell-strong">${esc(room.nomor)}<div class="cell-muted">${esc(room.id)}</div></td>
          <td><span class="chip chip--${room.tipe === 'A' ? '' : room.tipe === 'B' ? 'orange' : 'teal'}">${esc(room.tipe)}</span></td>
          <td class="cell-nowrap">${esc(K.fmtRupiah(room.harga))}</td>
          <td class="cell-muted">${esc(room.fasilitas)}</td>
          <td>${person ? esc(person.nama) : '<span class="cell-muted">—</span>'}</td>
          <td>${badge(K.roomStatus(room))}</td>
          <td><div class="cell-actions">
            ${iconButton('edit-room', room.id, 'Ubah kamar ' + room.nomor, ICON.edit)}
            ${iconButton('delete-room', room.id, 'Hapus kamar ' + room.nomor, ICON.trash, true)}
          </div></td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;
  }

  /* -----------------------------------------------------------------------
     Data penghuni
     ----------------------------------------------------------------------- */
  function renderPenghuni() {
    return `
      <div class="page-head">
        <div class="page-head__text">
          <h2>Data penghuni</h2>
          <p>Simpan nama, nomor telepon, telepon orang tua, dan alamat penghuni.</p>
        </div>
        <div class="page-head__actions">
          <button type="button" class="btn btn--primary btn--sm" data-action="add-resident">${ICON.plus} Tambah Penghuni</button>
        </div>
      </div>
      <section class="panel">
        <div class="toolbar">
          <div class="toolbar__search">${ICON.search}<input class="input" type="search" data-filter="penghuni-search" placeholder="Cari nama, telepon, atau alamat..." value="${esc(ui.penghuniSearch)}" aria-label="Cari penghuni"></div>
          <span class="toolbar__count" id="penghuni-count"></span>
        </div>
        <div id="penghuni-table"></div>
      </section>
    `;
  }

  function paintPenghuniTable() {
    const target = $('#penghuni-table');
    if (!target) return;
    const query = ui.penghuniSearch.toLowerCase();
    let rows = K.residents().slice().sort((a, b) => (a.nama < b.nama ? -1 : 1));
    if (query) {
      rows = rows.filter((person) =>
        `${person.nama} ${person.telepon} ${person.telepon_ortu} ${person.alamat}`.toLowerCase().indexOf(query) >= 0
      );
    }

    const count = $('#penghuni-count');
    if (count) count.textContent = `${rows.length} dari ${K.residents().length} penghuni`;

    if (!rows.length) {
      target.innerHTML = emptyState('Penghuni tidak ditemukan', 'Tambahkan penghuni baru atau ubah kata kunci pencarian.');
      return;
    }

    target.innerHTML = `<div class="table-wrap"><table class="data">
      <thead><tr><th>Nama</th><th>Telepon</th><th>Telepon orang tua</th><th>Alamat</th><th>Sewa aktif</th><th><span class="sr-only">Aksi</span></th></tr></thead>
      <tbody>${rows.map((person) => {
        const active = K.leases().filter((lease) => lease.id_penghuni === person.id && K.leaseStatus(lease) === 'Aktif');
        const rooms = active.map((lease) => K.getRoom(lease.id_kamar)).filter(Boolean).map((room) => room.nomor);
        return `<tr>
          <td class="cell-strong">${esc(person.nama)}<div class="cell-muted">${esc(person.id)}</div></td>
          <td class="cell-nowrap">${esc(person.telepon)}</td>
          <td class="cell-nowrap">${esc(person.telepon_ortu)}</td>
          <td class="cell-muted">${esc(person.alamat)}</td>
          <td>${rooms.length ? rooms.map((nomor) => `<span class="chip">${esc(nomor)}</span>`).join(' ') : '<span class="cell-muted">—</span>'}</td>
          <td><div class="cell-actions">
            ${iconButton('edit-resident', person.id, 'Ubah penghuni ' + person.nama, ICON.edit)}
            ${iconButton('delete-resident', person.id, 'Hapus penghuni ' + person.nama, ICON.trash, true)}
          </div></td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;
  }

  /* -----------------------------------------------------------------------
     Data sewa
     ----------------------------------------------------------------------- */
  function renderSewa() {
    return `
      <div class="page-head">
        <div class="page-head__text">
          <h2>Data sewa</h2>
          <p>Harga kamar disalin saat sewa dibuat. Jadwal bertabrakan ditolak sebelum disimpan.</p>
        </div>
        <div class="page-head__actions">
          <button type="button" class="btn btn--primary btn--sm" data-action="add-lease">${ICON.plus} Buat Sewa</button>
        </div>
      </div>
      <section class="panel">
        <div class="toolbar">
          <div class="toolbar__search">${ICON.search}<input class="input" type="search" data-filter="sewa-search" placeholder="Cari ID, penghuni, atau kamar..." value="${esc(ui.sewaSearch)}" aria-label="Cari sewa"></div>
          <select class="select" data-filter="sewa-status" aria-label="Filter status sewa">
            ${option('', 'Semua status', ui.sewaStatus)}
            ${option('Aktif', 'Aktif', ui.sewaStatus)}
            ${option('Selesai', 'Selesai', ui.sewaStatus)}
          </select>
          <span class="toolbar__count" id="sewa-count"></span>
        </div>
        <div id="sewa-table"></div>
      </section>
    `;
  }

  function paintSewaTable() {
    const target = $('#sewa-table');
    if (!target) return;
    const query = ui.sewaSearch.toLowerCase();
    let rows = K.leases().slice().sort((a, b) => (a.id < b.id ? 1 : -1));
    if (query) {
      rows = rows.filter((lease) => {
        const person = K.getResident(lease.id_penghuni);
        const room = K.getRoom(lease.id_kamar);
        return `${lease.id} ${person ? person.nama : ''} ${room ? room.nomor : ''}`.toLowerCase().indexOf(query) >= 0;
      });
    }
    if (ui.sewaStatus) rows = rows.filter((lease) => K.leaseStatus(lease) === ui.sewaStatus);

    const count = $('#sewa-count');
    if (count) count.textContent = `${rows.length} dari ${K.leases().length} sewa`;

    if (!rows.length) {
      target.innerHTML = emptyState('Sewa tidak ditemukan', 'Buat sewa baru atau ubah filter yang aktif.');
      return;
    }

    target.innerHTML = `<div class="table-wrap"><table class="data">
      <thead><tr><th>ID</th><th>Penghuni</th><th>Kamar</th><th>Periode</th><th>Durasi</th><th>Harga</th><th>Status</th><th><span class="sr-only">Aksi</span></th></tr></thead>
      <tbody>${rows.map((lease) => {
        const person = K.getResident(lease.id_penghuni);
        const room = K.getRoom(lease.id_kamar);
        const status = K.leaseStatus(lease);
        return `<tr>
          <td class="cell-strong">${esc(lease.id)}</td>
          <td>${person ? esc(person.nama) : '—'}<div class="cell-muted">${person ? esc(person.telepon) : ''}</div></td>
          <td><span class="cell-strong">${room ? esc(room.nomor) : '—'}</span><div class="cell-muted">${room ? esc(K.ROOM_TYPES[room.tipe].label) : ''}</div></td>
          <td class="cell-nowrap">${esc(K.fmtDate(lease.mulai))}<div class="cell-muted">s.d. ${esc(K.fmtDate(lease.selesai))}</div></td>
          <td class="cell-nowrap">${lease.durasi} bulan</td>
          <td class="cell-nowrap">${esc(K.fmtRupiah(lease.harga))}</td>
          <td>${badge(status)}</td>
          <td><div class="cell-actions">
            ${status === 'Aktif' ? `<button type="button" class="btn btn--soft btn--sm" data-action="end-lease" data-id="${esc(lease.id)}">Akhiri</button>` : ''}
            ${iconButton('delete-lease', lease.id, 'Hapus sewa ' + lease.id, ICON.trash, true)}
          </div></td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;
  }

  /* -----------------------------------------------------------------------
     Pembayaran
     ----------------------------------------------------------------------- */
  function ensurePaymentSelection() {
    if (!ui.bayarLease || !K.getLease(ui.bayarLease)) {
      const active = K.activeLeases()[0] || K.leases()[0];
      ui.bayarLease = active ? active.id : '';
    }
    if (!ui.bayarBulan) ui.bayarBulan = K.today().getMonth() + 1;
    if (!ui.bayarTahun) ui.bayarTahun = K.today().getFullYear();
  }

  function renderPembayaran() {
    ensurePaymentSelection();
    return `
      <div class="page-head">
        <div class="page-head__text">
          <h2>Pembayaran</h2>
          <p>Nominal harus sama dengan harga sewa. Satu sewa hanya boleh punya satu pembayaran per periode.</p>
        </div>
        <div class="page-head__actions">
          <button type="button" class="btn btn--ghost btn--sm" data-action="export-csv">${ICON.download} Unduh CSV</button>
        </div>
      </div>
      <div class="pay-grid">
        <section class="panel">
          <div class="panel__head">
            <div><div class="panel__title">Catat pembayaran</div><div class="panel__sub">Pilih sewa dan periode yang dibayar</div></div>
          </div>
          <form id="payment-form" class="form-section" novalidate>
            <div class="field">
              <label for="pay-lease">Sewa</label>
              <select class="select" id="pay-lease" name="id_sewa">${leaseOptions(ui.bayarLease)}</select>
            </div>
            <div class="form-row form-row--3">
              <div class="field"><label for="pay-month">Bulan</label><select class="select" id="pay-month" name="bulan">${monthOptions(ui.bayarBulan)}</select></div>
              <div class="field"><label for="pay-year">Tahun</label><input class="input" id="pay-year" name="tahun" type="number" min="2000" max="2100" value="${esc(ui.bayarTahun)}"></div>
              <div class="field"><label for="pay-date">Tanggal bayar</label><input class="input" id="pay-date" name="tanggal" type="date" value="${esc(K.iso(K.today()))}"></div>
            </div>
            <div class="field">
              <label for="pay-nominal">Nominal</label>
              <input class="input" id="pay-nominal" name="nominal" type="number" min="1" step="1000" value="${esc(currentLeasePrice())}">
              <span class="hint" id="pay-hint"></span>
            </div>
            <div class="form-error" id="payment-error"></div>
            <button class="btn btn--primary btn--block" type="submit">${ICON.check} Simpan Pembayaran</button>
          </form>
        </section>
        <section class="panel" id="pay-panel"></section>
      </div>
      <section class="panel">
        <div class="panel__head">
          <div><div class="panel__title">Pembayaran tercatat</div><div class="panel__sub">Klik detail untuk melihat keterkaitan data</div></div>
        </div>
        <div id="payment-table"></div>
      </section>
    `;
  }

  function currentLeasePrice() {
    const lease = K.getLease(ui.bayarLease);
    return lease ? lease.harga : '';
  }

  function paintPaymentPanel() {
    const target = $('#pay-panel');
    if (!target) return;
    const lease = K.getLease(ui.bayarLease);
    if (!lease) {
      target.innerHTML = emptyState('Belum ada sewa', 'Buat sewa terlebih dahulu agar pembayaran bisa dicatat.');
      return;
    }
    const person = K.getResident(lease.id_penghuni);
    const room = K.getRoom(lease.id_kamar);
    const periods = K.periodsFor(lease);
    const paid = K.payments().filter((payment) => payment.id_sewa === lease.id);
    const total = periods.length * Number(lease.harga);
    const paidTotal = paid.reduce((sum, payment) => sum + Number(payment.nominal), 0);
    const remaining = total - paidTotal;

    const rows = periods.map((period) => {
      const status = K.paymentStatus(lease, period.year, period.month);
      const due = K.dueDate(lease, period.year, period.month);
      return `<div class="period-row">
        <span class="period-row__month">${esc(K.monthLabel(period.month, period.year))}</span>
        <span class="period-row__due">JT ${esc(K.fmtDate(K.iso(due)))}</span>
        ${badge(status)}
      </div>`;
    }).join('');

    target.innerHTML = `
      <div class="panel__head">
        <div><div class="panel__title">Tagihan per sewa</div><div class="panel__sub">${esc(lease.id)} · ${person ? esc(person.nama) : '—'} · Kamar ${room ? esc(room.nomor) : '—'}</div></div>
        ${badge(K.leaseStatus(lease))}
      </div>
      <div class="pay-summary">
        <div class="pay-summary__item"><span>Total tagihan</span><strong>${esc(K.fmtRupiah(total))}</strong></div>
        <div class="pay-summary__item pay-summary__item--ok"><span>Sudah dibayar</span><strong>${esc(K.fmtRupiah(paidTotal))}</strong></div>
        <div class="pay-summary__item ${remaining > 0 ? 'pay-summary__item--warn' : ''}"><span>Sisa tagihan</span><strong>${esc(K.fmtRupiah(remaining))}</strong></div>
      </div>
      <div class="period-list">${rows || emptyState('Belum ada periode', 'Periksa tanggal sewa.')}</div>
    `;
  }

  function paintPaymentTable() {
    const target = $('#payment-table');
    if (!target) return;
    const rows = K.payments().slice().sort((a, b) => (a.tanggal < b.tanggal ? 1 : -1));
    if (!rows.length) {
      target.innerHTML = emptyState('Belum ada pembayaran', 'Pembayaran yang dicatat akan muncul di sini.');
      return;
    }
    target.innerHTML = `<div class="table-wrap"><table class="data">
      <thead><tr><th>ID</th><th>Tanggal</th><th>Penghuni</th><th>Kamar</th><th>Periode</th><th>Nominal</th><th>Status</th><th><span class="sr-only">Aksi</span></th></tr></thead>
      <tbody>${rows.map((payment) => {
        const lease = K.getLease(payment.id_sewa);
        const person = lease ? K.getResident(lease.id_penghuni) : null;
        const room = lease ? K.getRoom(lease.id_kamar) : null;
        return `<tr>
          <td class="cell-strong">${esc(payment.id)}</td>
          <td class="cell-nowrap">${esc(K.fmtDate(payment.tanggal))}</td>
          <td>${person ? esc(person.nama) : '—'}</td>
          <td>${room ? esc(room.nomor) : '—'}</td>
          <td class="cell-nowrap">${esc(K.monthLabel(payment.bulan, payment.tahun))}</td>
          <td class="cell-nowrap">${esc(K.fmtRupiah(payment.nominal))}</td>
          <td>${badge(payment.status)}</td>
          <td><div class="cell-actions">
            ${iconButton('detail-payment', payment.id, 'Detail pembayaran ' + payment.id, ICON.eye)}
            ${iconButton('delete-payment', payment.id, 'Hapus pembayaran ' + payment.id, ICON.trash, true)}
          </div></td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;
  }

  function clearPaymentError() {
    const errorBox = $('#payment-error');
    if (!errorBox) return;
    errorBox.textContent = '';
    errorBox.classList.remove('is-visible');
  }

  function syncPaymentForm() {
    const lease = K.getLease(ui.bayarLease);
    const hint = $('#pay-hint');
    const nominal = $('#pay-nominal');
    if (!lease) return;
    if (nominal && (!nominal.value || Number(nominal.value) === 0)) {
      nominal.value = lease.harga;
    }
    if (hint) {
      const due = K.dueDate(lease, ui.bayarTahun, ui.bayarBulan);
      const status = K.paymentStatus(lease, ui.bayarTahun, ui.bayarBulan);
      hint.textContent = `Jatuh tempo ${K.fmtDate(K.iso(due))} · Status periode ini: ${status}.`;
    }
  }

  /* -----------------------------------------------------------------------
     Riwayat
     ----------------------------------------------------------------------- */
  function renderRiwayat() {
    return `
      <div class="page-head">
        <div class="page-head__text">
          <h2>Riwayat transaksi</h2>
          <p>Setiap pembayaran terhubung ke satu sewa, satu penghuni, dan satu kamar.</p>
        </div>
        <div class="page-head__actions">
          <button type="button" class="btn btn--ghost btn--sm" data-action="export-csv">${ICON.download} Unduh CSV</button>
        </div>
      </div>
      <section class="panel">
        <div class="history-toolbar">
          <div class="field">
            <label for="history-lease">Sewa</label>
            <select class="select" id="history-lease" data-filter="riwayat-lease">
              ${option('', 'Semua sewa', ui.riwayatLease)}
              ${leaseOptions(ui.riwayatLease)}
            </select>
          </div>
          <div class="field field--grow">
            <label for="history-search">Cari</label>
            <input class="input" id="history-search" type="search" data-filter="riwayat-search" placeholder="Cari penghuni, kamar, atau ID pembayaran..." value="${esc(ui.riwayatSearch)}">
          </div>
          <span class="toolbar__count" id="riwayat-count"></span>
        </div>
        <div id="riwayat-table"></div>
      </section>
    `;
  }

  function paintRiwayatTable() {
    const target = $('#riwayat-table');
    if (!target) return;
    const query = ui.riwayatSearch.toLowerCase();
    let rows = K.payments().slice().sort((a, b) => (a.tanggal < b.tanggal ? 1 : -1));
    if (ui.riwayatLease) rows = rows.filter((payment) => payment.id_sewa === ui.riwayatLease);
    if (query) {
      rows = rows.filter((payment) => {
        const lease = K.getLease(payment.id_sewa);
        const person = lease ? K.getResident(lease.id_penghuni) : null;
        const room = lease ? K.getRoom(lease.id_kamar) : null;
        return `${payment.id} ${payment.id_sewa} ${person ? person.nama : ''} ${room ? room.nomor : ''}`.toLowerCase().indexOf(query) >= 0;
      });
    }

    const count = $('#riwayat-count');
    if (count) count.textContent = `${rows.length} transaksi`;

    if (!rows.length) {
      target.innerHTML = emptyState('Riwayat tidak ditemukan', 'Ubah filter sewa atau kata kunci pencarian.');
      return;
    }

    target.innerHTML = `<div class="table-wrap"><table class="data">
      <thead><tr><th>ID</th><th>Tanggal</th><th>Sewa</th><th>Penghuni</th><th>Kamar</th><th>Periode</th><th>Nominal</th><th>Status</th><th><span class="sr-only">Aksi</span></th></tr></thead>
      <tbody>${rows.map((payment) => {
        const lease = K.getLease(payment.id_sewa);
        const person = lease ? K.getResident(lease.id_penghuni) : null;
        const room = lease ? K.getRoom(lease.id_kamar) : null;
        return `<tr>
          <td class="cell-strong">${esc(payment.id)}</td>
          <td class="cell-nowrap">${esc(K.fmtDate(payment.tanggal))}</td>
          <td>${esc(payment.id_sewa)}</td>
          <td>${person ? esc(person.nama) : '—'}</td>
          <td>${room ? esc(room.nomor) : '—'}</td>
          <td class="cell-nowrap">${esc(K.monthLabel(payment.bulan, payment.tahun))}</td>
          <td class="cell-nowrap">${esc(K.fmtRupiah(payment.nominal))}</td>
          <td>${badge(payment.status)}</td>
          <td><div class="cell-actions">${iconButton('detail-payment', payment.id, 'Detail pembayaran ' + payment.id, ICON.eye)}</div></td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;
  }

  /* -----------------------------------------------------------------------
     Modal
     ----------------------------------------------------------------------- */
  function openModal(options) {
    const root = $('#modal-root');
    const footer = options.footer !== undefined
      ? options.footer
      : `<button type="button" class="btn btn--ghost" data-action="close-modal">Batal</button>
         <button type="submit" class="btn btn--primary" form="modal-form">${ICON.check} Simpan</button>`;
    root.innerHTML = `<div class="modal${options.wide ? ' modal--wide' : ''}" role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <div class="modal__head">
        <div><h3 id="modal-title">${options.title}</h3>${options.subtitle ? `<p>${options.subtitle}</p>` : ''}</div>
        <button type="button" class="modal__close" data-action="close-modal" aria-label="Tutup">${ICON.x}</button>
      </div>
      <div class="modal__body">${options.body}</div>
      <div class="modal__foot">${footer}</div>
    </div>`;
    root.classList.add('is-open');
    modalOpen = true;
    lastFocus = document.activeElement;
    document.body.style.overflow = 'hidden';
    const form = root.querySelector('#modal-form');
    if (form && options.onSubmit) {
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        options.onSubmit(form);
      });
    }
    const first = root.querySelector('input:not([type="hidden"]), select, textarea, button');
    if (first) setTimeout(() => first.focus(), 30);
  }

  function closeModal() {
    const root = $('#modal-root');
    if (!root) return;
    root.classList.remove('is-open');
    root.innerHTML = '';
    modalOpen = false;
    pendingConfirm = null;
    document.body.style.overflow = '';
    if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
    lastFocus = null;
  }

  function showFormError(form, message) {
    const box = form.querySelector('#form-error');
    if (box) {
      box.textContent = message;
      box.classList.add('is-visible');
      box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

  function confirmDialog(options) {
    pendingConfirm = options.onConfirm;
    openModal({
      title: options.title,
      subtitle: options.subtitle || '',
      body: `<p style="font-size:.88rem;color:var(--muted);line-height:1.65">${options.message}</p>`,
      footer: `<button type="button" class="btn btn--ghost" data-action="close-modal">Batal</button>
               <button type="button" class="btn btn--danger" data-action="confirm">${esc(options.confirmLabel || 'Hapus')}</button>`
    });
  }

  /* -----------------------------------------------------------------------
     Toast
     ----------------------------------------------------------------------- */
  function toast(message, type) {
    const root = $('#toast-root');
    if (!root) return;
    const kind = type || 'success';
    const element = document.createElement('div');
    element.className = `toast toast--${kind}`;
    const icon = kind === 'error' ? ICON.alert : kind === 'info' ? ICON.info : ICON.check;
    element.innerHTML = `${icon}<div>${esc(message)}</div><button type="button" class="toast__close" aria-label="Tutup">×</button>`;
    root.appendChild(element);
    const close = () => {
      element.style.opacity = '0';
      element.style.transform = 'translateY(8px)';
      setTimeout(() => element.remove(), 220);
    };
    element.querySelector('.toast__close').addEventListener('click', close);
    setTimeout(close, 4400);
  }

  /* -----------------------------------------------------------------------
     Form kamar & penghuni
     ----------------------------------------------------------------------- */
  function roomForm(room) {
    const isEdit = Boolean(room);
    return `<form id="modal-form" class="form-section" novalidate>
      <div class="form-row">
        <div class="field">
          <label for="room-nomor">Nomor kamar</label>
          <input class="input" id="room-nomor" name="nomor" value="${room ? esc(room.nomor) : ''}" placeholder="Contoh A01" required>
          <span class="hint">Huruf tipe + 2 angka. Nomor tidak boleh kembar (B01).</span>
        </div>
        <div class="field">
          <label for="room-tipe">Tipe kamar</label>
          <select class="select" id="room-tipe" name="tipe">
            ${Object.keys(K.ROOM_TYPES).map((type) => option(type, `${K.ROOM_TYPES[type].label} · ${K.fmtRupiah(K.ROOM_TYPES[type].harga)}`, room ? room.tipe : type)).join('')}
          </select>
        </div>
      </div>
      <div class="field">
        <label for="room-harga">Harga bulanan</label>
        <input class="input" id="room-harga" name="harga" type="number" min="1" step="1000" value="${room ? room.harga : K.ROOM_TYPES.A.harga}" required>
      </div>
      <div class="field">
        <label for="room-fasilitas">Fasilitas</label>
        <input class="input" id="room-fasilitas" name="fasilitas" value="${room ? esc(room.fasilitas) : K.ROOM_TYPES.A.fasilitas}" required>
      </div>
      <div class="inline-note">${ICON.info}<span>Status kamar dihitung otomatis dari sewa aktif, bukan diisi manual.</span></div>
      <div class="form-error" id="form-error"></div>
    </form>`;
  }

  function openRoomModal(room) {
    openModal({
      title: room ? `Ubah kamar ${room.nomor}` : 'Tambah kamar',
      subtitle: room ? 'Perubahan harga tidak mengubah harga pada sewa yang sudah ada.' : 'Nomor kamar harus unik dan mengikuti format tipe + 2 angka.',
      body: roomForm(room),
      onSubmit: (form) => {
        const data = {
          nomor: form.nomor.value,
          tipe: form.tipe.value,
          harga: form.harga.value,
          fasilitas: form.fasilitas.value
        };
        const result = room ? K.updateRoom(room.id, data) : K.addRoom(data);
        if (!result.ok) {
          showFormError(form, result.message);
          return;
        }
        closeModal();
        toast(room ? `Kamar ${result.item.nomor} berhasil diubah.` : `Kamar ${result.item.nomor} berhasil ditambahkan.`);
        renderView('kamar');
      }
    });
  }

  function residentForm(person) {
    return `<form id="modal-form" class="form-section" novalidate>
      <div class="field">
        <label for="person-nama">Nama lengkap</label>
        <input class="input" id="person-nama" name="nama" value="${person ? esc(person.nama) : ''}" placeholder="Nama penghuni" required>
      </div>
      <div class="form-row">
        <div class="field">
          <label for="person-telepon">Nomor telepon</label>
          <input class="input" id="person-telepon" name="telepon" value="${person ? esc(person.telepon) : ''}" placeholder="0812-3456-7890" required>
        </div>
        <div class="field">
          <label for="person-ortu">Telepon orang tua</label>
          <input class="input" id="person-ortu" name="telepon_ortu" value="${person ? esc(person.telepon_ortu) : ''}" placeholder="0813-1111-2222" required>
        </div>
      </div>
      <div class="field">
        <label for="person-alamat">Alamat</label>
        <textarea class="textarea" id="person-alamat" name="alamat" placeholder="Kota, provinsi" required>${person ? esc(person.alamat) : ''}</textarea>
      </div>
      <div class="inline-note">${ICON.info}<span>Penghuni yang sudah punya catatan sewa tidak bisa dihapus (B10).</span></div>
      <div class="form-error" id="form-error"></div>
    </form>`;
  }

  function openResidentModal(person) {
    openModal({
      title: person ? `Ubah penghuni ${person.nama}` : 'Tambah penghuni',
      subtitle: 'Data kontak dipakai pemilik untuk menghubungi penghuni dan orang tua.',
      body: residentForm(person),
      onSubmit: (form) => {
        const data = {
          nama: form.nama.value,
          telepon: form.telepon.value,
          telepon_ortu: form.telepon_ortu.value,
          alamat: form.alamat.value
        };
        const result = person ? K.updateResident(person.id, data) : K.addResident(data);
        if (!result.ok) {
          showFormError(form, result.message);
          return;
        }
        closeModal();
        toast(person ? 'Data penghuni berhasil diubah.' : `${result.item.nama} berhasil ditambahkan.`);
        renderView('penghuni');
      }
    });
  }

  /* -----------------------------------------------------------------------
     Form sewa
     ----------------------------------------------------------------------- */
  function leaseForm() {
    const start = K.iso(K.today());
    const end = K.iso(K.addMonths(K.today(), 12));
    const firstResident = K.residents()[0];
    const firstRoom = K.rooms().find((room) => K.roomStatus(room) === 'Tersedia') || K.rooms()[0];
    return `<form id="modal-form" class="form-section" novalidate>
      <div class="form-row">
        <div class="field">
          <label for="lease-person">Penghuni</label>
          <select class="select" id="lease-person" name="id_penghuni">${residentOptions(firstResident ? firstResident.id : '')}</select>
        </div>
        <div class="field">
          <label for="lease-room">Kamar</label>
          <select class="select" id="lease-room" name="id_kamar">${roomOptions(firstRoom ? firstRoom.id : '')}</select>
        </div>
      </div>
      <div class="form-row">
        <div class="field">
          <label for="lease-start">Tanggal mulai</label>
          <input class="input" id="lease-start" name="mulai" type="date" value="${start}" required>
        </div>
        <div class="field">
          <label for="lease-end">Tanggal selesai</label>
          <input class="input" id="lease-end" name="selesai" type="date" value="${end}" required>
          <span class="hint">Harus setelah tanggal mulai (B06).</span>
        </div>
      </div>
      <div class="inline-note" id="lease-preview">${ICON.info}<span>Harga kamar akan disalin saat sewa disimpan.</span></div>
      <div class="form-error" id="form-error"></div>
    </form>`;
  }

  function updateLeasePreview() {
    const preview = $('#lease-preview');
    const person = $('#lease-person');
    const room = $('#lease-room');
    const start = $('#lease-start');
    const end = $('#lease-end');
    if (!preview || !room || !start || !end) return;
    const roomData = K.getRoom(room.value);
    const duration = start.value && end.value ? K.monthsBetween(start.value, end.value) : 0;
    const error = K.validateLease({
      id_penghuni: person ? person.value : '',
      id_kamar: room.value,
      mulai: start.value,
      selesai: end.value
    });
    const priceLine = roomData ? `Harga kamar ${K.fmtRupiah(roomData.harga)} / bulan · durasi ${duration} bulan.` : '';
    if (error) {
      preview.className = 'inline-note inline-note--warn';
      preview.innerHTML = `${ICON.alert}<span>${esc(error)}</span>`;
    } else {
      preview.className = 'inline-note inline-note--ok';
      preview.innerHTML = `${ICON.check}<span>${esc(priceLine)} Jadwal kamar ini tersedia.</span>`;
    }
  }

  function openLeaseModal() {
    openModal({
      title: 'Buat sewa baru',
      subtitle: 'Harga kamar disalin ke sewa agar riwayat tidak berubah saat harga kamar naik.',
      body: leaseForm(),
      wide: true,
      onSubmit: (form) => {
        const data = {
          id_penghuni: form.id_penghuni.value,
          id_kamar: form.id_kamar.value,
          mulai: form.mulai.value,
          selesai: form.selesai.value
        };
        const result = K.addLease(data);
        if (!result.ok) {
          showFormError(form, result.message);
          return;
        }
        closeModal();
        toast(`Sewa ${result.item.id} berhasil dibuat untuk kamar ${K.getRoom(result.item.id_kamar).nomor}.`);
        renderView('sewa');
      }
    });
    updateLeasePreview();
  }

  /* -----------------------------------------------------------------------
     Detail pembayaran
     ----------------------------------------------------------------------- */
  function openPaymentDetail(payment) {
    const lease = K.getLease(payment.id_sewa);
    const person = lease ? K.getResident(lease.id_penghuni) : null;
    const room = lease ? K.getRoom(lease.id_kamar) : null;
    openModal({
      title: `Detail pembayaran ${payment.id}`,
      subtitle: 'Transaksi ini terhubung ke satu sewa, satu penghuni, dan satu kamar.',
      body: `<div class="detail-list">
        <div class="detail-row"><span>ID pembayaran</span><strong>${esc(payment.id)}</strong></div>
        <div class="detail-row"><span>Tanggal bayar</span><strong>${esc(K.fmtDate(payment.tanggal))}</strong></div>
        <div class="detail-row"><span>Periode</span><strong>${esc(K.monthLabel(payment.bulan, payment.tahun))}</strong></div>
        <div class="detail-row"><span>Nominal</span><strong>${esc(K.fmtRupiah(payment.nominal))}</strong></div>
        <div class="detail-row"><span>Status</span><strong>${badge(payment.status)}</strong></div>
        <div class="detail-row"><span>Sewa</span><strong>${esc(payment.id_sewa)}</strong></div>
        <div class="detail-row"><span>Penghuni</span><strong>${person ? esc(person.nama) : '—'}</strong></div>
        <div class="detail-row"><span>Kamar</span><strong>${room ? esc(room.nomor) + ' · ' + esc(K.ROOM_TYPES[room.tipe].label) : '—'}</strong></div>
        <div class="detail-row"><span>Masa sewa</span><strong>${lease ? esc(K.fmtDate(lease.mulai)) + ' s.d. ' + esc(K.fmtDate(lease.selesai)) : '—'}</strong></div>
      </div>`,
      footer: `<button type="button" class="btn btn--ghost" data-action="close-modal">Tutup</button>`
    });
  }

  /* -----------------------------------------------------------------------
     Ekspor CSV
     ----------------------------------------------------------------------- */
  function downloadCsv() {
    const csv = K.csvPayments();
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `kospace-pembayaran-${K.iso(K.today())}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1200);
    toast('Rekap pembayaran diunduh sebagai CSV.', 'success');
  }

  /* -----------------------------------------------------------------------
     Render & routing
     ----------------------------------------------------------------------- */
  const RENDERERS = {
    dashboard: renderDashboard,
    kamar: renderKamar,
    penghuni: renderPenghuni,
    sewa: renderSewa,
    pembayaran: renderPembayaran,
    riwayat: renderRiwayat
  };

  function afterRender(view) {
    if (view === 'kamar') paintKamarTable();
    if (view === 'penghuni') paintPenghuniTable();
    if (view === 'sewa') paintSewaTable();
    if (view === 'pembayaran') {
      paintPaymentPanel();
      paintPaymentTable();
      syncPaymentForm();
    }
    if (view === 'riwayat') paintRiwayatTable();
  }

  function renderView(view) {
    const name = RENDERERS[view] ? view : 'dashboard';
    const meta = VIEW_META[name];
    ui.view = name;
    const title = $('#page-title');
    const desc = $('#page-desc');
    if (title) title.textContent = meta.title;
    if (desc) desc.textContent = meta.desc;
    $$('.side-link').forEach((link) => {
      link.classList.toggle('is-active', link.getAttribute('href') === '#' + name);
    });
    const container = $('#view');
    if (container) container.innerHTML = RENDERERS[name]();
    afterRender(name);
  }

  function route() {
    const hash = (window.location.hash || '#dashboard').replace(/^#/, '');
    renderView(VIEW_META[hash] ? hash : 'dashboard');
  }

  /* -----------------------------------------------------------------------
     Event global
     ----------------------------------------------------------------------- */
  function bindEvents() {
    window.addEventListener('hashchange', route);

    document.addEventListener('click', (event) => {
      const target = event.target.closest('[data-action]');
      if (!target) return;
      const action = target.getAttribute('data-action');
      const id = target.getAttribute('data-id');

      if (action === 'close-modal') {
        closeModal();
        return;
      }

      if (action === 'confirm') {
        const callback = pendingConfirm;
        closeModal();
        if (callback) callback();
        return;
      }

      if (action === 'add-room') {
        openRoomModal(null);
        return;
      }
      if (action === 'edit-room') {
        openRoomModal(K.getRoom(id));
        return;
      }
      if (action === 'delete-room') {
        const room = K.getRoom(id);
        if (!room) return;
        confirmDialog({
          title: `Hapus kamar ${room.nomor}?`,
          message: 'Kamar yang sudah punya riwayat sewa tidak akan bisa dihapus. Tindakan ini tidak dapat dibatalkan.',
          confirmLabel: 'Hapus kamar',
          onConfirm: () => {
            const result = K.deleteRoom(id);
            if (!result.ok) {
              toast(result.message, 'error');
              return;
            }
            toast(`Kamar ${room.nomor} berhasil dihapus.`);
            renderView('kamar');
          }
        });
        return;
      }

      if (action === 'add-resident') {
        openResidentModal(null);
        return;
      }
      if (action === 'edit-resident') {
        openResidentModal(K.getResident(id));
        return;
      }
      if (action === 'delete-resident') {
        const person = K.getResident(id);
        if (!person) return;
        confirmDialog({
          title: `Hapus penghuni ${person.nama}?`,
          message: 'Penghuni yang sudah punya catatan sewa tidak akan bisa dihapus. Tindakan ini tidak dapat dibatalkan.',
          confirmLabel: 'Hapus penghuni',
          onConfirm: () => {
            const result = K.deleteResident(id);
            if (!result.ok) {
              toast(result.message, 'error');
              return;
            }
            toast('Data penghuni berhasil dihapus.');
            renderView('penghuni');
          }
        });
        return;
      }

      if (action === 'add-lease') {
        openLeaseModal();
        return;
      }
      if (action === 'end-lease') {
        const lease = K.getLease(id);
        if (!lease) return;
        const person = K.getResident(lease.id_penghuni);
        confirmDialog({
          title: `Akhiri sewa ${lease.id}?`,
          subtitle: 'Sewa akan ditandai selesai hari ini.',
          message: `Sewa ${person ? person.nama : ''} pada kamar ${K.getRoom(lease.id_kamar).nomor} akan diakhiri. Riwayat dan pembayaran tetap tersimpan.`,
          confirmLabel: 'Akhiri sewa',
          onConfirm: () => {
            const result = K.endLease(id);
            if (!result.ok) {
              toast(result.message, 'error');
              return;
            }
            toast(`Sewa ${lease.id} ditandai selesai.`);
            renderView('sewa');
          }
        });
        return;
      }
      if (action === 'delete-lease') {
        const lease = K.getLease(id);
        if (!lease) return;
        confirmDialog({
          title: `Hapus sewa ${lease.id}?`,
          message: 'Sewa yang sudah punya pembayaran tidak akan bisa dihapus. Tindakan ini tidak dapat dibatalkan.',
          confirmLabel: 'Hapus sewa',
          onConfirm: () => {
            const result = K.deleteLease(id);
            if (!result.ok) {
              toast(result.message, 'error');
              return;
            }
            toast(`Sewa ${lease.id} berhasil dihapus.`);
            renderView('sewa');
          }
        });
        return;
      }

      if (action === 'pay-lease') {
        ui.bayarLease = id;
        ui.bayarBulan = Number(target.getAttribute('data-month')) || K.today().getMonth() + 1;
        ui.bayarTahun = Number(target.getAttribute('data-year')) || K.today().getFullYear();
        window.location.hash = '#pembayaran';
        if (ui.view === 'pembayaran') renderView('pembayaran');
        return;
      }

      if (action === 'delete-payment') {
        const payment = K.getPayment(id);
        if (!payment) return;
        confirmDialog({
          title: `Hapus pembayaran ${payment.id}?`,
          message: 'Pembayaran hanya boleh dihapus untuk memperbaiki salah catat. Setelah dihapus, status periode akan dihitung ulang.',
          confirmLabel: 'Hapus pembayaran',
          onConfirm: () => {
            const result = K.deletePayment(id);
            if (!result.ok) {
              toast(result.message, 'error');
              return;
            }
            toast(`Pembayaran ${payment.id} berhasil dihapus.`);
            renderView(ui.view);
          }
        });
        return;
      }

      if (action === 'detail-payment') {
        openPaymentDetail(K.getPayment(id));
        return;
      }

      if (action === 'export-csv') {
        downloadCsv();
        return;
      }

      if (action === 'reset-demo') {
        confirmDialog({
          title: 'Reset data demo?',
          message: 'Semua perubahan yang tersimpan di browser akan diganti dengan data contoh awal. Tindakan ini tidak dapat dibatalkan.',
          confirmLabel: 'Reset data',
          onConfirm: () => {
            K.resetDemo();
            ui.bayarLease = '';
            ui.bayarBulan = '';
            ui.bayarTahun = '';
            toast('Data demo berhasil direset.', 'info');
            renderView(ui.view);
          }
        });
        return;
      }

      if (action === 'sidebar-toggle') {
        document.body.classList.toggle('sidebar-open');
        return;
      }
      if (action === 'sidebar-close') {
        document.body.classList.remove('sidebar-open');
        return;
      }
    });

    document.addEventListener('input', (event) => {
      const filter = event.target.getAttribute && event.target.getAttribute('data-filter');
      if (!filter) return;
      if (filter === 'kamar-search') {
        ui.kamarSearch = event.target.value;
        paintKamarTable();
      } else if (filter === 'penghuni-search') {
        ui.penghuniSearch = event.target.value;
        paintPenghuniTable();
      } else if (filter === 'sewa-search') {
        ui.sewaSearch = event.target.value;
        paintSewaTable();
      } else if (filter === 'riwayat-search') {
        ui.riwayatSearch = event.target.value;
        paintRiwayatTable();
      }
    });

    document.addEventListener('change', (event) => {
      const filter = event.target.getAttribute && event.target.getAttribute('data-filter');
      if (filter === 'kamar-tipe') {
        ui.kamarTipe = event.target.value;
        paintKamarTable();
        return;
      }
      if (filter === 'kamar-status') {
        ui.kamarStatus = event.target.value;
        paintKamarTable();
        return;
      }
      if (filter === 'sewa-status') {
        ui.sewaStatus = event.target.value;
        paintSewaTable();
        return;
      }
      if (filter === 'riwayat-lease') {
        ui.riwayatLease = event.target.value;
        paintRiwayatTable();
        return;
      }

      if (event.target.id === 'pay-lease') {
        ui.bayarLease = event.target.value;
        const nominal = $('#pay-nominal');
        const lease = K.getLease(ui.bayarLease);
        if (nominal && lease) nominal.value = lease.harga;
        clearPaymentError();
        paintPaymentPanel();
        syncPaymentForm();
        return;
      }
      if (event.target.id === 'pay-month') {
        ui.bayarBulan = Number(event.target.value);
        clearPaymentError();
        paintPaymentPanel();
        syncPaymentForm();
        return;
      }
      if (event.target.id === 'pay-year') {
        ui.bayarTahun = Number(event.target.value);
        clearPaymentError();
        paintPaymentPanel();
        syncPaymentForm();
        return;
      }

      if (event.target.id === 'lease-room' || event.target.id === 'lease-start' || event.target.id === 'lease-end' || event.target.id === 'lease-person') {
        updateLeasePreview();
      }
    });

    document.addEventListener('submit', (event) => {
      if (event.target.id !== 'payment-form') return;
      event.preventDefault();
      const form = event.target;
      const data = {
        id_sewa: form.id_sewa.value,
        bulan: form.bulan.value,
        tahun: form.tahun.value,
        tanggal: form.tanggal.value,
        nominal: form.nominal.value
      };
      const result = K.addPayment(data);
      const errorBox = $('#payment-error');
      if (!result.ok) {
        if (errorBox) {
          errorBox.textContent = result.message;
          errorBox.classList.add('is-visible');
        }
        toast(result.message, 'error');
        return;
      }
      if (errorBox) {
        errorBox.textContent = '';
        errorBox.classList.remove('is-visible');
      }
      toast(`Pembayaran ${result.item.id} untuk ${K.monthLabel(result.item.bulan, result.item.tahun)} berhasil dicatat.`);
      renderView('pembayaran');
    });

    document.addEventListener('keydown', (event) => {
      if (!modalOpen) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        closeModal();
        return;
      }
      if (event.key !== 'Tab') return;
      const modal = $('.modal');
      if (!modal) return;
      const focusables = $$('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])', modal)
        .filter((element) => !element.disabled && element.offsetParent !== null);
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });

    $$('.side-link').forEach((link) => {
      link.addEventListener('click', () => document.body.classList.remove('sidebar-open'));
    });

    const overlay = $('#sidebar-overlay');
    if (overlay) overlay.addEventListener('click', () => document.body.classList.remove('sidebar-open'));
  }

  /* -----------------------------------------------------------------------
     Inisialisasi
     ----------------------------------------------------------------------- */
  function init() {
    const dateTarget = $('#topbar-date');
    if (dateTarget) dateTarget.innerHTML = ICON.calendar + '<span>' + esc(K.fmtDateLong(K.iso(K.today()))) + '</span>';
    bindEvents();
    route();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
