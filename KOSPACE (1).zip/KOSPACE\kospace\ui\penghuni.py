"""Halaman pengelolaan Penghuni."""

from __future__ import annotations

from html import escape

import streamlit as st

from ..database import db
from ..repositories import penghuni as repo
from ..validators import ValidationError
from .components import (
    badge,
    empty_state,
    flash,
    muted,
    page_header,
    strong,
    table,
)


def render() -> None:
    page_header(
        "Data Master",
        "Penghuni",
        "Simpan identitas penghuni beserta kontak darurat orang tua. "
        "Data yang punya riwayat sewa tidak dapat dihapus.",
    )
    tab_daftar, tab_tambah, tab_ubah = st.tabs(
        ["Daftar Penghuni", "Tambah Penghuni", "Ubah & Hapus"]
    )
    with tab_daftar:
        _daftar()
    with tab_tambah:
        _tambah()
    with tab_ubah:
        _ubah_hapus()


def _daftar() -> None:
    q = st.text_input(
        "Cari penghuni",
        placeholder="Nama, nomor telepon, atau alamat…",
        key="penghuni_cari",
    )
    with db() as conn:
        rows = repo.list_penghuni(conn, q)

    isi = []
    for row in rows:
        kamar = row["kamar_aktif"]
        isi.append(
            [
                strong(str(row["id_penghuni"])),
                escape(str(row["nama"])),
                escape(str(row["telepon"])),
                escape(str(row["telepon_ortu"])),
                escape(str(row["alamat"])),
                badge(f"Kamar {kamar}") if kamar else muted("—"),
                str(row["jumlah_sewa"]),
            ]
        )

    table(
        ["ID", "Nama", "Telepon", "Telepon Ortu", "Alamat", "Kamar Aktif", "Sewa"],
        isi,
        empty_title="Belum ada penghuni",
        empty_message="Tambahkan penghuni pertama pada tab Tambah Penghuni.",
    )
    st.caption(f"{len(rows)} penghuni ditampilkan.")


def _tambah() -> None:
    st.markdown("#### Identitas penghuni baru")
    kiri, kanan = st.columns(2)
    with kiri:
        nama = st.text_input(
            "Nama lengkap", placeholder="Contoh: Alya Nafisah",
            key="penghuni_nama_baru",
        )
        telepon = st.text_input(
            "Nomor telepon", placeholder="08xxxxxxxxxx",
            key="penghuni_telepon_baru",
        )
    with kanan:
        telepon_ortu = st.text_input(
            "Nomor telepon orang tua", placeholder="08xxxxxxxxxx",
            key="penghuni_ortu_baru",
        )
        alamat = st.text_area(
            "Alamat asal", height=90,
            placeholder="Kota / kabupaten asal",
            key="penghuni_alamat_baru",
        )

    if st.button("Simpan Penghuni", type="primary", use_container_width=True):
        try:
            with db() as conn:
                id_penghuni = repo.create_penghuni(
                    conn, nama, telepon, telepon_ortu, alamat
                )
            for kunci in (
                "penghuni_nama_baru",
                "penghuni_telepon_baru",
                "penghuni_ortu_baru",
                "penghuni_alamat_baru",
            ):
                st.session_state.pop(kunci, None)
            flash(
                "success",
                f"Penghuni {nama.strip()} berhasil ditambahkan ({id_penghuni}).",
            )
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))


def _ubah_hapus() -> None:
    with db() as conn:
        rows = repo.list_penghuni(conn)

    if not rows:
        empty_state(
            "Belum ada penghuni",
            "Tambahkan penghuni terlebih dahulu pada tab Tambah Penghuni.",
        )
        return

    peta = {str(r["id_penghuni"]): r for r in rows}
    id_penghuni = st.selectbox(
        "Pilih penghuni",
        list(peta),
        format_func=lambda k: f"{peta[k]['nama']} — {k}",
        key="penghuni_pilih_ubah",
    )
    orang = peta[id_penghuni]

    st.write("")
    st.markdown("#### Ubah data penghuni")
    kiri, kanan = st.columns(2)
    with kiri:
        nama = st.text_input(
            "Nama lengkap", value=str(orang["nama"]),
            key=f"edit_nama_{id_penghuni}",
        )
        telepon = st.text_input(
            "Nomor telepon", value=str(orang["telepon"]),
            key=f"edit_telepon_{id_penghuni}",
        )
    with kanan:
        telepon_ortu = st.text_input(
            "Nomor telepon orang tua", value=str(orang["telepon_ortu"]),
            key=f"edit_ortu_{id_penghuni}",
        )
        alamat = st.text_area(
            "Alamat asal", value=str(orang["alamat"]), height=90,
            key=f"edit_alamat_{id_penghuni}",
        )

    if st.button("Simpan Perubahan", type="primary"):
        try:
            with db() as conn:
                repo.update_penghuni(
                    conn, id_penghuni, nama, telepon, telepon_ortu, alamat
                )
            flash("success", f"Data {nama.strip()} berhasil diperbarui.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))

    st.divider()
    st.markdown("#### Hapus penghuni")
    with db() as conn:
        punya_sewa = repo.has_riwayat_sewa(conn, id_penghuni)

    if punya_sewa:
        st.warning(
            f"{orang['nama']} sudah punya catatan sewa sehingga tidak bisa "
            "dihapus (aturan B10). Riwayatnya tetap dapat ditelusuri lewat "
            "menu Riwayat.",
            icon="🔒",
        )
    else:
        yakin = st.checkbox(
            f"Saya yakin ingin menghapus {orang['nama']}",
            key=f"hapus_yakin_penghuni_{id_penghuni}",
        )
        if st.button(
            "Hapus Penghuni",
            type="primary",
            disabled=not yakin,
            key=f"hapus_penghuni_{id_penghuni}",
        ):
            try:
                with db() as conn:
                    repo.delete_penghuni(conn, id_penghuni)
                flash("success", f"{orang['nama']} berhasil dihapus.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))
