# KOSPACE — Sistem Administrasi Pengelolaan Kos

Aplikasi web lokal untuk pemilik kos putri mengelola data kamar, penghuni,
sewa, dan pembayaran dalam satu sistem.

Dibangun dengan **Python + Streamlit + SQLite**.

## Menjalankan di VS Code

1. Buka folder `kospace` di VS Code (`File > Open Folder`).
2. Buka terminal (`Ctrl + ~`), lalu jalankan:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   streamlit run app.py
   ```

   Jika PowerShell memblokir aktivasi venv, jalankan sekali:
   `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

3. Browser akan terbuka otomatis di `http://localhost:8501`.

Database SQLite dibuat otomatis di `data/kospace.db` saat aplikasi pertama
kali dijalankan, lengkap dengan 25 kamar (A01–A05, B01–B10, C01–C10).

### Data contoh (opsional)

```powershell
python -m kospace.seed_demo
```

Perintah ini menambahkan 3 penghuni, 3 sewa, dan beberapa pembayaran contoh
agar dashboard langsung terlihat terisi.

### Menjalankan pengujian aturan bisnis

```powershell
python -m unittest discover -s tests -v
```

## Struktur proyek

```
kospace/
├─ app.py                  # Entry point Streamlit + navigasi
├─ requirements.txt
├─ .streamlit/config.toml  # Tema warna aplikasi
├─ .vscode/                # Konfigurasi debug & editor
├─ docs/RANCANGAN.md       # Dokumen rancangan lengkap
├─ kospace/
│  ├─ config.py            # Konstanta, tipe kamar, harga
│  ├─ database.py          # Skema SQLite + seed kamar
│  ├─ utils.py             # Format tanggal/rupiah, ID otomatis
│  ├─ validators.py        # Aturan bisnis B01, B06, B08, B10, B14
│  ├─ repositories/        # Akses data per entitas
│  ├─ services/            # Sinkronisasi status + ringkasan dashboard
│  └─ ui/                  # Halaman & komponen antarmuka
├─ tests/                  # Unit test aturan bisnis
└─ data/kospace.db         # Dibuat otomatis
```

## Aturan bisnis yang diterapkan

| Kode | Aturan |
|------|--------|
| B01 | Nomor kamar tidak boleh kembar |
| B06 | Tanggal selesai harus setelah tanggal mulai |
| B08 | Nominal pembayaran > 0 dan sama dengan harga sewa |
| B10 | Kamar/penghuni dengan riwayat sewa tidak bisa dihapus |
| B14 | Satu sewa hanya boleh punya satu pembayaran per periode |
| — | Jadwal sewa bertabrakan ditolak sebelum disimpan |
| — | Status kamar & sewa diperbarui otomatis |
| — | Tanggal tampil DD-MM-YYYY, tersimpan YYYY-MM-DD |

Rancangan lengkap (ERD, wireframe, kamus data, rencana uji) ada di
[`docs/RANCANGAN.md`](docs/RANCANGAN.md).

## Website rancangan & demo admin

Selain aplikasi Streamlit, tersedia website statis untuk presentasi rancangan
sekaligus demo antarmuka yang bisa diklik:

- [`website/index.html`](website/index.html) — landing page rancangan.
- [`website/app.html`](website/app.html) — demo admin (dashboard, kamar,
  penghuni, sewa, pembayaran, riwayat) dengan aturan B01, B06, B08, B10, B14
  dan deteksi jadwal bertabrakan.
- [`website/README.md`](website/README.md) — cara menjalankan dan skenario uji.
- [`docs/RANCANGAN_WEBSITE.md`](docs/RANCANGAN_WEBSITE.md) — dokumen rancangan
  website: pemetaan 16 slide PPT, design system, wireframe, responsif, dan
  aksesibilitas.

Cara cepat membuka demo:

```powershell
python -m http.server 8765 --bind 127.0.0.1
```

Jalankan perintah di atas dari folder `kospace`, lalu buka
<http://127.0.0.1:8765/website/index.html>. Halaman website tidak
membutuhkan Python; perintah di atas hanya menjalankan server statis opsional
agar `localStorage` berjalan optimal dan tautan dokumen ikut aktif.

