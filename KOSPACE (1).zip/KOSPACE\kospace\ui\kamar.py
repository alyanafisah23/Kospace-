"""Halaman pengelolaan Kamar."""

from __future__ import annotations

from html import escape

import streamlit as st

from ..config import ROOM_TYPES
from ..database import db
from ..repositories import kamar as repo
from ..utils import rupiah
from ..validators import ValidationError
from .components import (
    badge,
    empty_state,
    flash,
    muted,
    page_header,
    strong,
    table,
)


def render() -> None:
    page_header(
        "Data Master",
        "Kamar",
        "Kelola nomor, tipe, harga, dan fasilitas kamar. Status kamar "
        "diperbarui otomatis dari sewa yang berjalan.",
    )
    tab_daftar, tab_tambah, tab_ubah = st.tabs(
        ["Daftar Kamar", "Tambah Kamar", "Ubah & Hapus"]
    )
    with tab_daftar:
        _daftar()
    with tab_tambah:
        _tambah()
    with tab_ubah:
        _ubah_hapus()


def _daftar() -> None:
    kiri, tengah, kanan = st.columns([2.0, 1.0, 1.0])
    q = kiri.text_input(
        "Cari kamar",
        placeholder="Nomor kamar atau fasilitas…",
        key="kamar_cari",
    )
    tipe = tengah.selectbox(
        "Tipe", ["Semua", "A", "B", "C"], key="kamar_filter_tipe"
    )
    status = kanan.selectbox(
        "Status", ["Semua", "Tersedia", "Ditempati"], key="kamar_filter_status"
    )

    with db() as conn:
        rows = repo.list_kamar(conn, status=status, tipe=tipe, q=q)

    isi = []
    for row in rows:
        penghuni = row["penghuni_aktif"]
        isi.append(
            [
                strong(str(row["nomor_kamar"])),
                badge(str(row["tipe"])),
                rupiah(row["harga_bulanan"]),
                escape(str(row["fasilitas"])),
                badge(str(row["status"])),
                escape(str(penghuni)) if penghuni else muted("—"),
            ]
        )

    table(
        ["Nomor", "Tipe", "Harga / Bulan", "Fasilitas", "Status", "Penghuni"],
        isi,
        empty_title="Kamar tidak ditemukan",
        empty_message="Coba ubah kata kunci atau filter yang dipakai.",
    )
    st.caption(f"{len(rows)} kamar ditampilkan.")


def _nomor_berikut(conn, tipe: str) -> str:
    terpakai = {
        str(r["nomor_kamar"])
        for r in conn.execute(
            "SELECT nomor_kamar FROM kamar WHERE tipe = ?", (tipe,)
        ).fetchall()
    }
    urutan = 1
    while f"{tipe}{urutan:02d}" in terpakai:
        urutan += 1
    return f"{tipe}{urutan:02d}"


def _tambah() -> None:
    st.session_state.setdefault("kamar_tipe_baru", "A")
    st.session_state.setdefault(
        "kamar_harga_baru", int(ROOM_TYPES["A"]["harga"])
    )
    st.session_state.setdefault(
        "kamar_fas_baru", str(ROOM_TYPES["A"]["fasilitas"])
    )

    kiri, kanan = st.columns([1.25, 1.0])

    with kiri:
        st.markdown("#### Informasi kamar baru")
        tipe = st.selectbox(
            "Tipe kamar",
            list(ROOM_TYPES),
            format_func=lambda t: f"Tipe {t} · {ROOM_TYPES[t]['fasilitas']}",
            key="kamar_tipe_baru",
        )

        # Saat tipe berubah, isi otomatis harga, fasilitas, dan nomor berikutnya.
        if st.session_state.get("_kamar_tipe_terakhir") != tipe:
            st.session_state["kamar_harga_baru"] = int(ROOM_TYPES[tipe]["harga"])
            st.session_state["kamar_fas_baru"] = str(
                ROOM_TYPES[tipe]["fasilitas"]
            )
            with db() as conn:
                st.session_state["kamar_nomor_baru"] = _nomor_berikut(conn, tipe)
            st.session_state["_kamar_tipe_terakhir"] = tipe

        nomor = st.text_input(
            "Nomor kamar",
            placeholder="Contoh: A06",
            key="kamar_nomor_baru",
            help="Nomor kamar harus unik dan diawali huruf sesuai tipe (B01).",
        )
        harga = st.number_input(
            "Harga bulanan (Rp)",
            min_value=0,
            step=50_000,
            format="%d",
            key="kamar_harga_baru",
        )
        fasilitas = st.text_area(
            "Fasilitas",
            height=90,
            key="kamar_fas_baru",
        )
        st.caption(f"Harga ditampilkan sebagai **{rupiah(harga)}** per bulan.")

        if st.button("Simpan Kamar", type="primary", use_container_width=True):
            try:
                with db() as conn:
                    id_kamar = repo.create_kamar(
                        conn, nomor, tipe, harga, fasilitas
                    )
                for kunci in (
                    "kamar_nomor_baru",
                    "kamar_harga_baru",
                    "kamar_fas_baru",
                    "_kamar_tipe_terakhir",
                ):
                    st.session_state.pop(kunci, None)
                flash("success", f"Kamar {nomor.upper()} berhasil ditambahkan ({id_kamar}).")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))

    with kanan:
        meta = ROOM_TYPES[tipe]
        st.markdown(
            f"""
            <div class="ks-card">
                <div class="ks-card-head">
                    <div class="ks-card-title">Standar Tipe {escape(tipe)}</div>
                    <div class="ks-card-sub">Bawaan sistem</div>
                </div>
                <div style="font-size:1.5rem;font-weight:800;color:#2B1B27">
                    {rupiah(meta['harga'])}<span style="font-size:.8rem;
                    font-weight:600;color:#7A6B74"> / bulan</span>
                </div>
                <div style="font-size:.84rem;color:#7A6B74;margin-top:8px">
                    {escape(str(meta['fasilitas']))}
                </div>
                <div style="margin-top:14px;padding-top:14px;
                            border-top:1px solid #EADFE6;font-size:.8rem;
                            color:#7A6B74">
                    Jumlah kamar tipe ini: <b>{meta['jumlah']} unit</b>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.info(
            "Harga pada tabel Sewa disalin saat sewa dibuat, sehingga "
            "perubahan harga kamar tidak mengubah riwayat pembayaran.",
            icon="ℹ️",
        )


def _ubah_hapus() -> None:
    with db() as conn:
        rows = repo.list_kamar(conn)

    if not rows:
        empty_state(
            "Belum ada kamar",
            "Tambahkan kamar terlebih dahulu pada tab Tambah Kamar.",
        )
        return

    peta = {str(r["id_kamar"]): r for r in rows}
    id_kamar = st.selectbox(
        "Pilih kamar",
        list(peta),
        format_func=lambda k: (
            f"{peta[k]['nomor_kamar']} — Tipe {peta[k]['tipe']} — "
            f"{peta[k]['status']}"
        ),
        key="kamar_pilih_ubah",
    )
    kamar = peta[id_kamar]

    st.write("")
    st.markdown("#### Ubah data kamar")
    kiri, kanan = st.columns(2)
    with kiri:
        nomor = st.text_input(
            "Nomor kamar", value=str(kamar["nomor_kamar"]),
            key=f"edit_nomor_{id_kamar}",
        )
        tipe = st.selectbox(
            "Tipe",
            list(ROOM_TYPES),
            index=list(ROOM_TYPES).index(str(kamar["tipe"])),
            format_func=lambda t: f"Tipe {t} · {ROOM_TYPES[t]['fasilitas']}",
            key=f"edit_tipe_{id_kamar}",
        )
    with kanan:
        harga = st.number_input(
            "Harga bulanan (Rp)",
            min_value=0,
            step=50_000,
            format="%d",
            value=int(kamar["harga_bulanan"]),
            key=f"edit_harga_{id_kamar}",
        )
        fasilitas = st.text_input(
            "Fasilitas",
            value=str(kamar["fasilitas"]),
            key=f"edit_fas_{id_kamar}",
        )

    if st.button("Simpan Perubahan", type="primary"):
        try:
            with db() as conn:
                repo.update_kamar(conn, id_kamar, nomor, tipe, harga, fasilitas)
            flash("success", f"Data kamar {nomor.upper()} berhasil diperbarui.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))

    st.divider()
    st.markdown("#### Hapus kamar")
    with db() as conn:
        punya_sewa = repo.has_riwayat_sewa(conn, id_kamar)

    if punya_sewa:
        st.warning(
            f"Kamar {kamar['nomor_kamar']} sudah punya riwayat sewa sehingga "
            "tidak bisa dihapus (aturan B10). Data tetap tersimpan untuk "
            "penelusuran.",
            icon="🔒",
        )
    else:
        yakin = st.checkbox(
            f"Saya yakin ingin menghapus kamar {kamar['nomor_kamar']}",
            key=f"hapus_yakin_{id_kamar}",
        )
        if st.button(
            "Hapus Kamar",
            type="primary",
            disabled=not yakin,
            key=f"hapus_kamar_{id_kamar}",
        ):
            try:
                with db() as conn:
                    repo.delete_kamar(conn, id_kamar)
                flash("success", f"Kamar {kamar['nomor_kamar']} berhasil dihapus.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))
