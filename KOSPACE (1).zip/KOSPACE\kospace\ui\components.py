"""Komponen antarmuka dan sistem desain KOSPACE."""

from __future__ import annotations

from html import escape

import streamlit as st

from ..config import APP_NAME, APP_TAGLINE, APP_VERSION, NAV_ITEMS

# ---------------------------------------------------------------------------
# Sistem desain
# ---------------------------------------------------------------------------
CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

:root {
    --ks-bg: #F6F1EE;
    --ks-surface: #FFFFFF;
    --ks-ink: #2B1B27;
    --ks-muted: #7A6B74;
    --ks-plum: #7B3F61;
    --ks-plum-dark: #5E2E49;
    --ks-rose: #B65C82;
    --ks-cream: #FBF7F4;
    --ks-line: #EADFE6;
    --ks-green: #2F7D5C;
    --ks-amber: #A96A12;
    --ks-red: #B23A48;
}

html, body, [class*="st-"], button, input, textarea, select {
    font-family: 'Plus Jakarta Sans', 'Segoe UI', sans-serif;
}

.stApp {
    background: var(--ks-bg);
    color: var(--ks-ink);
}

[data-testid="stHeader"] {
    background: transparent;
}

#MainMenu,
[data-testid="stToolbar"],
[data-testid="stDecoration"],
footer {
    display: none !important;
    visibility: hidden !important;
}

.block-container {
    padding-top: 1.5rem;
    padding-bottom: 3rem;
    max-width: 1180px;
}

/* --------------------------------------------------------------------- */
/* Sidebar                                                                */
/* --------------------------------------------------------------------- */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #2B1B27 0%, #3A2334 100%);
    border-right: 1px solid #4A2C40;
}

[data-testid="stSidebar"] > div:first-child {
    padding-top: 1.1rem;
}

[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] div,
[data-testid="stSidebar"] label {
    color: #F3E9EF;
}

[data-testid="stSidebar"] .stButton > button {
    width: 100%;
    justify-content: flex-start;
    text-align: left;
    border-radius: 10px;
    border: 1px solid transparent;
    background: transparent;
    color: #F3E9EF;
    font-weight: 600;
    font-size: 0.92rem;
    padding: 0.55rem 0.85rem;
    box-shadow: none;
}

[data-testid="stSidebar"] .stButton > button:hover {
    background: rgba(255, 255, 255, 0.08);
    border-color: rgba(255, 255, 255, 0.12);
    color: #FFFFFF;
}

[data-testid="stSidebar"] .stButton > button[kind="primary"] {
    background: #F3E9EF;
    border-color: #F3E9EF;
    color: #3A2334;
}

[data-testid="stSidebar"] .stButton > button[kind="primary"] * {
    color: #3A2334 !important;
}

.ks-brand {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 4px 4px 18px;
}

.ks-logo {
    width: 44px;
    height: 44px;
    border-radius: 13px;
    background: linear-gradient(135deg, #D988A8, #7B3F61);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.35rem;
    font-weight: 800;
    color: #fff !important;
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.25);
}

.ks-brand-name {
    font-size: 1.08rem;
    font-weight: 800;
    letter-spacing: 0.14em;
    line-height: 1.1;
    color: #fff !important;
}

.ks-brand-sub {
    font-size: 0.72rem;
    color: #C9B4C0 !important;
    margin-top: 3px;
}

.ks-side-label {
    font-size: 0.64rem;
    font-weight: 800;
    letter-spacing: 0.16em;
    color: #A98FA0 !important;
    padding: 4px 8px 8px;
}

.ks-side-foot {
    margin-top: 22px;
    padding: 14px;
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.09);
}

.ks-side-foot-title {
    font-size: 0.83rem;
    font-weight: 700;
    color: #F3E9EF !important;
}

.ks-side-foot-sub {
    font-size: 0.72rem;
    color: #C9B4C0 !important;
    margin-top: 2px;
}

.ks-side-foot-ver {
    font-size: 0.66rem;
    color: #A98FA0 !important;
    margin-top: 8px;
    letter-spacing: 0.08em;
}

/* --------------------------------------------------------------------- */
/* Judul halaman                                                          */
/* --------------------------------------------------------------------- */
.ks-head {
    margin-bottom: 1.15rem;
}

.ks-eyebrow {
    display: inline-block;
    font-size: 0.68rem;
    font-weight: 800;
    letter-spacing: 0.13em;
    text-transform: uppercase;
    color: var(--ks-plum);
    background: #F1E2EA;
    border-radius: 999px;
    padding: 4px 11px;
}

.ks-head h1 {
    font-size: 1.95rem;
    font-weight: 800;
    margin: 0.55rem 0 0.2rem;
    letter-spacing: -0.025em;
    color: var(--ks-ink);
    line-height: 1.15;
}

.ks-head p {
    margin: 0;
    color: var(--ks-muted);
    font-size: 0.94rem;
    max-width: 70ch;
}

/* --------------------------------------------------------------------- */
/* Kartu KPI                                                              */
/* --------------------------------------------------------------------- */
.ks-kpi {
    background: var(--ks-surface);
    border: 1px solid var(--ks-line);
    border-radius: 15px;
    padding: 16px 17px 14px;
    box-shadow: 0 1px 2px rgba(43, 27, 39, 0.04);
    position: relative;
    overflow: hidden;
    min-height: 108px;
}

.ks-kpi::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
    background: var(--accent, var(--ks-plum));
}

.ks-kpi-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

.ks-kpi-label {
    font-size: 0.68rem;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--ks-muted);
    font-weight: 800;
}

.ks-kpi-icon {
    width: 26px;
    height: 26px;
    border-radius: 8px;
    background: #F6EAF0;
    color: var(--ks-plum);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 0.8rem;
    font-weight: 700;
}

.ks-kpi-value {
    font-size: 1.55rem;
    font-weight: 800;
    line-height: 1.15;
    margin-top: 7px;
    color: var(--ks-ink);
    letter-spacing: -0.02em;
}

.ks-kpi-hint {
    font-size: 0.76rem;
    color: var(--ks-muted);
    margin-top: 3px;
}

/* --------------------------------------------------------------------- */
/* Kartu umum                                                             */
/* --------------------------------------------------------------------- */
.ks-card {
    background: var(--ks-surface);
    border: 1px solid var(--ks-line);
    border-radius: 15px;
    padding: 18px 20px;
    box-shadow: 0 1px 2px rgba(43, 27, 39, 0.04);
}

.ks-card-head {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 14px;
}

.ks-card-title {
    font-size: 0.98rem;
    font-weight: 800;
    color: var(--ks-ink);
}

.ks-card-sub {
    font-size: 0.76rem;
    color: var(--ks-muted);
}

/* --------------------------------------------------------------------- */
/* Tabel                                                                  */
/* --------------------------------------------------------------------- */
.ks-table-wrap {
    background: var(--ks-surface);
    border: 1px solid var(--ks-line);
    border-radius: 15px;
    overflow-x: auto;
    box-shadow: 0 1px 2px rgba(43, 27, 39, 0.04);
}

table.ks-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.86rem;
    min-width: 620px;
}

.ks-table th {
    text-align: left;
    padding: 11px 14px;
    background: #FBF7F4;
    color: var(--ks-muted);
    font-size: 0.68rem;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    border-bottom: 1px solid var(--ks-line);
    white-space: nowrap;
}

.ks-table td {
    padding: 11px 14px;
    border-bottom: 1px solid #F3EAEF;
    color: var(--ks-ink);
    vertical-align: middle;
}

.ks-table tr:last-child td {
    border-bottom: none;
}

.ks-table tbody tr:hover td {
    background: #FCF8FA;
}

.ks-table .ks-strong {
    font-weight: 700;
}

.ks-table .ks-muted {
    color: var(--ks-muted);
    font-size: 0.8rem;
}

/* --------------------------------------------------------------------- */
/* Badge                                                                  */
/* --------------------------------------------------------------------- */
.ks-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 3px 9px;
    border-radius: 999px;
    font-size: 0.72rem;
    font-weight: 700;
    white-space: nowrap;
    line-height: 1.4;
}

.ks-badge::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
    flex: 0 0 auto;
}

.ks-badge--green { color: #2F7D5C; background: #E4F3EC; }
.ks-badge--plum { color: #7B3F61; background: #F1E2EA; }
.ks-badge--rose { color: #A6476B; background: #F9E6EE; }
.ks-badge--sand { color: #8A6535; background: #F6EDDD; }
.ks-badge--amber { color: #A96A12; background: #FBF0DC; }
.ks-badge--red { color: #B23A48; background: #FBE7E9; }
.ks-badge--muted { color: #6F6269; background: #EFEAEC; }

/* --------------------------------------------------------------------- */
/* Progress & donut                                                       */
/* --------------------------------------------------------------------- */
.ks-donut {
    width: 138px;
    height: 138px;
    border-radius: 50%;
    background: conic-gradient(var(--ks-plum) calc(var(--p, 0) * 1%), #F0E4EA 0);
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    margin: 4px auto 10px;
}

.ks-donut::after {
    content: '';
    position: absolute;
    inset: 13px;
    background: #fff;
    border-radius: 50%;
}

.ks-donut-value {
    position: relative;
    z-index: 1;
    text-align: center;
    line-height: 1.1;
}

.ks-donut-value b {
    display: block;
    font-size: 1.55rem;
    font-weight: 800;
    color: var(--ks-ink);
}

.ks-donut-value span {
    font-size: 0.66rem;
    color: var(--ks-muted);
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-weight: 700;
}

.ks-legend {
    display: flex;
    justify-content: center;
    gap: 18px;
    font-size: 0.78rem;
    color: var(--ks-muted);
}

.ks-legend b {
    color: var(--ks-ink);
}

.ks-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    margin-right: 6px;
}

.ks-bar-row {
    margin-bottom: 15px;
}

.ks-bar-head {
    display: flex;
    justify-content: space-between;
    font-size: 0.8rem;
    margin-bottom: 6px;
    color: var(--ks-muted);
}

.ks-bar-head b {
    color: var(--ks-ink);
}

.ks-bar {
    height: 8px;
    border-radius: 999px;
    background: #F0E4EA;
    overflow: hidden;
}

.ks-bar > span {
    display: block;
    height: 100%;
    border-radius: 999px;
    background: var(--ks-plum);
}

/* --------------------------------------------------------------------- */
/* Flash & kosong                                                         */
/* --------------------------------------------------------------------- */
.ks-flash {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 11px 14px;
    border-radius: 11px;
    font-size: 0.87rem;
    font-weight: 600;
    margin-bottom: 14px;
    border: 1px solid transparent;
}

.ks-flash--success { background: #E4F3EC; color: #23664A; border-color: #C9E6D9; }
.ks-flash--error { background: #FBE7E9; color: #962F3C; border-color: #F3CBD0; }
.ks-flash--warning { background: #FBF0DC; color: #8A5710; border-color: #F0DCB6; }
.ks-flash--info { background: #EDE7F2; color: #5E3A72; border-color: #DDD0E8; }

.ks-empty {
    background: #FBF7F4;
    border: 1px dashed #DCCBD5;
    border-radius: 15px;
    padding: 34px 22px;
    text-align: center;
    color: var(--ks-muted);
}

.ks-empty-icon {
    font-size: 1.6rem;
    margin-bottom: 6px;
    color: #B99CAE;
}

.ks-empty-title {
    font-weight: 800;
    color: var(--ks-ink);
    font-size: 0.95rem;
}

.ks-empty p {
    margin: 4px 0 0;
    font-size: 0.84rem;
}

/* --------------------------------------------------------------------- */
/* Tabs & form                                                            */
/* --------------------------------------------------------------------- */
.stTabs [data-baseweb="tab-list"] {
    gap: 5px;
    background: #EDE3E9;
    padding: 5px;
    border-radius: 12px;
    width: fit-content;
    margin-bottom: 14px;
}

.stTabs [data-baseweb="tab"] {
    border-radius: 9px;
    padding: 7px 16px;
    font-weight: 700;
    font-size: 0.85rem;
    color: #6E5B66;
    background: transparent;
}

.stTabs [aria-selected="true"] {
    background: #FFFFFF !important;
    color: var(--ks-plum-dark) !important;
    box-shadow: 0 1px 3px rgba(43, 27, 39, 0.12);
}

.stTabs [data-baseweb="tab-highlight"],
.stTabs [data-baseweb="tab-border"] {
    display: none;
}

[data-testid="stForm"] {
    background: #FFFFFF;
    border: 1px solid var(--ks-line);
    border-radius: 15px;
    padding: 18px 20px;
    box-shadow: 0 1px 2px rgba(43, 27, 39, 0.04);
}

[data-baseweb="input"] > div,
[data-baseweb="select"] > div,
[data-baseweb="textarea"] > div {
    border-radius: 9px !important;
}

.stButton > button {
    border-radius: 9px;
    font-weight: 700;
    border: 1px solid #E3D4DD;
}

.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #7B3F61, #5E2E49);
    border: none;
    color: #FFFFFF;
}

.stButton > button[kind="primary"]:hover {
    background: linear-gradient(135deg, #6B3555, #4E243C);
    color: #FFFFFF;
}

div[data-testid="stExpander"] {
    border: 1px solid var(--ks-line);
    border-radius: 13px;
    background: #FFFFFF;
}

div[data-testid="stExpander"] summary {
    font-weight: 700;
    font-size: 0.87rem;
}

hr {
    border-color: var(--ks-line);
}
</style>
"""


def inject_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
def sidebar() -> str:
    st.sidebar.markdown(
        f"""
        <div class="ks-brand">
            <div class="ks-logo">K</div>
            <div>
                <div class="ks-brand-name">{APP_NAME}</div>
                <div class="ks-brand-sub">{APP_TAGLINE}</div>
            </div>
        </div>
        <div class="ks-side-label">MENU UTAMA</div>
        """,
        unsafe_allow_html=True,
    )

    if "page" not in st.session_state:
        st.session_state.page = "dashboard"

    for key, label, icon in NAV_ITEMS:
        aktif = st.session_state.page == key
        if st.sidebar.button(
            f"{icon}   {label}",
            key=f"nav_{key}",
            use_container_width=True,
            type="primary" if aktif else "secondary",
        ):
            st.session_state.page = key
            st.rerun()

    st.sidebar.markdown(
        f"""
        <div class="ks-side-foot">
            <div class="ks-side-foot-title">Kos Putri KOSPACE</div>
            <div class="ks-side-foot-sub">25 kamar &middot; 3 tipe</div>
            <div class="ks-side-foot-ver">VERSI {APP_VERSION}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    return st.session_state.page


def goto(page_key: str) -> None:
    st.session_state.page = page_key
    st.rerun()


# ---------------------------------------------------------------------------
# Elemen halaman
# ---------------------------------------------------------------------------
def page_header(eyebrow: str, title: str, subtitle: str) -> None:
    st.markdown(
        f"""
        <div class="ks-head">
            <span class="ks-eyebrow">{escape(eyebrow)}</span>
            <h1>{escape(title)}</h1>
            <p>{escape(subtitle)}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def kpi_card(
    label: str,
    value: str,
    hint: str = "",
    tone: str = "plum",
    icon: str = "",
) -> None:
    tones = {
        "plum": "#7B3F61",
        "rose": "#B65C82",
        "green": "#2F7D5C",
        "amber": "#A96A12",
        "red": "#B23A48",
    }
    accent = tones.get(tone, tones["plum"])
    st.markdown(
        f"""
        <div class="ks-kpi" style="--accent:{accent}">
            <div class="ks-kpi-top">
                <span class="ks-kpi-label">{escape(label)}</span>
                <span class="ks-kpi-icon">{escape(icon)}</span>
            </div>
            <div class="ks-kpi-value">{value}</div>
            <div class="ks-kpi-hint">{hint}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def badge(status: str) -> str:
    warna = {
        "Tersedia": "green",
        "Ditempati": "plum",
        "Aktif": "green",
        "Selesai": "muted",
        "Lunas": "green",
        "Belum Dibayar": "amber",
        "Terlambat": "red",
        "A": "plum",
        "B": "rose",
        "C": "sand",
    }.get(str(status), "muted")
    return (
        f'<span class="ks-badge ks-badge--{warna}">{escape(str(status))}</span>'
    )


def table(
    headers: list[str],
    rows: list[list[str]],
    empty_title: str = "Belum ada data",
    empty_message: str = "Data akan muncul di sini setelah ditambahkan.",
) -> None:
    if not rows:
        empty_state(empty_title, empty_message)
        return

    head = "".join(f"<th>{escape(h)}</th>" for h in headers)
    body = "".join(
        "<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>"
        for row in rows
    )
    st.markdown(
        f"""
        <div class="ks-table-wrap">
            <table class="ks-table">
                <thead><tr>{head}</tr></thead>
                <tbody>{body}</tbody>
            </table>
        </div>
        """,
        unsafe_allow_html=True,
    )


def empty_state(
    title: str, message: str = "", icon: str = "◌"
) -> None:
    st.markdown(
        f"""
        <div class="ks-empty">
            <div class="ks-empty-icon">{escape(icon)}</div>
            <div class="ks-empty-title">{escape(title)}</div>
            <p>{escape(message)}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def card_header(title: str, subtitle: str = "") -> None:
    st.markdown(
        f"""
        <div class="ks-card-head">
            <div class="ks-card-title">{escape(title)}</div>
            <div class="ks-card-sub">{escape(subtitle)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def flash(kind: str, message: str) -> None:
    """Simpan pesan untuk ditampilkan setelah rerun."""
    st.session_state["_flash"] = (kind, message)


def render_flash() -> None:
    data = st.session_state.pop("_flash", None)
    if not data:
        return
    kind, message = data
    ikon = {"success": "✓", "error": "!", "warning": "△", "info": "i"}.get(
        kind, "i"
    )
    st.markdown(
        f'<div class="ks-flash ks-flash--{kind}">'
        f"<span>{ikon}</span><span>{escape(message)}</span></div>",
        unsafe_allow_html=True,
    )


def bar_row(
    label: str,
    value: int,
    total: int,
    color: str = "#7B3F61",
) -> str:
    persen = (value / total * 100) if total else 0
    return (
        f'<div class="ks-bar-row">'
        f'<div class="ks-bar-head"><span>{escape(label)}</span>'
        f"<span><b>{value}</b> / {total}</span></div>"
        f'<div class="ks-bar"><span style="width:{persen:.0f}%;'
        f'background:{color}"></span></div></div>'
    )


def donut(persen: float) -> str:
    return (
        f'<div class="ks-donut" style="--p:{max(0, min(100, persen)):.1f}">'
        f'<div class="ks-donut-value"><b>{persen:.0f}%</b>'
        f"<span>Okupansi</span></div></div>"
    )


def muted(text: str) -> str:
    return f'<span class="ks-muted">{escape(text)}</span>'


def strong(text: str) -> str:
    return f'<span class="ks-strong">{escape(text)}</span>'
